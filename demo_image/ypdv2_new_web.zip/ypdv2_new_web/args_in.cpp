#include "args_in.h"

#include <format>
#include <stdexcept>
#include <string_view>

namespace {

[[nodiscard]] std::string_view argAt(int argc, char** argv, int i) {
	if (i < 0 || i >= argc) {
		return {};
	}
	const char* const s = argv[i];
	return s ? std::string_view{s} : std::string_view{};
}

[[nodiscard]] std::string programName(int argc, char** argv) {
	if (argc >= 1 && argv[0] != nullptr) {
		return fs::path(argv[0]).filename().string();
	}
	return "pdv_in";
}

[[nodiscard]] std::string buildUsage(std::string_view prog) {
	return std::format(
		"Usage: {} [-m|-r] <cover_image> <secret_file>\n"
		"       {} capsize <cover_image>",
		prog,
		prog);
}

[[noreturn]] void dieUsage(const std::string& usage) {
	throw std::runtime_error(usage);
}

} // namespace

ProgramArgs ProgramArgs::parse(int argc, char** argv) {
	const std::string usage = buildUsage(programName(argc, argv));
	ProgramArgs out{};
	if (argAt(argc, argv, 1) == "capsize") {
		if (argc != 3 || argAt(argc, argv, 2).empty()) {
			dieUsage(usage);
		}
		out.mode = Mode::capsize;
		out.option = Option::Reddit;
		out.image_file_path = argAt(argc, argv, 2);
		return out;
	}

	int i = 1;

	if (argAt(argc, argv, i) == "-m" || argAt(argc, argv, i) == "-r") {
		out.option = argAt(argc, argv, i) == "-m" ? Option::Mastodon : Option::Reddit;
		++i;
	}

	if (argc != i + 2 || argAt(argc, argv, i).empty() || argAt(argc, argv, i + 1).empty()) {
		dieUsage(usage);
	}

	out.image_file_path = argAt(argc, argv, i);
	out.data_file_path = argAt(argc, argv, i + 1);
	return out;
}
