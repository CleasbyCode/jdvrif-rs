#include "args_in.h"

#include <format>
#include <stdexcept>
#include <string_view>

namespace {

[[nodiscard]] std::string_view argAt(int argc, char** argv, int i) {
	if (i < 0 || i >= argc) {
		return {};
	}
	const char* const s = argv[i];
	return s ? std::string_view{s} : std::string_view{};
}

[[nodiscard]] std::string programName(int argc, char** argv) {
	if (argc >= 1 && argv[0] != nullptr) {
		return fs::path(argv[0]).filename().string();
	}
	return "pdv_in";
}

[[nodiscard]] std::string buildUsage(std::string_view prog) {
	return std::format("Usage: {} [-m] <cover_image> <secret_file>", prog);
}

[[noreturn]] void dieUsage(const std::string& usage) {
	throw std::runtime_error(usage);
}

} // namespace

ProgramArgs ProgramArgs::parse(int argc, char** argv) {
	const std::string usage = buildUsage(programName(argc, argv));
	ProgramArgs out{};
	int i = 1;

	if (argAt(argc, argv, i) == "-m") {
		out.option = Option::Mastodon;
		++i;
	}

	if (argc != i + 2 || argAt(argc, argv, i).empty() || argAt(argc, argv, i + 1).empty()) {
		dieUsage(usage);
	}

	out.image_file_path = argAt(argc, argv, i);
	out.data_file_path = argAt(argc, argv, i + 1);
	return out;
}
