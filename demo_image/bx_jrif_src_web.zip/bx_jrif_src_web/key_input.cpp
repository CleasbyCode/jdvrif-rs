// Web variant of the main source's key_input.cpp: the same getRecoveryKey() interface,
// so encryption.cpp and recover.cpp are shared unchanged, but the KEY comes
// from the file jdv_out registered (key_file.h) instead of a terminal prompt.

#include "key_input.h"
#include "key_file.h"
#include "key_codec.h"
#include "signal_utils.h"

#include <algorithm>
#include <stdexcept>
#include <string_view>
#include <utility>

namespace {
constexpr const char* FILE_ERROR = "KEY File Error: Invalid file contents.";

// A KEY whose check pair does not match its body: a typo the user can find,
// reported before any key derivation. Same text as the terminal prompt's.
constexpr const char* CHECK_ERROR =
    "KEY Entry Error: That KEY has a typo: its last two characters do not "
    "match the rest. Check each character, including upper and lower case.";

vBytes* key_file = nullptr;

[[nodiscard]] bool isTrimmed(Byte b) noexcept {
    return b == ' ' || b == '\t' || b == '\n' || b == '\r';
}
} // namespace

void setKeyFile(vBytes& key_file_bytes) noexcept {
    key_file = &key_file_bytes;
}

// The KEY file holds the KEY as printed (D8): surrounding " \t\r\n" is trimmed
// and the shared codec checks the rest, ignoring the group dashes. Failing
// that, a file of exactly 16 bytes holding a non-text byte is the raw 128-bit
// secret. The file's bytes are wiped whatever the outcome, so a KEY can be
// read only once.
RecoveryKey getRecoveryKey() {
    throwIfSignalCancellationRequested();
    throwIf(key_file == nullptr || key_file->empty(), FILE_ERROR);
    vBytes& bytes = *key_file;
    WipeBytesGuard wipe_bytes{bytes};

    std::size_t begin = 0;
    std::size_t end = bytes.size();
    while (begin < end && isTrimmed(bytes[begin])) ++begin;
    while (end > begin && isTrimmed(bytes[end - 1])) --end;
    auto parsed = parseRecoveryKeyText(std::string_view(
        reinterpret_cast<const char*>(bytes.data() + begin), end - begin));
    if (parsed) return std::move(*parsed);

    // Raw fallback, only when the untrimmed file holds a byte that is not
    // printable ASCII or \t \r \n: a plain-text file that failed the text
    // parse is a typo, not a raw secret, and gets the text error below.
    const bool has_binary_byte = std::ranges::any_of(bytes, [](Byte b) static {
        return !((b >= 0x20 && b <= 0x7E) || b == '\t' || b == '\r' || b == '\n');
    });
    if (has_binary_byte && bytes.size() == RECOVERY_KEY_BYTES) {
        RecoveryKeyBytes secret{};
        WipePodGuard<RecoveryKeyBytes> wipe_secret{secret};
        std::ranges::copy(bytes, secret.begin());
        throwIf(std::ranges::all_of(secret, [](Byte b) static { return b == 0; }), FILE_ERROR);
        return RecoveryKey::modern(secret);
    }

    throw std::runtime_error(
        parsed.error() == KeyParseError::checksum ? CHECK_ERROR : FILE_ERROR);
}
