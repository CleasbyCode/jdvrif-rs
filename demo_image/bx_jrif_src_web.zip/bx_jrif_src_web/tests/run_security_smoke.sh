#!/bin/bash
# Focused regressions for security/correctness fixes shared with the main CLI.
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
TESTS="$ROOT/tests"
FIXTURES="$TESTS/fixtures"
IN_BIN="${JDV_IN_BIN:-$ROOT/jdv_in}"
OUT_BIN="${JDV_OUT_BIN:-$ROOT/jdv_out}"
NO_BUILD=0

usage() {
    cat <<'EOF'
Usage: tests/run_security_smoke.sh [options]

Options:
  --no-build        Reuse existing binaries.
  --in-bin <path>   Use an explicit jdv_in binary path.
  --out-bin <path>  Use an explicit jdv_out binary path.
  -h, --help        Show this help.

JDV_IN_BIN and JDV_OUT_BIN provide the same binary overrides.
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --no-build)
            NO_BUILD=1
            shift
            ;;
        --in-bin)
            [[ $# -ge 2 ]] || { echo "--in-bin requires a path" >&2; exit 2; }
            IN_BIN="$2"
            NO_BUILD=1
            shift 2
            ;;
        --out-bin)
            [[ $# -ge 2 ]] || { echo "--out-bin requires a path" >&2; exit 2; }
            OUT_BIN="$2"
            NO_BUILD=1
            shift 2
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            usage >&2
            exit 2
            ;;
    esac
done

if [[ "$IN_BIN" != /* ]]; then IN_BIN="$(pwd -P)/${IN_BIN#./}"; fi
if [[ "$OUT_BIN" != /* ]]; then OUT_BIN="$(pwd -P)/${OUT_BIN#./}"; fi
if [[ "$NO_BUILD" -eq 0 ]]; then
    (cd "$ROOT" && bash ./compile_jdv_in.sh && bash ./compile_jdv_out.sh)
fi
for binary in "$IN_BIN" "$OUT_BIN"; do
    [[ -x "$binary" ]] || { echo "Binary not found or not executable: $binary" >&2; exit 1; }
done
for command_name in cmp find grep python3 sed; do
    command -v "$command_name" >/dev/null 2>&1 || {
        echo "Missing required command: $command_name" >&2
        exit 1
    }
done

COVER="$FIXTURES/covers/cover_default.jpg"
REDDIT_COVER="$FIXTURES/covers/cover_reddit.jpg"
PAYLOAD="$FIXTURES/payloads/payload_text.txt"
WORK="$(mktemp -d "${TMPDIR:-/tmp}/jdv-web-security.XXXXXX")"
trap 'rm -rf "$WORK"' EXIT

extract_embedded_image() {
    sed -n 's/.*Saved "file-embedded" JPG image: \(.*\) ([0-9][0-9]* bytes)\..*/\1/p' "$1" | tail -n 1
}

extract_pin() {
    sed -n 's/.*Recovery PIN: \[\*\*\*\([0-9][0-9]*\)\*\*\*\].*/\1/p' "$1" | tail -n 1
}

extract_recovered_file() {
    sed -n 's/.*Extracted hidden file: \(.*\) ([0-9][0-9]* bytes)\..*/\1/p' "$1" | tail -n 1
}

assert_no_stage_files() {
    local found
    found="$(find "$1" -maxdepth 1 \
        \( -name '.jdvrif_*' -o -name '.*.jdvrif_tmp_*' \) -print -quit)"
    if [[ -n "$found" ]]; then
        echo "staging file remains: $found" >&2
        return 1
    fi
}

prepare_fixture() {
    local tag="$1"
    local option="$2"
    local cover="$3"
    local dir="$WORK/fresh_$tag"
    local embedded pin
    mkdir -p "$dir"
    if [[ -n "$option" ]]; then
        (cd "$dir" && "$IN_BIN" "$option" "$cover" "$PAYLOAD" > conceal.log 2>&1)
    else
        (cd "$dir" && "$IN_BIN" "$cover" "$PAYLOAD" > conceal.log 2>&1)
    fi
    embedded="$(extract_embedded_image "$dir/conceal.log")"
    pin="$(extract_pin "$dir/conceal.log")"
    [[ -n "$embedded" && -n "$pin" && -f "$dir/$embedded" ]] || {
        cat "$dir/conceal.log" >&2
        return 1
    }
    printf '%s\n' "$pin" > "$dir/pin.txt"
    chmod 600 "$dir/pin.txt"
    if [[ "$tag" == "default" ]]; then
        DEFAULT_IMAGE="$dir/$embedded"
        DEFAULT_PIN_FILE="$dir/pin.txt"
    else
        REDDIT_IMAGE="$dir/$embedded"
        REDDIT_PIN_FILE="$dir/pin.txt"
    fi
}

prepare_fixture default "" "$COVER"
prepare_fixture reddit -r "$REDDIT_COVER"

test_authenticated_compression_mode() {
    local dir="$WORK/compression_tamper"
    mkdir -p "$dir"
    cp "$DEFAULT_PIN_FILE" "$dir/pin.txt"
    python3 - "$DEFAULT_IMAGE" "$dir/mode.jpg" "$dir/downgrade.jpg" <<'PY'
import sys
from pathlib import Path

data = bytearray(Path(sys.argv[1]).read_bytes())
mntr = data.find(b"mntrRGB")
if mntr < 8:
    raise SystemExit("ICC signature not found")
base = mntr - 8
compression_flag = base + 0x68
kdf_marker = base + 0x2FB
if data[kdf_marker:kdf_marker + 4] != b"KDF3":
    raise SystemExit("fresh fixture is not KDF3")
if data[compression_flag] == 0x58:
    raise SystemExit("fresh small payload unexpectedly bypassed compression")

data[compression_flag] = 0x58
Path(sys.argv[2]).write_bytes(data)
data[kdf_marker:kdf_marker + 4] = b"KDF2"
Path(sys.argv[3]).write_bytes(data)
PY
    local image
    for image in mode.jpg downgrade.jpg; do
        if (cd "$dir" && "$OUT_BIN" "$image" pin.txt > "recover-$image.log" 2>&1); then
            echo "tampered compression semantics were accepted from $image" >&2
            return 1
        fi
    done
    if find "$dir" -maxdepth 1 -type f -name 'payload_text*' -print -quit | grep -q .; then
        echo "tampered recovery left plaintext output" >&2
        return 1
    fi
    assert_no_stage_files "$dir"
}

test_wrong_pin_leaves_no_plaintext() {
    local dir="$WORK/wrong_pin"
    local actual_pin wrong_pin=1
    mkdir -p "$dir"
    cp "$DEFAULT_IMAGE" "$dir/input.jpg"
    actual_pin="$(sed -n '1{s/[^0-9]//g;p;}' "$DEFAULT_PIN_FILE")"
    if [[ "$actual_pin" == "$wrong_pin" ]]; then wrong_pin=2; fi
    printf '%s\n' "$wrong_pin" > "$dir/wrong-pin.txt"
    if (cd "$dir" && "$OUT_BIN" input.jpg wrong-pin.txt > recover.log 2>&1); then
        echo "jdv_out unexpectedly accepted a wrong PIN" >&2
        return 1
    fi
    if find "$dir" -maxdepth 1 -type f -name 'payload_text*' -print -quit | grep -q .; then
        echo "wrong-PIN recovery left plaintext output" >&2
        return 1
    fi
    assert_no_stage_files "$dir"
}

test_oversized_pin_file_rejected() {
    local dir="$WORK/oversized_pin"
    mkdir -p "$dir"
    cp "$DEFAULT_IMAGE" "$dir/input.jpg"
    python3 - "$dir/oversized-pin.txt" <<'PY'
import sys
from pathlib import Path

Path(sys.argv[1]).write_bytes(b"1" * 65)
PY
    if (cd "$dir" && "$OUT_BIN" input.jpg oversized-pin.txt > recover.log 2>&1); then
        echo "jdv_out accepted a PIN file over 64 bytes" >&2
        return 1
    fi
    grep -Eiq 'PIN.*64-byte size limit|PIN.*size limit' "$dir/recover.log"
    if find "$dir" -maxdepth 1 -type f -name 'payload_text*' -print -quit | grep -q .; then
        echo "oversized-PIN recovery left plaintext output" >&2
        return 1
    fi
    assert_no_stage_files "$dir"
}

test_truncated_ciphertext() {
    local dir="$WORK/truncated"
    mkdir -p "$dir"
    cp "$DEFAULT_PIN_FILE" "$dir/pin.txt"
    python3 - "$DEFAULT_IMAGE" "$dir/input.jpg" <<'PY'
import sys
from pathlib import Path

data = Path(sys.argv[1]).read_bytes()
mntr = data.find(b"mntrRGB")
if mntr < 8:
    raise SystemExit("ICC signature not found")
base = mntr - 8
size = int.from_bytes(data[base + 0x2CA:base + 0x2CE], "big")
payload = base + 0x33B
if size < 2 or payload + size > len(data):
    raise SystemExit("unexpected embedded layout")
Path(sys.argv[2]).write_bytes(data[:payload + size - 1])
PY
    if (cd "$dir" && "$OUT_BIN" input.jpg pin.txt > recover.log 2>&1); then
        echo "jdv_out accepted truncated ciphertext" >&2
        return 1
    fi
    if find "$dir" -maxdepth 1 -type f -name 'payload_text*' -print -quit | grep -q .; then
        echo "truncated recovery left plaintext output" >&2
        return 1
    fi
    assert_no_stage_files "$dir"
}

test_pin_delivery_failure_is_transactional() {
    local dir="$WORK/full_stdout"
    local found
    [[ -e /dev/full ]] || return 77
    mkdir -p "$dir"
    if (cd "$dir" && "$IN_BIN" "$COVER" "$PAYLOAD" > /dev/full 2> conceal.err); then
        echo "jdv_in succeeded although its PIN could not be delivered" >&2
        return 1
    fi
    found="$(find "$dir" -maxdepth 1 \
        \( -name 'jrif_*.jpg' -o -name '.jdvrif_*' -o -name '.*.jdvrif_tmp_*' \) \
        -print -quit)"
    if [[ -n "$found" ]]; then
        echo "jdv_in committed or leaked output after PIN delivery failure: $found" >&2
        return 1
    fi
}

test_oversized_jpeg_dimensions() {
    local dir="$WORK/huge_dimensions"
    mkdir -p "$dir"
    python3 - "$COVER" "$dir/huge.jpg" <<'PY'
import sys
from pathlib import Path

data = bytearray(Path(sys.argv[1]).read_bytes())
pos = 2
sof = None
while pos + 4 <= len(data):
    if data[pos] != 0xFF:
        pos += 1
        continue
    while pos < len(data) and data[pos] == 0xFF:
        pos += 1
    marker = data[pos]
    pos += 1
    if marker in (0x01, 0xD8, 0xD9) or 0xD0 <= marker <= 0xD7:
        continue
    if marker == 0xDA:
        break
    length = int.from_bytes(data[pos:pos + 2], "big")
    if marker in {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                  0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}:
        sof = pos + 2
        break
    pos += length
if sof is None:
    raise SystemExit("SOF marker not found")
data[sof + 1:sof + 3] = (65000).to_bytes(2, "big")
data[sof + 3:sof + 5] = (65000).to_bytes(2, "big")
Path(sys.argv[2]).write_bytes(data)
PY
    if (cd "$dir" && "$IN_BIN" huge.jpg "$PAYLOAD" > conceal.log 2>&1); then
        echo "oversized JPEG dimensions were accepted" >&2
        return 1
    fi
    grep -Eiq 'dimension|pixel|too large|maximum' "$dir/conceal.log"
    assert_no_stage_files "$dir"
}

test_cmyk_cover_rejected() {
    local dir="$WORK/cmyk"
    if ! python3 -c 'import PIL' >/dev/null 2>&1; then
        return 77
    fi
    mkdir -p "$dir"
    python3 - "$dir/cmyk.jpg" <<'PY'
import sys
from PIL import Image

Image.new("CMYK", (500, 500), (0, 255, 255, 0)).save(
    sys.argv[1], format="JPEG", quality=90
)
PY
    if (cd "$dir" && "$IN_BIN" cmyk.jpg "$PAYLOAD" > conceal.log 2>&1); then
        echo "CMYK cover was accepted" >&2
        return 1
    fi
    grep -Eiq 'CMYK|YCCK|color space|unsupported' "$dir/conceal.log"
}

test_post_transform_dimensions() {
    local dir="$WORK/trimmed_dimensions"
    local magick_bin
    magick_bin="$(command -v magick || command -v convert || true)"
    if [[ -z "$magick_bin" ]]; then
        return 77
    fi
    mkdir -p "$dir"
    "$magick_bin" -size 400x401 gradient:red-blue -colorspace sRGB \
        -sampling-factor 4:1:1 -quality 90 "$dir/base.jpg"
    python3 - "$dir/base.jpg" "$dir/oriented.jpg" <<'PY'
import struct
import sys
from pathlib import Path

data = Path(sys.argv[1]).read_bytes()
if not data.startswith(b"\xff\xd8"):
    raise SystemExit("not a JPEG")
tiff = (
    b"II\x2a\x00" + struct.pack("<I", 8) + struct.pack("<H", 1) +
    struct.pack("<HHI", 0x0112, 3, 1) + struct.pack("<H", 2) + b"\x00\x00" +
    struct.pack("<I", 0)
)
payload = b"Exif\x00\x00" + tiff
app1 = b"\xff\xe1" + struct.pack(">H", len(payload) + 2) + payload
Path(sys.argv[2]).write_bytes(data[:2] + app1 + data[2:])
PY
    if (cd "$dir" && "$IN_BIN" oriented.jpg "$PAYLOAD" > conceal.log 2>&1); then
        echo "cover trimmed below 400px was accepted" >&2
        return 1
    fi
    grep -Eiq 'dimension|too small|at least 400' "$dir/conceal.log"
    assert_no_stage_files "$dir"
}

test_referenced_nonzero_dqt_quality() {
    local dir="$WORK/nonzero_dqt"
    if ! python3 -c 'import PIL' >/dev/null 2>&1; then
        return 77
    fi
    mkdir -p "$dir"
    python3 - "$dir/dqt1.jpg" <<'PY'
import io
import sys
from pathlib import Path
from PIL import Image

buffer = io.BytesIO()
Image.new("L", (500, 500), 128).save(buffer, format="JPEG", quality=100)
data = bytearray(buffer.getvalue())
pos = 2
changed_dqt = False
changed_sof = False
while pos + 4 <= len(data):
    if data[pos] != 0xFF:
        pos += 1
        continue
    while pos < len(data) and data[pos] == 0xFF:
        pos += 1
    marker = data[pos]
    pos += 1
    if marker in (0x01, 0xD8, 0xD9) or 0xD0 <= marker <= 0xD7:
        continue
    if marker == 0xDA:
        break
    length = int.from_bytes(data[pos:pos + 2], "big")
    payload = pos + 2
    end = pos + length
    if marker == 0xDB:
        cursor = payload
        while cursor < end:
            header = data[cursor]
            table_size = 128 if header >> 4 else 64
            if (header & 0x0F) == 0:
                data[cursor] = (header & 0xF0) | 1
                changed_dqt = True
            cursor += 1 + table_size
    elif marker in {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                    0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}:
        components = data[payload + 5]
        for index in range(components):
            qsel = payload + 6 + index * 3 + 2
            if data[qsel] == 0:
                data[qsel] = 1
                changed_sof = True
    pos = end
if not (changed_dqt and changed_sof):
    raise SystemExit("failed to build nonzero-DQT fixture")
Path(sys.argv[1]).write_bytes(data)
PY
    if (cd "$dir" && "$IN_BIN" dqt1.jpg "$PAYLOAD" > conceal.log 2>&1); then
        echo "quality-100 cover using DQT table 1 was accepted" >&2
        return 1
    fi
    grep -Eiq 'quality.*exceeds|quality.*maximum' "$dir/conceal.log"
    assert_no_stage_files "$dir"
}

test_signal_cleans_compression_stage() {
    local dir="$WORK/signal_cleanup"
    local pid status seen=0
    command -v truncate >/dev/null 2>&1 || return 77
    mkdir -p "$dir"
    truncate -s "$((512 * 1024 * 1024))" "$dir/source.bin"
    (
        cd "$dir"
        exec "$IN_BIN" "$COVER" source.bin > conceal.log 2>&1
    ) &
    pid=$!

    for ((attempt = 0; attempt < 1000; ++attempt)); do
        if find "$dir" -maxdepth 1 -type f -name '.jdvrif_comp_*' -print -quit | grep -q .; then
            seen=1
            kill -TERM "$pid"
            break
        fi
        if ! kill -0 "$pid" 2>/dev/null; then break; fi
        sleep 0.01
    done
    if [[ "$seen" -eq 0 ]]; then
        if kill -0 "$pid" 2>/dev/null; then kill -TERM "$pid"; fi
        wait "$pid" 2>/dev/null || true
        echo "did not observe a compression stage before jdv_in exited" >&2
        return 1
    fi

    set +e
    wait "$pid"
    status=$?
    set -e
    if [[ "$status" -eq 0 ]]; then
        echo "signal-interrupted jdv_in returned success" >&2
        return 1
    fi
    assert_no_stage_files "$dir"
    if find "$dir" -maxdepth 1 -type f -name 'jrif_*.jpg' -print -quit | grep -q .; then
        echo "signal-interrupted jdv_in committed an output image" >&2
        return 1
    fi
}

test_dangling_symlink_collision() {
    local dir="$WORK/dangling_symlink"
    local recovered
    mkdir -p "$dir"
    cp "$DEFAULT_IMAGE" "$dir/input.jpg"
    cp "$DEFAULT_PIN_FILE" "$dir/pin.txt"
    ln -s missing-target "$dir/payload_text.txt"
    (cd "$dir" && "$OUT_BIN" input.jpg pin.txt > recover.log 2>&1)
    recovered="$(extract_recovered_file "$dir/recover.log")"
    [[ "$recovered" == "payload_text_1.txt" ]] || {
        echo "expected payload_text_1.txt, got ${recovered:-<none>}" >&2
        return 1
    }
    [[ -L "$dir/payload_text.txt" ]]
    [[ "$(readlink "$dir/payload_text.txt")" == "missing-target" ]]
    cmp -s "$dir/$recovered" "$PAYLOAD"
    assert_no_stage_files "$dir"
}

patch_declared_size() {
    python3 - "$1" "$2" "$3" <<'PY'
import sys
from pathlib import Path

data = bytearray(Path(sys.argv[1]).read_bytes())
mntr = data.find(b"mntrRGB")
if mntr < 8:
    raise SystemExit("ICC signature not found")
base = mntr - 8
data[base + 0x2CA:base + 0x2CE] = int(sys.argv[3]).to_bytes(4, "big")
Path(sys.argv[2]).write_bytes(data)
PY
}

assert_recovery_cap() {
    local source_image="$1"
    local source_pin="$2"
    local maximum="$3"
    local tag="$4"
    local dir="$WORK/$tag"
    mkdir -p "$dir/at_limit" "$dir/over_limit"
    cp "$source_pin" "$dir/pin.txt"
    patch_declared_size "$source_image" "$dir/at_limit/input.jpg" "$maximum"
    patch_declared_size "$source_image" "$dir/over_limit/input.jpg" "$((maximum + 1))"

    if (cd "$dir/at_limit" && "$OUT_BIN" input.jpg ../pin.txt > recover.log 2>&1); then
        echo "synthetic at-limit fixture unexpectedly recovered" >&2
        return 1
    fi
    if grep -q 'exceeds the maximum allowed' "$dir/at_limit/recover.log"; then
        echo "$tag rejected its documented wiggle-room boundary" >&2
        return 1
    fi
    if (cd "$dir/over_limit" && "$OUT_BIN" input.jpg ../pin.txt > recover.log 2>&1); then
        echo "$tag accepted a declaration over its recovery cap" >&2
        return 1
    fi
    grep -q 'exceeds the maximum allowed' "$dir/over_limit/recover.log"
    assert_no_stage_files "$dir/at_limit"
    assert_no_stage_files "$dir/over_limit"
}

test_default_recovery_wiggle_room() {
    assert_recovery_cap "$DEFAULT_IMAGE" "$DEFAULT_PIN_FILE" \
        "$((2 * 1024 * 1024 * 1024 + 50 * 1024 * 1024))" default_size_boundary
}

test_reddit_recovery_wiggle_room() {
    assert_recovery_cap "$REDDIT_IMAGE" "$REDDIT_PIN_FILE" \
        "$((20 * 1024 * 1024 + 2 * 1024 * 1024))" reddit_size_boundary
}

PASS=0
FAIL=0
SKIP=0
run_test() {
    local name="$1"
    shift
    local rc
    if (set -euo pipefail; "$@"); then
        echo "[PASS] $name"
        PASS=$((PASS + 1))
    else
        rc=$?
        if [[ "$rc" -eq 77 ]]; then
            echo "[SKIP] $name"
            SKIP=$((SKIP + 1))
        else
            echo "[FAIL] $name" >&2
            FAIL=$((FAIL + 1))
        fi
    fi
}

run_test authenticated_compression_mode test_authenticated_compression_mode
run_test wrong_pin_no_plaintext test_wrong_pin_leaves_no_plaintext
run_test oversized_pin_file test_oversized_pin_file_rejected
run_test truncated_ciphertext test_truncated_ciphertext
run_test transactional_pin_delivery test_pin_delivery_failure_is_transactional
run_test oversized_jpeg_dimensions test_oversized_jpeg_dimensions
run_test cmyk_cover_rejected test_cmyk_cover_rejected
run_test post_transform_dimensions test_post_transform_dimensions
run_test referenced_nonzero_dqt test_referenced_nonzero_dqt_quality
run_test dangling_symlink_collision test_dangling_symlink_collision
run_test default_recovery_wiggle_room test_default_recovery_wiggle_room
run_test reddit_recovery_wiggle_room test_reddit_recovery_wiggle_room
run_test compression_stage_sigterm test_signal_cleans_compression_stage

echo
echo "Security smoke summary: PASS=$PASS FAIL=$FAIL SKIP=$SKIP"
echo "jdv_in:  $IN_BIN"
echo "jdv_out: $OUT_BIN"
[[ "$FAIL" -eq 0 ]]
