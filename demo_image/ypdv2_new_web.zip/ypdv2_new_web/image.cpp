#include "image.h"
#include "compression.h"
#include "encryption.h"
#include "io_utils.h"
#include "lodepng/lodepng_config.h"
#include "lodepng/lodepng.h"
#include "lodepng/lodepng_zlib_adapter.h"
#include "png_utils.h"

#include <zlib.h>

#include <algorithm>
#include <array>
#include <cstring>
#include <format>
#include <limits>
#include <optional>
#include <print>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string_view>
#include <vector>

namespace {

constexpr Byte
	INDEXED_PLTE   = 3,
	TRUECOLOR_RGB  = 2,
	TRUECOLOR_RGBA = 6;

// TYPE_IHDR/IDAT/ICCP/IEND/tRNS and the PNG/IHDR sizes come from png_utils.h.
constexpr std::uint32_t
	TYPE_PLTE = 0x504C5445u,
	TYPE_CHRM = 0x6348524Du,
	TYPE_GAMA = 0x67414D41u,
	TYPE_SRGB = 0x73524742u,
	TYPE_SBIT = 0x73424954u,
	TYPE_CICP = 0x63494350u,
	TYPE_MDCV = 0x6D444356u,
	TYPE_CLLI = 0x634C4C49u,
	TYPE_ACTL = 0x6163544Cu,
	TYPE_FCTL = 0x6663544Cu,
	TYPE_FDAT = 0x66644154u;

[[nodiscard]] constexpr std::uint32_t packRgbaKey(Byte red, Byte green, Byte blue, Byte alpha) {
	return
		(static_cast<std::uint32_t>(red) << 24)   |
		(static_cast<std::uint32_t>(green) << 16) |
		(static_cast<std::uint32_t>(blue) << 8)   |
		 static_cast<std::uint32_t>(alpha);
}

struct DecodedImageForOptimization {
	vBytes image{};
	unsigned width{};
	unsigned height{};
	LodePNGColorStats stats{};
	Byte png_color_type{};
	Byte png_bit_depth{};
	LodePNGColorType raw_color_type{};
};

[[nodiscard]] constexpr bool isApngChunk(std::uint32_t type) {
	return type == TYPE_ACTL || type == TYPE_FCTL || type == TYPE_FDAT;
}

[[nodiscard]] constexpr bool isColorMetadataChunk(std::uint32_t type) {
	return
		type == TYPE_CHRM ||
		type == TYPE_GAMA ||
		type == TYPE_ICCP ||
		type == TYPE_SRGB ||
		type == TYPE_SBIT ||
		type == TYPE_CICP ||
		type == TYPE_MDCV ||
		type == TYPE_CLLI;
}

// A previous pdvrdt Mastodon payload must be removed when its image is reused as
// a cover, while a genuine ICC profile must be preserved. findPdvrdtIccpPayload()
// is the shared decision the recover side uses, so the two can never disagree.
[[nodiscard]] bool looksLikePdvrdtIccp(std::span<const Byte> chunk_data) {
	return findPdvrdtIccpPayload(chunk_data).has_value();
}

[[nodiscard]] bool looksLikePdvrdtIdat(std::span<const Byte> chunk_data) {
	return bytesEqualAt(chunk_data, 0, PDVRDT_IDAT_PREFIX) &&
		hasPdvrdtProfileMarkers(chunk_data.subspan(PDVRDT_IDAT_PREFIX.size()), DEFAULT_OFFSETS);
}

// sBIT's length is fixed by the image's color type (PNG spec 11.3.3). Zero for a
// color type that has no valid sBIT, which readRequiredIhdr()/the geometry
// preflight have already ruled out by the time this runs.
[[nodiscard]] constexpr std::size_t sbitLengthForColorType(Byte color_type) {
	switch (color_type) {
		case 0: return 1;  // greyscale
		case 2: return 3;  // truecolor
		case 3: return 3;  // indexed -- significance of the palette's RGB samples
		case 4: return 2;  // greyscale + alpha
		case 6: return 4;  // truecolor + alpha
		default: return 0;
	}
}

// Every color-metadata chunk pdvrdt keeps is copied into the output verbatim,
// byte range and all. lodepng never looks at them
// (LODEPNG_NO_COMPILE_ANCILLARY_CHUNKS) and readPngChunk() only checks the CRC,
// so without this a cover can hand pdvrdt a malformed chunk that it then
// faithfully re-emits -- producing an image that fails PNG validators through no
// fault of the payload, and giving the cover an unvalidated channel for planting
// arbitrary bytes in whatever gets shared. Each chunk's length (and, where it is
// cheap, its contents) is checked against the spec here, once, in the preflight
// both output paths run.
void requireValidColorMetadataChunk(const PngChunkView& chunk, Byte color_type, Byte bit_depth) {
	const auto reject = [](std::string_view detail) static {
		throw std::runtime_error(std::format("PNG Error: Invalid color metadata. {}", detail));
	};
	const auto requireLength = [&](std::size_t expected, std::string_view name) {
		if (chunk.length != expected) {
			reject(std::format("{} chunk must be {} bytes.", name, expected));
		}
	};

	switch (chunk.type) {
		case TYPE_CHRM: requireLength(32, "cHRM"); break;
		case TYPE_GAMA: requireLength(4,  "gAMA"); break;
		case TYPE_CICP: requireLength(4,  "cICP"); break;
		case TYPE_MDCV: requireLength(24, "mDCv"); break;
		case TYPE_CLLI: requireLength(8,  "cLLi"); break;
		case TYPE_SRGB:
			// Spelt out rather than requireLength() + a read, so the bounds of the
			// data access are visible at the point it happens.
			if (chunk.length != 1) {
				reject("sRGB chunk must be 1 byte.");
			} else if (chunk.data[0] > 3) {
				reject("sRGB rendering intent must be 0-3.");
			}
			break;
		case TYPE_SBIT: {
			const std::size_t expected = sbitLengthForColorType(color_type);
			if (expected == 0 || chunk.length != expected) {
				reject(std::format(
					"sBIT chunk must be {} bytes for color type {}.",
					expected, static_cast<unsigned>(color_type)));
			}
			// A palette's entries are 8-bit samples whatever the image's bit
			// depth, which is only the width of the index.
			const Byte sample_bits = (color_type == INDEXED_PLTE) ? Byte{8} : bit_depth;
			for (const Byte significant_bits : chunk.data) {
				if (significant_bits == 0 || significant_bits > sample_bits) {
					reject(std::format(
						"sBIT significant-bit counts must be 1-{}.",
						static_cast<unsigned>(sample_bits)));
				}
			}
			break;
		}
		case TYPE_ICCP: {
			// Profile name (1-79 bytes), NUL, compression method, deflate stream.
			const auto separator = std::ranges::find(chunk.data, Byte{0});
			const std::size_t name_length =
				static_cast<std::size_t>(separator - chunk.data.begin());
			if (separator == chunk.data.end() || name_length == 0 || name_length > 79) {
				reject("iCCP profile name must be 1-79 bytes followed by a null separator.");
			} else if (chunk.length < name_length + 3) {
				reject("iCCP chunk carries no compressed profile.");
			} else if (chunk.data[name_length + 1] != 0) {
				reject("iCCP compression method must be 0 (deflate).");
			}
			break;
		}
		default: break;
	}
}

void validateStaticPngChunks(
	std::span<const Byte> png,
	std::size_t first_chunk_pos,
	Byte color_type,
	Byte bit_depth) {

	bool has_iccp = false;
	bool has_srgb = false;
	bool seen_idat = false;

	forEachChunkToIend(png, first_chunk_pos, [&](const PngChunkView& chunk) {
		if (isApngChunk(chunk.type)) {
			throw std::runtime_error("PNG Error: APNG covers are not supported.");
		}
		if (chunk.type == TYPE_IDAT) {
			seen_idat = true;
		} else if (seen_idat && (chunk.type == TYPE_PLTE || chunk.type == TYPE_TRNS)) {
			// PNG spec 5.6: both must precede the image data. Decoders disagree on
			// what a late one means, and keeping it would split the IDAT run the
			// default-mode payload chunk is appended to.
			throw std::runtime_error(
				"PNG Error: Invalid chunk order. PLTE/tRNS chunk found after image data.");
		}
		if (isColorMetadataChunk(chunk.type)) {
			requireValidColorMetadataChunk(chunk, color_type, bit_depth);
		}
		if (chunk.type == TYPE_ICCP) {
			if (has_iccp || has_srgb) {
				throw std::runtime_error(
					"PNG Error: Invalid color metadata. Duplicate iCCP or conflicting sRGB chunk.");
			}
			has_iccp = true;
		} else if (chunk.type == TYPE_SRGB) {
			if (has_srgb || has_iccp) {
				throw std::runtime_error(
					"PNG Error: Invalid color metadata. Duplicate sRGB or conflicting iCCP chunk.");
			}
			has_srgb = true;
		}
	});
}

} // namespace

void preflightPngDecode(std::span<const Byte> png, std::uint32_t max_cover_dimension) {
	requireSpanRange(png, 0, PNG_HEADER_SIZE + PNG_CHUNK_OVERHEAD + IHDR_DATA_SIZE,
		"PNG Error: File too small to contain valid PNG structure.");
	const PngChunkView ihdr = readRequiredIhdr(png);

	// The cover-dimension limit is mode policy and comes first, so an oversized
	// cover is named as such: the same image would otherwise trip the decoder's
	// byte ceiling below and be reported as a generic safety-limit failure,
	// which says nothing about what to do about it.
	const std::uint32_t
		width  = getValue(ihdr.data, 0),
		height = getValue(ihdr.data, 4);
	if (width > max_cover_dimension || height > max_cover_dimension) {
		throw std::runtime_error(std::format(
			"Image File Error: Cover image dimensions of {}x{} exceed the maximum of {}x{} for this conceal mode.",
			width, height, max_cover_dimension, max_cover_dimension));
	}

	// The geometry bound lives in png_utils so the recover-only binary can reach
	// it without linking this file; the chunk policy below is cover-image policy
	// and stays here.
	requirePngGeometryWithinDecodeLimit(ihdr);
	validateStaticPngChunks(
		png,
		ihdr.offset + ihdr.total_size,
		ihdr.data[9],   // color type
		ihdr.data[8]);  // bit depth
}

namespace {

// Appends one small metadata chunk (at most 4 data bytes), CRC and all.
void appendSmallChunk(vBytes& chunks, std::uint32_t type, std::span<const Byte> data) {
	constexpr std::size_t MAX_DATA_SIZE = 4;
	if (data.size() > MAX_DATA_SIZE) {
		throw std::runtime_error("PNG Error: Invalid color metadata size.");
	}
	std::array<Byte, 4 + 4 + MAX_DATA_SIZE + 4> chunk{};
	updateValue(chunk, 0, static_cast<std::uint32_t>(data.size()));
	updateValue(chunk, 4, type);
	std::ranges::copy(data, chunk.begin() + 8);

	const std::span<const Byte> type_and_data(chunk.data() + 4, 4 + data.size());
	updateValue(chunk, 8 + data.size(), pdvrdtCrc32Update(0, type_and_data));
	appendBytes(
		chunks,
		std::span<const Byte>(chunk).first(4 + 4 + data.size() + 4),
		"PNG Error: Color metadata size overflow.");
}

void appendPaletteSbitFromRgba(
	vBytes& chunks,
	std::span<const Byte> rgba_sbit) {

	constexpr std::size_t
		RGBA_SBIT_SIZE    = 4,
		PALETTE_SBIT_SIZE = 3;

	if (rgba_sbit.size() != RGBA_SBIT_SIZE) {
		throw std::runtime_error("PNG Error: Invalid RGBA sBIT metadata.");
	}
	appendSmallChunk(chunks, TYPE_SBIT, rgba_sbit.first(PALETTE_SBIT_SIZE));
}

// The colour metadata chunks to carry over, concatenated whole (header, data,
// CRC) in their original order.
[[nodiscard]] vBytes collectColorMetadata(
	std::span<const Byte> png,
	bool palette_from_rgba) {

	const PngChunkView ihdr = readRequiredIhdr(png);
	vBytes metadata;
	bool seen_idat = false;

	forEachChunkToIend(png, ihdr.offset + ihdr.total_size, [&](const PngChunkView& chunk) {
		if (chunk.type == TYPE_IDAT) {
			seen_idat = true;
		}
		// Colour metadata after the image data is out of place (PNG spec 5.6) and
		// ignored by conforming decoders, so it is not carried forward either.
		if (!seen_idat &&
			isColorMetadataChunk(chunk.type) &&
			!(chunk.type == TYPE_ICCP && looksLikePdvrdtIccp(chunk.data))) {
			if (palette_from_rgba && chunk.type == TYPE_SBIT) {
				// Indexed PNG has no alpha field in sBIT. Preserve the RGB
				// significance fields and let tRNS carry the palette alpha values.
				appendPaletteSbitFromRgba(metadata, chunk.data);
			} else {
				appendBytes(
					metadata,
					png.subspan(chunk.offset, chunk.total_size),
					"PNG Error: Color metadata size overflow."
				);
			}
		}
	});
	return metadata;
}

void insertColorMetadataAfterIhdr(vBytes& png, std::span<const Byte> metadata_chunks) {
	if (metadata_chunks.empty()) {
		return;
	}

	const PngChunkView ihdr = readRequiredIhdr(png);
	const std::size_t insert_pos = ihdr.offset + ihdr.total_size;
	vBytes with_metadata;
	with_metadata.reserve(checkedAddSize(
		png.size(),
		metadata_chunks.size(),
		"PNG Error: Encoded image size overflow."
	));
	appendBytes(
		with_metadata,
		std::span<const Byte>(png).first(insert_pos),
		"PNG Error: Encoded image size overflow."
	);
	appendBytes(with_metadata, metadata_chunks, "PNG Error: Encoded image size overflow.");
	appendBytes(
		with_metadata,
		std::span<const Byte>(png).subspan(insert_pos),
		"PNG Error: Encoded image size overflow."
	);
	png = std::move(with_metadata);
}

void removeExistingPdvrdtIdatChunks(vBytes& image_file_vec) {
	requireSpanRange(image_file_vec, 0, PNG_HEADER_SIZE, "PNG Error: Invalid PNG signature.");
	const PngChunkView ihdr = readRequiredIhdr(image_file_vec);
	compactChunksAfterIhdr(image_file_vec, ihdr.offset + ihdr.total_size, [](const PngChunkView& chunk) static {
		return chunk.type != TYPE_IDAT || !looksLikePdvrdtIdat(chunk.data);
	});
}

// A full-avalanche 32-bit mixer (lowbias32): every bit of all four RGBA
// components affects every output bit, so any low-bit mask of it makes an even
// bucket choice. A bare multiply would not do: its low bits depend only on the
// key's low bits, i.e. on red and part of green.
[[nodiscard]] constexpr std::uint32_t mixColourKey(std::uint32_t key) noexcept {
	key ^= key >> 16;
	key *= 0x7feb352dU;
	key ^= key >> 15;
	key *= 0x846ca68bU;
	key ^= key >> 16;
	return key;
}

// Compact open-addressing hash from a 32-bit RGBA colour to its palette index.
// palette_size is capped at MAX_PALETTE_SIZE (256, validated in convertToPalette),
// so a 512-slot table stays at <= 50% load: ~1-2 probes per lookup, the whole
// table fits in L1, and there is no large allocation or zero-fill (unlike a
// 2^24-entry / 33 MiB direct LUT). Ported from pdvzip's PaletteIndexTable.
class PaletteIndexTable {
	static constexpr std::size_t TABLE_SIZE = 512;
	static constexpr std::size_t TABLE_MASK = TABLE_SIZE - 1;

	std::array<std::uint32_t, TABLE_SIZE> keys_{};
	std::array<Byte, TABLE_SIZE> values_{};
	std::array<bool, TABLE_SIZE> occupied_{};

	[[nodiscard]] static constexpr std::size_t hash(std::uint32_t key) {
		return static_cast<std::size_t>(mixColourKey(key)) & TABLE_MASK;
	}

public:
	void insertIfAbsent(std::uint32_t key, Byte value) {
		std::size_t slot = hash(key);
		for (std::size_t probe = 0; probe < TABLE_SIZE; ++probe) {
			if (!occupied_[slot]) {
				occupied_[slot] = true;
				keys_[slot] = key;
				values_[slot] = value;
				return;
			}
			if (keys_[slot] == key) {
				return;
			}
			slot = (slot + 1) & TABLE_MASK;
		}
		throw std::runtime_error("convertToPalette: Palette lookup table is full.");
	}

	[[nodiscard]] bool find(std::uint32_t key, Byte& value) const {
		std::size_t slot = hash(key);
		for (std::size_t probe = 0; probe < TABLE_SIZE; ++probe) {
			if (!occupied_[slot]) {
				return false;
			}
			if (keys_[slot] == key) {
				value = values_[slot];
				return true;
			}
			slot = (slot + 1) & TABLE_MASK;
		}
		return false;
	}
};

// Map every pixel to its palette index via the compact RGBA hash. Replaces the
// former direct-LUT (33 MiB) / sorted-binary-search split with a single path;
// keying on full RGBA also removes the opaque-only restriction the direct path
// required.
void mapPixelsToPalette(
	vBytes& indexed_image,
	const vBytes& image,
	const LodePNGColorStats& stats,
	std::size_t palette_size,
	std::size_t channels,
	bool has_alpha) {

	constexpr std::size_t RGBA_COMPONENTS = 4;
	constexpr Byte ALPHA_OPAQUE = 255;

	PaletteIndexTable color_to_index;
	for (const auto [i, src] :
			std::span(stats.palette).first(palette_size * RGBA_COMPONENTS)
				| std::views::chunk(RGBA_COMPONENTS)
				| std::views::enumerate) {
		color_to_index.insertIfAbsent(packRgbaKey(src[0], src[1], src[2], src[3]), static_cast<Byte>(i));
	}

	for (std::size_t i = 0; i < indexed_image.size(); ++i) {
		const std::size_t offset = i * channels;
		const std::uint32_t key = packRgbaKey(
			image[offset],
			image[offset + 1],
			image[offset + 2],
			has_alpha ? image[offset + 3] : ALPHA_OPAQUE
		);

		Byte palette_index = 0;
		if (!color_to_index.find(key, palette_index)) {
			throw std::runtime_error(std::format(
				"convertToPalette: Pixel {} has color 0x{:08X} not found in palette.",
				i, key));
		}
		indexed_image[i] = palette_index;
	}
}

void convertToPalette(
	vBytes& image_file_vec,
	const vBytes& image,
	unsigned width,
	unsigned height,
	const LodePNGColorStats& stats,
	LodePNGColorType raw_color_type,
	std::span<const Byte> color_metadata) {

	constexpr Byte PALETTE_BIT_DEPTH = 8;

	constexpr std::size_t
		RGBA_COMPONENTS  = 4,
		RGB_COMPONENTS   = 3,
		MAX_PALETTE_SIZE = 256;

	// Validate color type — this function only handles RGB and RGBA input.
	if (raw_color_type != LCT_RGB && raw_color_type != LCT_RGBA) {
		throw std::runtime_error(std::format(
			"convertToPalette: Unsupported color type {}. Expected RGB or RGBA.",
			static_cast<unsigned>(raw_color_type)));
	}

	const std::size_t palette_size = stats.numcolors;

	if (palette_size == 0) {
		throw std::runtime_error("convertToPalette: Palette is empty.");
	}
	if (palette_size > MAX_PALETTE_SIZE) {
		throw std::runtime_error(std::format(
			"convertToPalette: Palette has {} colors, exceeds maximum of {}.",
			palette_size, MAX_PALETTE_SIZE));
	}

	const std::size_t channels =
		(raw_color_type == LCT_RGBA) ? RGBA_COMPONENTS : RGB_COMPONENTS;

	// Map each pixel to its palette index.
	const std::size_t pixel_count = checkedMulSize(
		static_cast<std::size_t>(width),
		static_cast<std::size_t>(height),
		"Image Error: Pixel count overflow."
	);
	const std::size_t expected_image_size = checkedMulSize(
		pixel_count,
		channels,
		"Image Error: Decoded image size overflow."
	);
	if (image.size() != expected_image_size) {
		throw std::runtime_error("Image Error: Decoded image size does not match PNG dimensions.");
	}
	vBytes indexed_image(pixel_count);

	const bool has_alpha = (raw_color_type == LCT_RGBA);
	mapPixelsToPalette(indexed_image, image, stats, palette_size, channels, has_alpha);

	// Encode as 8-bit palette PNG.
	lodepng::State encode_state;
	lodepng_zlib_adapter::configureEncoder(encode_state);
	encode_state.info_raw.colortype       = LCT_PALETTE;
	encode_state.info_raw.bitdepth        = PALETTE_BIT_DEPTH;
	encode_state.info_png.color.colortype = LCT_PALETTE;
	encode_state.info_png.color.bitdepth  = PALETTE_BIT_DEPTH;
	encode_state.encoder.auto_convert     = 0;

	for (const auto p :
			std::span(stats.palette).first(palette_size * RGBA_COMPONENTS)
				| std::views::chunk(RGBA_COMPONENTS)) {
		unsigned error = lodepng_palette_add(&encode_state.info_png.color, p[0], p[1], p[2], p[3]);
		if (error) {
			throw std::runtime_error(std::format("LodePNG palette error {}: {}", error, lodepng_error_text(error)));
		}
		error = lodepng_palette_add(&encode_state.info_raw, p[0], p[1], p[2], p[3]);
		if (error) {
			throw std::runtime_error(std::format("LodePNG palette error {}: {}", error, lodepng_error_text(error)));
		}
	}

	vBytes output;
	unsigned error = lodepng::encode(output, indexed_image.data(), width, height, encode_state);
	if (error) {
		throw std::runtime_error(std::format("LodePNG encode error: {}", error));
	}
	insertColorMetadataAfterIhdr(output, color_metadata);
	image_file_vec = std::move(output);
}

void stripAndCopyChunks(vBytes& image_file_vec, Byte color_type) {
	constexpr std::size_t MIN_PNG_SIZE = PNG_HEADER_SIZE + PNG_CHUNK_OVERHEAD + IHDR_DATA_SIZE + PNG_CHUNK_OVERHEAD;

	if (image_file_vec.size() < MIN_PNG_SIZE) {
		throw std::runtime_error("PNG Error: File too small to contain valid PNG structure.");
	}
	const PngChunkView ihdr = readRequiredIhdr(image_file_vec);
	bool seen_idat = false;
	compactChunksAfterIhdr(image_file_vec, ihdr.offset + ihdr.total_size, [color_type, &seen_idat](const PngChunkView& chunk) {
		if (chunk.type == TYPE_IDAT) {
			seen_idat = true;
		}
		// Only IDAT and IEND may follow the image data here. validateStaticPngChunks()
		// has rejected a late PLTE/tRNS; late colour metadata is dropped (conforming
		// decoders ignore it). Anything kept between the last IDAT and IEND would
		// split the IDAT run once the default-mode payload chunk is appended.
		return
			(chunk.type == TYPE_PLTE && color_type == INDEXED_PLTE) ||
			chunk.type == TYPE_TRNS ||
			(!seen_idat &&
				isColorMetadataChunk(chunk.type) &&
				!(chunk.type == TYPE_ICCP && looksLikePdvrdtIccp(chunk.data))) ||
			// Any pdvrdt IDAT payload is already gone: optimizeImage() runs
			// removeExistingPdvrdtIdatChunks() before this. Re-testing here would
			// be dead weight on every IDAT of every cover.
			chunk.type == TYPE_IDAT ||
			chunk.type == TYPE_IEND;
	});
}

// Decode without interpreting failures, so the caller can repair a cover whose
// IDAT stream has trailing bytes and try once more. Reports lodepng's own error
// code; 0 on success.
[[nodiscard]] unsigned tryDecodePng(
	const vBytes& image_file_vec,
	lodepng::State& state,
	DecodedImageForOptimization& decoded,
	bool native_format) {

	lodepng_zlib_adapter::configureDecoder(state);
	// Native format: no RGBA8 conversion pass, and the pixel buffer stays at the
	// cover's own (smaller) size. The decode still inflates, unfilters and
	// validates every row, which is its real job for such a cover.
	state.decoder.color_convert = native_format ? 0 : 1;
	return lodepng::decode(decoded.image, decoded.width, decoded.height, state, image_file_vec);
}

// True as soon as `rgba` (RGBA8) shows more than 256 distinct colours -- more
// than a palette holds, which is all the colour statistics are wanted for
// unless a palette is possible. lodepng's own statistics pass cannot stop
// there: with an RGBA8 input it keeps scanning every pixel for transparency.
// A photograph typically passes 256 colours within its first rows.
[[nodiscard]] bool hasMoreThan256Colours(std::span<const Byte> rgba) noexcept {
	constexpr std::size_t SLOTS = 1024;  // open addressing, never more than 1/4 full
	constexpr std::size_t SLOT_MASK = SLOTS - 1;
	std::array<std::uint32_t, SLOTS> seen{};
	std::array<bool, SLOTS> used{};
	std::size_t distinct = 0;
	std::uint32_t previous = 0;
	for (std::size_t at = 0; at + 4 <= rgba.size(); at += 4) {
		const std::uint32_t colour =
			static_cast<std::uint32_t>(rgba[at]) |
			(static_cast<std::uint32_t>(rgba[at + 1]) << 8U) |
			(static_cast<std::uint32_t>(rgba[at + 2]) << 16U) |
			(static_cast<std::uint32_t>(rgba[at + 3]) << 24U);
		if (at != 0 && colour == previous) {
			continue;
		}
		previous = colour;
		std::size_t slot = mixColourKey(colour) & SLOT_MASK;
		while (used[slot] && seen[slot] != colour) {
			slot = (slot + 1U) & SLOT_MASK;
		}
		if (!used[slot]) {
			used[slot] = true;
			seen[slot] = colour;
			if (++distinct > 256) {
				return true;
			}
		}
	}
	return false;
}

[[nodiscard]] DecodedImageForOptimization decodeImageForOptimization(vBytes& image_file_vec) {
	// Only an 8-bit truecolor cover can be palettized, and only that case reads
	// the decoded pixels (for colour statistics, which want RGBA8). Every other
	// cover is decoded purely to validate it, so skip the RGBA8 conversion --
	// unless its native samples are wider than RGBA8, where converting keeps the
	// buffer smaller.
	const PngChunkView ihdr = readRequiredIhdr(image_file_vec);
	const Byte ihdr_bit_depth = ihdr.data[8];
	const Byte ihdr_color_type = ihdr.data[9];
	const bool may_palettize = ihdr_bit_depth == 8 &&
		(ihdr_color_type == TRUECOLOR_RGB || ihdr_color_type == TRUECOLOR_RGBA);
	const unsigned channels =
		ihdr_color_type == TRUECOLOR_RGBA ? 4U :
		ihdr_color_type == TRUECOLOR_RGB  ? 3U :
		ihdr_color_type == 4              ? 2U :  // greyscale + alpha
		1U;                                        // greyscale, indexed
	const bool native_format = !may_palettize && channels * ihdr_bit_depth <= 32U;

	lodepng::State state;
	DecodedImageForOptimization decoded;
	unsigned error = tryDecodePng(image_file_vec, state, decoded, native_format);

	// removeExistingPdvrdtIdatChunks() has already dropped any IDAT this tool
	// wrote, so leftover bytes mean some *other* tool appended one. Those bytes
	// sit past the end of the PNG's own zlib stream, so they are provably not
	// part of the picture: drop them and decode again rather than making the
	// user go and re-save the file.
	//
	// Done here, on the failure, rather than as a routine pre-pass: finding the
	// end of the stream costs a full inflate, and covers with a stray IDAT are
	// the rare case. A clean cover pays nothing for this.
	if (error == lodepng_zlib_adapter::ERROR_TRAILING_DATA && stripTrailingIdatData(image_file_vec)) {
		std::println(" Note: removed a stray IDAT chunk left in the cover image by another tool.");
		state = lodepng::State{};
		decoded = DecodedImageForOptimization{};
		error = tryDecodePng(image_file_vec, state, decoded, native_format);
	}

	if (error == lodepng_zlib_adapter::ERROR_TRAILING_DATA) {
		// Still trailing data after the repair (or nothing could be repaired):
		// the IDAT stream is not a complete zlib stream followed by junk, so
		// this is a genuinely malformed image rather than an appended chunk.
		throw std::runtime_error(
			"PNG Error: The cover image's compressed image data does not end where the PNG "
			"says it should, and the leftover bytes are not a stray chunk that can be removed. "
			"Re-save the image with a PNG editor and try again.");
	}
	if (error) {
		throw std::runtime_error(std::format("LodePNG decode error {}: {}", error, lodepng_error_text(error)));
	}

	lodepng_color_stats_init(&decoded.stats);
	decoded.png_color_type = static_cast<Byte>(state.info_png.color.colortype);
	decoded.png_bit_depth  = static_cast<Byte>(state.info_png.color.bitdepth);
	decoded.raw_color_type = state.info_raw.colortype;

	const bool can_use_rgba8_stats =
		decoded.png_bit_depth == 8 &&
		(decoded.png_color_type == TRUECOLOR_RGB || decoded.png_color_type == TRUECOLOR_RGBA);
	const bool decoded_as_rgba8 =
		state.info_raw.colortype == LCT_RGBA && state.info_raw.bitdepth == 8;
	if (can_use_rgba8_stats && decoded_as_rgba8 && hasMoreThan256Colours(decoded.image)) {
		// No palette possible; lodepng would report the same, capped at 257.
		decoded.stats.numcolors = 257;
	} else if (can_use_rgba8_stats) {
		decoded.stats.allow_palette   = 1;
		decoded.stats.allow_greyscale = 0;
		error = lodepng_compute_color_stats(
			&decoded.stats,
			decoded.image.data(),
			decoded.width,
			decoded.height,
			&state.info_raw
		);
		if (error) {
			throw std::runtime_error(std::format("LodePNG stats error: {}", error));
		}
	}
	return decoded;
}

[[nodiscard]] bool hasUnsupportedShareDimensions(unsigned width, unsigned height, uint16_t max_dim) {
	constexpr uint16_t MIN_DIMS = 68;
	return width < MIN_DIMS || height < MIN_DIMS || width > max_dim || height > max_dim;
}

// Mastodon's payload travels in an RGB ICC profile, and PNG does not allow an
// RGB profile on a greyscale image: libpng, for one, drops it -- and the
// payload with it. So a greyscale cover is re-encoded as truecolor, RGB or (with
// an alpha channel) RGBA, at the same sample depth; 1-, 2- and 4-bit greyscale
// become 8-bit, scaled the way every decoder displays them. The pixels look the
// same. tRNS and sBIT are rewritten for the new colour type; every other kept
// colour chunk means the same for either type.
void convertGreyscaleToTruecolor(vBytes& image_file_vec) {
	constexpr Byte GREYSCALE = 0, GREYSCALE_ALPHA = 4;

	const PngChunkView ihdr = readRequiredIhdr(image_file_vec);
	const Byte bit_depth = ihdr.data[8];
	const Byte color_type = ihdr.data[9];
	if (color_type != GREYSCALE && color_type != GREYSCALE_ALPHA) {
		return;
	}
	const bool has_alpha = color_type == GREYSCALE_ALPHA;
	const unsigned target_depth = bit_depth == 16 ? 16U : 8U;
	const LodePNGColorType target_type = has_alpha ? LCT_RGBA : LCT_RGB;

	// The colour chunks first (they precede the image data), sBIT widened to
	// one entry per colour channel.
	vBytes color_metadata;
	bool seen_idat = false;
	forEachChunkToIend(image_file_vec, ihdr.offset + ihdr.total_size, [&](const PngChunkView& chunk) {
		if (chunk.type == TYPE_IDAT) {
			seen_idat = true;
		}
		if (seen_idat || !isColorMetadataChunk(chunk.type)) {
			return;
		}
		if (chunk.type == TYPE_SBIT) {
			// Validated: one byte (grey), or two (grey, alpha). A 1/2/4-bit
			// count stays valid once the samples are 8-bit.
			const std::array<Byte, 4> widened{
				chunk.data[0], chunk.data[0], chunk.data[0], has_alpha ? chunk.data[1] : Byte{0}};
			appendSmallChunk(color_metadata, TYPE_SBIT,
				std::span<const Byte>(widened).first(has_alpha ? 4 : 3));
		} else {
			appendBytes(
				color_metadata,
				std::span<const Byte>(image_file_vec).subspan(chunk.offset, chunk.total_size),
				"PNG Error: Color metadata size overflow.");
		}
	});

	lodepng::State decode_state;
	lodepng_zlib_adapter::configureDecoder(decode_state);
	decode_state.info_raw.colortype = target_type;
	decode_state.info_raw.bitdepth = target_depth;
	vBytes pixels;
	unsigned width = 0;
	unsigned height = 0;
	unsigned error = lodepng::decode(pixels, width, height, decode_state, image_file_vec);
	if (error) {
		throw std::runtime_error(std::format("LodePNG decode error {}: {}", error, lodepng_error_text(error)));
	}

	lodepng::State encode_state;
	lodepng_zlib_adapter::configureEncoder(encode_state);
	for (LodePNGColorMode* mode : {&encode_state.info_raw, &encode_state.info_png.color}) {
		mode->colortype = target_type;
		mode->bitdepth = target_depth;
	}
	encode_state.encoder.auto_convert = 0;
	// A greyscale tRNS key becomes the equivalent RGB key, scaled with the
	// samples (an 8-bit-or-wider key keeps its value).
	const LodePNGColorMode& source = decode_state.info_png.color;
	if (!has_alpha && source.key_defined) {
		const unsigned key = bit_depth < 8
			? source.key_r * 255U / ((1U << bit_depth) - 1U)
			: source.key_r;
		for (LodePNGColorMode* mode : {&encode_state.info_raw, &encode_state.info_png.color}) {
			mode->key_defined = 1;
			mode->key_r = mode->key_g = mode->key_b = key;
		}
	}

	vBytes output;
	error = lodepng::encode(output, pixels, width, height, encode_state);
	if (error) {
		throw std::runtime_error(std::format("LodePNG encode error {}: {}", error, lodepng_error_text(error)));
	}
	vBytes{}.swap(pixels);
	insertColorMetadataAfterIhdr(output, color_metadata);
	image_file_vec = std::move(output);
}

} // namespace

bool optimizeImage(vBytes& image_file_vec) {
	constexpr uint16_t
		MAX_PLTE_DIMS  = 4096,
		MAX_RGB_DIMS   = 900,
		MIN_RGB_COLORS = 257;

	preflightPngDecode(image_file_vec, MAX_COVER_DIMENSION);
	removeExistingPdvrdtIdatChunks(image_file_vec);

	const DecodedImageForOptimization decoded = decodeImageForOptimization(image_file_vec);
	const Byte color_type = decoded.png_color_type;
	const bool is_truecolor = (color_type == TRUECOLOR_RGB || color_type == TRUECOLOR_RGBA);
	// Palette entries are 8-bit samples. Statistics from LodePNG's default RGBA8
	// decode cannot distinguish 16-bit values that share the same high byte, so
	// never use them to rewrite a 16-bit source.
	const bool can_palettize =
		is_truecolor &&
		decoded.png_bit_depth == 8 &&
		(decoded.stats.numcolors < MIN_RGB_COLORS);

	if (can_palettize) {
		const vBytes color_metadata = collectColorMetadata(
			image_file_vec,
			color_type == TRUECOLOR_RGBA
		);
		convertToPalette(
			image_file_vec,
			decoded.image,
			decoded.width,
			decoded.height,
			decoded.stats,
			decoded.raw_color_type,
			color_metadata
		);
		return hasUnsupportedShareDimensions(decoded.width, decoded.height, MAX_PLTE_DIMS);
	}

	const uint16_t max_dim = (color_type == INDEXED_PLTE) ? MAX_PLTE_DIMS : MAX_RGB_DIMS;
	stripAndCopyChunks(image_file_vec, color_type);
	return hasUnsupportedShareDimensions(decoded.width, decoded.height, max_dim);
}

void prepareCoverForRedditCarrier(vBytes& image_file_vec) {
	preflightPngDecode(image_file_vec, MAX_REDDIT_COVER_DIMENSION);
	// A stale pdvrdt IDAT payload in a reused cover sits after the real image
	// data, so leaving it would make the concatenated IDAT stream look like
	// trailing garbage to the decoder. Removing it by chunk here is exact and
	// costs a walk; letting decodeCarrier() discover it costs a whole extra
	// inflate to find where the real stream ends.
	removeExistingPdvrdtIdatChunks(image_file_vec);
}

void prepareImageForMastodonEmbedding(vBytes& image_file_vec) {
	const PngChunkView ihdr = readRequiredIhdr(image_file_vec);
	compactChunksAfterIhdr(
		image_file_vec,
		ihdr.offset + ihdr.total_size,
		[](const PngChunkView& chunk) static {
			// Mastodon embeds the encrypted profile in iCCP. PNG permits only one
			// iCCP and forbids combining it with sRGB, so those cover declarations
			// are replaced while all compatible color metadata remains intact.
			return chunk.type != TYPE_ICCP && chunk.type != TYPE_SRGB;
		}
	);
	convertGreyscaleToTruecolor(image_file_vec);
}
