#pragma once

#include "common.h"

#include <string>

struct ProgramArgs {
	fs::path image_file_path{};
	fs::path passphrase_file_path{};

	[[noreturn]] static void die(const std::string& usage);
	static ProgramArgs parse(int argc, char** argv);
};
