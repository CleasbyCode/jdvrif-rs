#pragma once

#include "common.h"

void concealData(vBytes& png_vec, Option option, const fs::path& image_file_path, const fs::path& data_file_path);
void displayRedditCapacity(vBytes& png_vec, const fs::path& image_file_path);
