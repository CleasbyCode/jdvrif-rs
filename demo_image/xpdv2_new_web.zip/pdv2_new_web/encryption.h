#pragma once

#include "common.h"

#include <cstddef>
#include <optional>

struct ProfileOffsets {
	std::size_t
		kdf_metadata,   // 56-byte metadata region (magic/alg/salt/nonce/random padding)
		encrypted_file;
};

inline constexpr ProfileOffsets
	MASTODON_OFFSETS = { 0x1BE, 0x1FE },
	DEFAULT_OFFSETS  = { 0x02D, 0x06E };

inline constexpr std::size_t
	KDF_METADATA_REGION_BYTES = 56,
	KDF_MAGIC_OFFSET          = 0,
	KDF_ALG_OFFSET            = 4,
	KDF_SENTINEL_OFFSET       = 5,
	KDF_SALT_OFFSET           = 8,
	KDF_NONCE_OFFSET          = 24;

inline constexpr Byte
	KDF_ALG_ARGON2ID13 = 1,
	KDF_SENTINEL       = 0xA5;

inline constexpr auto KDF_METADATA_MAGIC_V2 =
	std::to_array<Byte>({'K', 'D', 'F', '2'});

inline constexpr auto PDVRDT_SIG =
	std::to_array<Byte>({0xC6, 0x50, 0x3C, 0xEA, 0x5E, 0x9D, 0xF9});

inline constexpr std::size_t DEFAULT_PDV_SIG_OFFSET  = 101;
inline constexpr std::size_t MASTODON_PDV_SIG_OFFSET = 502;

[[nodiscard]] std::uint64_t encryptCompressedFileToProfile(
	vBytes& profile_vec,
	const fs::path& data_file_path,
	const std::string& data_filename,
	Option option,
	bool is_compressed_file,
	bool has_mastodon_option);

[[nodiscard]] std::optional<std::string> decryptDataFile(vBytes& png_vec, vBytes& pin_vec, bool is_mastodon_file);
