#include "common.h"
#include "args.h"
#include "file_utils.h"
#include "jpeg_process.h"
#include "jpeg_warning_check.h"

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstddef>
#include <exception>
#include <fcntl.h>
#include <format>
#include <iostream>
#include <limits>
#include <optional>
#include <print>
#include <random>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <system_error>

namespace {
    constexpr std::size_t JFIF_SIG_LENGTH = 20;
    constexpr std::size_t JFIF_COMMENT_BLOCK_INDEX = 0x0C;
    constexpr std::size_t SEGMENT_SIZE_FIELD_INDEX = 0x16;
    constexpr std::size_t PROFILE_SIZE_FIELD_INDEX = 0x26;
    constexpr std::size_t PWSH_INSERT_INDEX = 6;

    [[nodiscard]] std::size_t checkedAdd(std::size_t lhs, std::size_t rhs, std::string_view context) {
        if (lhs > std::numeric_limits<std::size_t>::max() - rhs) {
            throw std::runtime_error(std::format("{} size overflow.", context));
        }
        return lhs + rhs;
    }

    [[nodiscard]] std::size_t checkedSub(std::size_t lhs, std::size_t rhs, std::string_view context) {
        if (lhs < rhs) {
            throw std::runtime_error(std::format("{} size underflow.", context));
        }
        return lhs - rhs;
    }

    void writeBigEndian(vBytes& vec, std::size_t index, std::size_t value, std::size_t bytes) {
        if (bytes == 0 || bytes > sizeof(std::size_t)) {
            throw std::runtime_error("writeBigEndian: invalid byte count.");
        }
        if (index > vec.size() || bytes > vec.size() - index) {
            throw std::runtime_error("writeBigEndian: index out of bounds.");
        }
        if (bytes < sizeof(std::size_t) && value >= (1uz << (bytes * 8))) {
            throw std::runtime_error("writeBigEndian: value exceeds range for requested byte width.");
        }

        constexpr std::size_t BITS_PER_BYTE = 8;
        for (std::size_t byte_index = 0; byte_index < bytes; ++byte_index) {
            const std::size_t shift = (bytes - byte_index - 1) * BITS_PER_BYTE;
            vec[index + byte_index] = static_cast<Byte>((value >> shift) & 0xFF);
        }
    }

    constexpr auto ICC_PROFILE_TEMPLATE = std::to_array<Byte>({
        0xFF, 0xE2, 0x00, 0x00, 0x49, 0x43, 0x43, 0x5F, 0x50, 0x52, 0x4F, 0x46, 0x49, 0x4C, 0x45, 0x00, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x5F, 0x6A, 0x70, 0x77,
        0x73, 0x5F, 0x00, 0x00, 0x6D, 0x6E, 0x74, 0x72, 0x52, 0x47, 0x42, 0x20, 0x58, 0x59, 0x5A, 0x20, 0x07, 0xE2, 0x00, 0x03, 0x00, 0x14, 0x00, 0x09, 0x00, 0x0E,
        0x00, 0x1D, 0x61, 0x63, 0x73, 0x70, 0x4D, 0x53, 0x46, 0x54, 0x00, 0x00, 0x00, 0x00, 0x73, 0x61, 0x77, 0x73, 0x63, 0x74, 0x72, 0x6C, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF6, 0xD6, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0xD3, 0x2D, 0x68, 0x61, 0x6E, 0x64, 0xEB, 0x77,
        0x1F, 0x3C, 0xAA, 0x53, 0x51, 0x02, 0xE9, 0x3E, 0x28, 0x6C, 0x91, 0x46, 0xAE, 0x57, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x09, 0x64, 0x65, 0x73, 0x63, 0x00, 0x00,
        0x00, 0xF0, 0x00, 0x00, 0x00, 0x1C, 0x77, 0x74, 0x70, 0x74, 0x00, 0x00, 0x01, 0x0C, 0x00, 0x00, 0x00, 0x14, 0x72, 0x58, 0x59, 0x5A, 0x00, 0x00, 0x01, 0x20,
        0x00, 0x00, 0x00, 0x14, 0x67, 0x58, 0x59, 0x5A, 0x00, 0x00, 0x01, 0x34, 0x00, 0x00, 0x00, 0x14, 0x62, 0x58, 0x59, 0x5A, 0x00, 0x00, 0x01, 0x48, 0x00, 0x00,
        0x00, 0x14, 0x72, 0x54, 0x52, 0x43, 0x00, 0x00, 0x01, 0x5C, 0x00, 0x00, 0x00, 0x34, 0x67, 0x54, 0x52, 0x43, 0x00, 0x00, 0x01, 0x5C, 0x00, 0x00, 0x00, 0x34,
        0x62, 0x54, 0x52, 0x43, 0x00, 0x00, 0x01, 0x5C, 0x00, 0x00, 0x00, 0x34, 0x63, 0x70, 0x72, 0x74, 0x00, 0x00, 0x01, 0x90, 0x00, 0x00, 0x00, 0x01, 0x64, 0x65,
        0x73, 0x63, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x6E, 0x52, 0x47, 0x42, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x58, 0x59, 0x5A, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF3, 0x54, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x16, 0xC9, 0x58, 0x59, 0x5A, 0x20, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x6F, 0xA0, 0x00, 0x00, 0x38, 0xF2, 0x00, 0x00, 0x03, 0x8F, 0x58, 0x59, 0x5A, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x62, 0x96,
        0x00, 0x00, 0xB7, 0x89, 0x00, 0x00, 0x18, 0xDA, 0x58, 0x59, 0x5A, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x24, 0xA0, 0x00, 0x00, 0x0F, 0x85, 0x00, 0x00,
        0xB6, 0xC4, 0x63, 0x75, 0x72, 0x76, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x01, 0x07, 0x02, 0xB5, 0x05, 0x6B, 0x09, 0x36, 0x0E, 0x50,
        0x14, 0xB1, 0x1C, 0x80, 0x25, 0xC8, 0x30, 0xA1, 0x3D, 0x19, 0x4B, 0x40, 0x5B, 0x27, 0x6C, 0xDB, 0x80, 0x6B, 0x95, 0xE3, 0xAD, 0x50, 0xC6, 0xC2, 0xE2, 0x31,
        0xFF, 0xFF, 0x23, 0x3E, 0x63, 0x6C, 0x73, 0x3B, 0x0D, 0x0A, 0x3C, 0x23, 0x0D, 0x0A
    });

    [[nodiscard]] std::string randomOutputSuffix(std::random_device& rd) {
        constexpr std::uint64_t OUTPUT_SUFFIX_MASK = (std::uint64_t{1} << 52) - 1;
        std::uniform_int_distribution<std::uint64_t> dist(0, OUTPUT_SUFFIX_MASK);
        return std::format("{:013x}", dist(rd));
    }

    void unlinkOutputFileBestEffort(const std::string& output_filename) noexcept {
        constexpr int MAX_UNLINK_RETRIES = 16;
        for (int attempt = 0; attempt < MAX_UNLINK_RETRIES; ++attempt) {
            if (::unlink(output_filename.c_str()) == 0 || errno != EINTR) {
                return;
            }
        }
    }

    [[noreturn]] void unlinkAndThrow(const std::string& output_filename, std::string_view message) {
        unlinkOutputFileBestEffort(output_filename);
        throw std::runtime_error(std::string(message));
    }

    [[noreturn]] void unlinkAndThrow(const std::string& output_filename, std::string_view prefix, int error_code) {
        unlinkOutputFileBestEffort(output_filename);
        throw std::runtime_error(std::format("{}: {}", prefix, std::system_category().message(error_code)));
    }

    void writeOutputBytes(const std::string& output_filename, int fd, std::span<const Byte> bytes) {
        while (!bytes.empty()) {
            const auto chunk_size = std::min<std::size_t>(bytes.size(), static_cast<std::size_t>(std::numeric_limits<ssize_t>::max()));
            const auto bytes_written = ::write(fd, bytes.data(), chunk_size);

            if (bytes_written > 0) {
                bytes = bytes.subspan(static_cast<std::size_t>(bytes_written));
                continue;
            }
            if (bytes_written == 0) {
                unlinkAndThrow(output_filename, "Write Error: Failed to write complete output file.");
            }
            if (errno != EINTR) {
                unlinkAndThrow(output_filename, "Write Error: Failed to write output file", errno);
            }
        }
    }

    void syncOutputFile(const std::string& output_filename, int fd) {
        while (::fsync(fd) != 0) {
            const int error_code = errno;
            if (error_code == EINTR) {
                continue;
            }
            unlinkAndThrow(output_filename, "Write Error: Failed to sync output file", error_code);
        }
    }

    [[nodiscard]] bool startsWith(std::span<const Byte> bytes, std::span<const Byte> prefix) {
        return bytes.size() >= prefix.size() &&
            std::ranges::equal(bytes.first(prefix.size()), prefix);
    }

    void rejectUnsupportedTextEncoding(std::span<const Byte> bytes) {
        // UTF-32 BOMs share a prefix with UTF-16, so check 4-byte BOMs first.
        constexpr auto UTF32_LE_BOM = std::to_array<Byte>({ 0xFF, 0xFE, 0x00, 0x00 });
        constexpr auto UTF32_BE_BOM = std::to_array<Byte>({ 0x00, 0x00, 0xFE, 0xFF });
        constexpr auto UTF16_LE_BOM = std::to_array<Byte>({ 0xFF, 0xFE });
        constexpr auto UTF16_BE_BOM = std::to_array<Byte>({ 0xFE, 0xFF });

        const std::span<const Byte> view(bytes);
        if (startsWith(view, UTF32_LE_BOM) || startsWith(view, UTF32_BE_BOM)) {
            throw std::runtime_error(
                "Script File Error: PowerShell script is UTF-32 encoded. "
                "Re-save the script as UTF-8 (with or without BOM).");
        }
        if (startsWith(view, UTF16_LE_BOM) || startsWith(view, UTF16_BE_BOM)) {
            throw std::runtime_error(
                "Script File Error: PowerShell script is UTF-16 encoded. "
                "Re-save the script as UTF-8 (with or without BOM).");
        }
    }

    void stripUtf8Bom(vBytes& bytes) {
        constexpr auto BOM_SIG = std::to_array<Byte>({ 0xEF, 0xBB, 0xBF });

        if (bytes.size() >= BOM_SIG.size() &&
            std::ranges::equal(std::span<const Byte>(bytes).first(BOM_SIG.size()), BOM_SIG)) {
            bytes.erase(bytes.begin(), bytes.begin() + static_cast<std::ptrdiff_t>(BOM_SIG.size()));
        }
    }

    // The embedded script runs after a leading "cls;" in the polyglot, so a
    // param() block is never the first statement and named parameters (e.g.
    // -Music) cannot bind. Detect a leading param() block (after skipping
    // whitespace and #/<# #> comments) so we can warn the operator.
    [[nodiscard]] bool scriptStartsWithParamBlock(std::span<const Byte> script) {
        const auto is_space = [](Byte b) static {
            return b == ' ' || b == '\t' || b == '\r' || b == '\n';
        };
        const auto to_lower = [](Byte b) static -> Byte {
            return (b >= 'A' && b <= 'Z') ? static_cast<Byte>(b + 32) : b;
        };

        const std::size_t n = script.size();
        std::size_t i = 0;
        while (i < n) {
            if (is_space(script[i])) {
                ++i;
            }
            else if (script[i] == '<' && i + 1 < n && script[i + 1] == '#') {
                i += 2;                                    // block comment: skip to "#>"
                while (i + 1 < n && !(script[i] == '#' && script[i + 1] == '>')) {
                    ++i;
                }
                if (i + 1 >= n) {
                    return false;                          // unterminated block comment
                }
                i += 2;
            }
            else if (script[i] == '#') {
                while (i < n && script[i] != '\n') {       // line comment: skip to EOL
                    ++i;
                }
            }
            else {
                break;                                     // first real (non-comment) token
            }
        }

        constexpr std::string_view PARAM_KEYWORD = "param";
        if (n - i < PARAM_KEYWORD.size()) {
            return false;
        }
        for (std::size_t k = 0; k < PARAM_KEYWORD.size(); ++k) {
            if (to_lower(script[i + k]) != static_cast<Byte>(PARAM_KEYWORD[k])) {
                return false;
            }
        }

        std::size_t j = i + PARAM_KEYWORD.size();
        while (j < n && is_space(script[j])) {
            ++j;
        }
        return j < n && script[j] == '(';
    }

    void warnIfScriptStartsWithParamBlock(std::span<const Byte> script) {
        if (!scriptStartsWithParamBlock(script)) {
            return;
        }
        std::println(std::cerr,
            "\nWarning: PowerShell script begins with a param() block.\n"
            "\nparam() cannot be the first statement in the polyglot: the embedded script runs after a leading \"cls;\".\n"
            "\nBest case the script runs but named parameters (e.g. -Music) are ignored.\n"
            "\nWorst case it fails to run at all.\n"
            "\nRead $args instead, e.g.: $Music = $args -contains '-Music'\n"
            "\nGenerating the image anyway.");
    }

    struct ProfileSizes {
        std::size_t segment_size = 0;
        std::size_t profile_size = 0;
    };

    [[nodiscard]] ProfileSizes calculateProfileSizes(std::size_t profile_byte_count) {
        const std::size_t segment_size = checkedSub(
            checkedAdd(profile_byte_count, JFIF_SIG_LENGTH, "Profile segment"),
            SEGMENT_SIZE_FIELD_INDEX,
            "Profile segment");

        return ProfileSizes{
            .segment_size = segment_size,
            .profile_size = checkedSub(segment_size, 16, "ICC profile")
        };
    }

    static_assert(ICC_PROFILE_TEMPLATE.size() == ICC_PROFILE_TEMPLATE_SIZE);

    constexpr auto PROFILE_COMMENT_CLOSE = std::to_array<Byte>({ '#', '>' });
    constexpr std::size_t PROFILE_COMMENT_CLOSE_OFFSET = static_cast<std::size_t>(
        std::ranges::search(ICC_PROFILE_TEMPLATE, PROFILE_COMMENT_CLOSE).begin() -
        ICC_PROFILE_TEMPLATE.begin());
    static_assert(PROFILE_COMMENT_CLOSE_OFFSET + PROFILE_COMMENT_CLOSE.size() <= ICC_PROFILE_TEMPLATE.size());

    void validateProfileSizes(const ProfileSizes& sizes) {
        if (sizes.segment_size > MAX_PROFILE_SEGMENT_SIZE) {
            throw std::runtime_error("Segment Size Error: The profile segment (FFE2) exceeds the maximum size limit of 10KB.");
        }

        if (sizes.segment_size > std::numeric_limits<uint16_t>::max()) {
            throw std::runtime_error("Segment Size Error: Segment size exceeds 16-bit field capacity.");
        }
    }

    [[nodiscard]] vBytes buildProfilePayload(std::span<const Byte> script_bytes) {
        constexpr std::size_t MIN_SCRIPT_PAYLOAD_SIZE = 10;
        if (script_bytes.size() < MIN_SCRIPT_PAYLOAD_SIZE) {
            throw std::runtime_error("Script File Error: PowerShell script is below minimum size.");
        }

        static_assert(ICC_PROFILE_TEMPLATE.size() >= PWSH_INSERT_INDEX);

        vBytes profile_vec(ICC_PROFILE_TEMPLATE.begin(), ICC_PROFILE_TEMPLATE.end());
        profile_vec.reserve(checkedAdd(profile_vec.size(), script_bytes.size(), "ICC profile"));
        profile_vec.insert(profile_vec.end() - PWSH_INSERT_INDEX, script_bytes.begin(), script_bytes.end());

        constexpr std::size_t PROFILE_SEGMENT_SIZE_FIELD = SEGMENT_SIZE_FIELD_INDEX - JFIF_SIG_LENGTH;
        constexpr std::size_t PROFILE_PROFILE_SIZE_FIELD = PROFILE_SIZE_FIELD_INDEX - JFIF_SIG_LENGTH;

        for (;;) {
            const ProfileSizes sizes = calculateProfileSizes(profile_vec.size());
            validateProfileSizes(sizes);
            writeBigEndian(profile_vec, PROFILE_SEGMENT_SIZE_FIELD, sizes.segment_size, 2);
            writeBigEndian(profile_vec, PROFILE_PROFILE_SIZE_FIELD, sizes.profile_size, 4);

            // A serialized size can itself spell "#>" (notably payload sizes
            // 8594 and 8610). Only the template's intended close may terminate
            // the opening comment. Pad inside the reopened trailing comment,
            // preserving both the script bytes and all ICC tag offsets.
            //
            // These collision sizes are fixed and lie well below the maximum
            // profile size, so padding headroom always exists in practice even
            // though MAX_SCRIPT_FILE_SIZE leaves none at the very top of the
            // range. validateProfileSizes() (called above, before any write)
            // still bounds this loop: if padding ever pushed the segment past
            // MAX_PROFILE_SEGMENT_SIZE it would throw rather than loop forever.
            const auto prefix = std::span<const Byte>(profile_vec).first(
                PROFILE_COMMENT_CLOSE_OFFSET + PROFILE_COMMENT_CLOSE.size());
            const auto first_close = std::ranges::search(prefix, PROFILE_COMMENT_CLOSE);
            if (static_cast<std::size_t>(first_close.begin() - prefix.begin()) == PROFILE_COMMENT_CLOSE_OFFSET) {
                break;
            }
            profile_vec.push_back(0);
        }

        return profile_vec;
    }

    [[nodiscard]] constexpr auto makeDefaultTailBytes() {
        return std::to_array<Byte>({
            0x9e, 0x23, 0x3e, 0x0d, 0x23, 0x00, 0x00, 0x20, 0x20, 0x00
        });
    }

    [[nodiscard]] constexpr auto makeAltTailBytes() {
        return std::to_array<Byte>({
            0x00, 0x20, 0x20, 0x00, 0x00, 0x23, 0x3E, 0x0D, 0x23, 0x9e
        });
    }

    // Walk actual markers, including entropy stuffing and restart markers. The
    // patch must fit wholly after the last header/restart and before final EOI.
    [[nodiscard]] bool tailPatchFits(std::span<const Byte> jpg, std::size_t count) {
        if (jpg.size() < 4 || jpg[0] != 0xFF || jpg[1] != 0xD8) return false;
        std::size_t pos = 2;
        std::size_t entropy_start = 0;
        bool in_scan = false;
        while (pos < jpg.size()) {
            if (in_scan && jpg[pos] != 0xFF) {
                ++pos;
                continue;
            }
            if (jpg[pos] != 0xFF) return false;
            const std::size_t marker_start = pos;
            while (pos < jpg.size() && jpg[pos] == 0xFF) ++pos;
            if (pos == jpg.size()) return false;
            const Byte marker = jpg[pos++];
            if (in_scan && marker == 0x00) continue;
            if (in_scan && marker >= 0xD0 && marker <= 0xD7) {
                entropy_start = pos;
                continue;
            }
            if (marker == 0xD9) {
                if (!in_scan || pos != jpg.size() || pos - marker_start != 2 ||
                    marker_start - entropy_start < count) return false;
                const std::size_t patch_start = marker_start - count;
                // Do not leave half of an FF/00 stuffed pair before the patch.
                return patch_start == entropy_start || jpg[patch_start - 1] != 0xFF;
            }
            in_scan = false;
            if (marker == 0x00 || marker == 0xD8 || marker == 0x01 ||
                (marker >= 0xD0 && marker <= 0xD7) || jpg.size() - pos < 2) return false;
            const std::size_t length = (static_cast<std::size_t>(jpg[pos]) << 8) | jpg[pos + 1];
            if (!jpegSegmentFits(pos, length, jpg.size())) return false;
            pos += length;
            if (marker == 0xDA) {
                in_scan = true;
                entropy_start = pos;
            }
        }
        return false;
    }

    void patchImageTail(vBytes& image_file_vec, Option option) {
        constexpr auto DEFAULT_BYTES = makeDefaultTailBytes();
        constexpr auto ALT_BYTES = makeAltTailBytes();
        constexpr auto JPEG_EOI = std::to_array<Byte>({ 0xFF, 0xD9 });

        constexpr std::size_t TAIL_OFFSET = JPEG_EOI.size();

        const std::span<const Byte> tail_bytes = [&] {
            switch (option) {
                case Option::Alt:
                    return std::span<const Byte>(ALT_BYTES);
                case Option::None:
                    return std::span<const Byte>(DEFAULT_BYTES);
            }
            throw std::runtime_error("Internal Error: Unknown tail patch option.");
        }();

        if (image_file_vec.size() < JFIF_SIG_LENGTH ||
            image_file_vec.size() < tail_bytes.size() + TAIL_OFFSET) {
            throw std::runtime_error("Image File Error: Image too small after processing to apply tail patch.");
        }

        if (!std::ranges::equal(
                std::span<const Byte>(image_file_vec).last(JPEG_EOI.size()),
                std::span<const Byte>(JPEG_EOI))) {
            throw std::runtime_error("Image File Error: Image does not end with a JPEG EOI marker.");
        }

        if (!tailPatchFits(image_file_vec, tail_bytes.size())) {
            throw std::runtime_error("Tail Patch Error: Final JPEG scan is too short or unsuitable for a safe tail patch. Try another cover image.");
        }

        std::ranges::reverse_copy(tail_bytes, image_file_vec.rbegin() + TAIL_OFFSET);
    }

    void writeJfifCommentBlock(vBytes& image_file_vec) {
        constexpr auto JFIF_COMMENT_BLOCK = std::to_array<Byte>({ 0x58, 0x54, 0x57, 0x0A, 0x3C, 0x23 });

        if (image_file_vec.size() < JFIF_COMMENT_BLOCK_INDEX + JFIF_COMMENT_BLOCK.size()) {
            throw std::runtime_error("Image File Error: Image too small to write JFIF comment block.");
        }

        std::ranges::copy(JFIF_COMMENT_BLOCK, image_file_vec.begin() + JFIF_COMMENT_BLOCK_INDEX);
    }

    [[nodiscard]] std::string writeOutputFile(std::span<const Byte> bytes) {
        constexpr mode_t OUTPUT_MODE = S_IRUSR | S_IWUSR;
        constexpr int OUTPUT_FLAGS = O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW;
        constexpr int MAX_OUTPUT_ATTEMPTS = 64;

        if (bytes.empty()) {
            throw std::runtime_error("Image File Error: Output image is empty.");
        }

        std::random_device rd;

        for (int attempt = 0; attempt < MAX_OUTPUT_ATTEMPTS; ++attempt) {
            std::string output_filename = std::format("jpws_{}.jpg", randomOutputSuffix(rd));
            UniqueFd output_fd(::open(output_filename.c_str(), OUTPUT_FLAGS, OUTPUT_MODE));

            if (output_fd.get() < 0) {
                if (errno == EEXIST) {
                    continue;
                }
                throw std::runtime_error(std::format("Write Error: Unable to create output file: {}", std::system_category().message(errno)));
            }

            writeOutputBytes(output_filename, output_fd.get(), bytes);
            syncOutputFile(output_filename, output_fd.get());

            const int raw_fd = output_fd.release();
            if (::close(raw_fd) != 0) {
                const int error_code = errno;
                unlinkAndThrow(output_filename, "Write Error: Failed to close output file", error_code);
            }

            return output_filename;
        }

        throw std::runtime_error("Write Error: Unable to create a unique output filename after multiple attempts.");
    }

    [[nodiscard]] vBytes buildPolyglotOutputBytes(std::span<const Byte> image_file_vec, std::span<const Byte> profile_vec) {
        if (image_file_vec.size() < JFIF_SIG_LENGTH) {
            throw std::runtime_error("Image File Error: Image too small to write output.");
        }

        const auto output_size = checkedAdd(image_file_vec.size(), profile_vec.size(), "Output image");
        if (output_size > MAX_IMAGE_FILE_SIZE) {
            throw std::runtime_error("Image File Error: Output image exceeds the 5 MiB size limit.");
        }
        vBytes output_vec;
        output_vec.reserve(output_size);
        output_vec.insert(output_vec.end(), image_file_vec.begin(), image_file_vec.begin() + static_cast<std::ptrdiff_t>(JFIF_SIG_LENGTH));
        output_vec.insert(output_vec.end(), profile_vec.begin(), profile_vec.end());
        output_vec.insert(output_vec.end(), image_file_vec.begin() + static_cast<std::ptrdiff_t>(JFIF_SIG_LENGTH), image_file_vec.end());
        return output_vec;
    }

    [[nodiscard]] vBytes buildValidatedOutput(
        std::span<const Byte> image, std::span<const Byte> profile, Option option) {
        vBytes output = buildPolyglotOutputBytes(image, profile);
        patchImageTail(output, option);
        writeJfifCommentBlock(output);
        const JpegWarningSummary warnings = inspectJpegWarnings(output);
        if (warnings.fatal_error) {
            throw std::runtime_error("Tail Patch Error: Patched JPEG cannot be decoded. Try another cover image.");
        }
        if (warnings.hasUnsafeTailWarning()) {
            std::println("\nTail validation reported recoverable JPEG decoding warnings; keeping cover image as-is (re-encode disabled).");
        }
        return output;
    }

}

int main(int argc, char** argv) {
    try {
        auto args_opt = ProgramArgs::parse(argc, argv);
        if (!args_opt) {
            return 0;
        }

        const auto& args = *args_opt;

        vBytes image_file_vec = readFile(args.image_file_path, FileTypeCheck::cover_image);
        vBytes pwsh_file_vec = readFile(args.pwsh_file_path, FileTypeCheck::script_file);

        rejectUnsupportedTextEncoding(pwsh_file_vec);
        stripUtf8Bom(pwsh_file_vec);
        warnIfScriptStartsWithParamBlock(pwsh_file_vec);

        vBytes profile_vec = buildProfilePayload(pwsh_file_vec);

        // ensureImageCompatible always re-encodes the cover (or throws), so the
        // image is unconditionally modified on return.
        ensureImageCompatible(image_file_vec, MAX_IMAGE_FILE_SIZE - profile_vec.size());
        std::println("");

        vBytes output_file_vec = buildValidatedOutput(image_file_vec, profile_vec, args.option);

        const std::size_t total_output_size = output_file_vec.size();
        const std::string output_filename = writeOutputFile(output_file_vec);

        std::println("\nSaved JPG-PowerShell polyglot image: {} ({} bytes).", output_filename, total_output_size);

        std::println("\nComment-block close sequences successfully removed from image.");
        std::println("\nPlease check to make sure size & quality of cover image is acceptable.");
        std::println("\nComplete!\n");
        return 0;
    }
    catch (const std::runtime_error& e) {
        std::println(std::cerr, "\n{}\n", e.what());
        return 1;
    }
    catch (const std::exception& e) {
        std::println(std::cerr, "\nUnexpected error: {}\n", e.what());
        return 1;
    }
}
