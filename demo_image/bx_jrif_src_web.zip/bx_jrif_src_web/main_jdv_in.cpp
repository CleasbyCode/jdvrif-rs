// JPG Data Vehicle (jdv_in) Created by Nicholas Cleasby (@CleasbyCode) 10/04/2023

#include "common.h"
#include "conceal.h"
#include "file_utils.h"
#include "program_args_in.h"
#include "signal_utils.h"

#include <iostream>
#include <print>
#include <stdexcept>

namespace {
[[nodiscard]] int run(int argc, char** argv) {
    throwIf(sodium_init() < 0, "Libsodium initialization failed!");
    auto args = ProgramArgs::parse(argc, argv);
    vBytes jpg_vec = readFile(args.image_file_path, FileTypeCheck::cover_image);
    concealData(jpg_vec, args.option, args.data_file_path);
    return 0;
}
} // namespace

int main(int argc, char** argv) {
    try {
        installProcessSignalHandlers();
        return run(argc, argv);
    } catch (const SignalCancellation& interruption) {
        reraiseSignalAfterCleanup(interruption.signalNumber());
    } catch (const std::exception& e) {
        std::println(std::cerr, "\n{}\n", e.what());
        return 1;
    } catch (...) {
        std::println(std::cerr, "\nUnknown fatal error.\n");
        return 1;
    }
}
