// Web argument-file interface and nonblocking FIFO regression tests.
#include "pdvzip.h"

#include <array>
#include <cerrno>
#include <csignal>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

namespace {
void require(bool condition, const char* message) {
	if (!condition) throw std::runtime_error(message);
}

struct TemporaryDirectory {
	fs::path path;
	TemporaryDirectory() {
		std::string pattern = (fs::temp_directory_path() / "pdvzip-web-args-XXXXXX").string();
		const char* result = ::mkdtemp(pattern.data());
		if (!result) throw std::runtime_error("mkdtemp failed");
		path = result;
	}
	~TemporaryDirectory() {
		std::error_code ec;
		fs::remove_all(path, ec);
	}
};

void writeText(const fs::path& path, const std::string& text) {
	std::ofstream output(path, std::ios::binary);
	output.write(text.data(), static_cast<std::streamsize>(text.size()));
	output.close();
	require(static_cast<bool>(output), "fixture write failed");
}

template<class Function>
void expectError(Function&& operation, std::string_view message) {
	try { operation(); }
	catch (const std::runtime_error& error) {
		require(std::string_view(error.what()).find(message) != std::string_view::npos,
			"unexpected error message");
		return;
	}
	throw std::runtime_error("expected rejection");
}

void testInvocation() {
	std::array<std::string, 5> values{"pdvzip", "cover.png", "input.zip", "linux.txt", "windows.txt"};
	std::array<char*, 5> argv{};
	for (std::size_t i = 0; i < values.size(); ++i) argv[i] = values[i].data();
	const auto args = ProgramArgs::parse(5, argv.data());
	require(args.image_file_path == values[1] && args.archive_file_path == values[2]
		&& args.linux_args_filename == values[3] && args.windows_args_filename == values[4],
		"web invocation lost one of its four paths");
	expectError([&] { (void)ProgramArgs::parse(3, argv.data()); }, "Usage:");
	argv[4] = nullptr;
	expectError([&] { (void)ProgramArgs::parse(5, argv.data()); }, "missing input path");
}

void testArgumentFiles(const fs::path& root) {
	const auto linux_file = root / "linux.txt";
	const auto windows_file = root / "windows.txt";
	const auto missing = root / "missing.txt";
	const std::string linux_text = R"("C:\Users\nick" "\d+" 'literal $HOME')";
	const std::string windows_text = R"("C:\Program Files\app" /flag)";
	writeText(linux_file, linux_text + "\r\n");
	writeText(windows_file, windows_text + "\n");
	for (const auto type : {FileType::PYTHON, FileType::POWERSHELL, FileType::BASH_SHELL, FileType::JAR}) {
		const auto args = loadArguments(type, linux_file, windows_file);
		require(args.linux_args == linux_text && args.windows_args == windows_text,
			"argument files changed quoting, backslashes, or newline trimming");
	}
	const auto absent = loadArguments(FileType::PYTHON, missing, "");
	require(absent.linux_args.empty() && absent.windows_args.empty(), "optional files must remain optional");
	writeText(linux_file, "");
	require(loadArguments(FileType::PYTHON, linux_file, "").linux_args.empty(), "empty file failed");
	writeText(linux_file, std::string(1024, 'a'));
	require(loadArguments(FileType::PYTHON, linux_file, "").linux_args.size() == 1024, "exact size cap failed");
	writeText(linux_file, std::string(1025, 'a'));
	expectError([&] { (void)loadArguments(FileType::PYTHON, linux_file, ""); }, "exceeds maximum length");
	expectError([&] { (void)loadArguments(FileType::PYTHON, "", linux_file); }, "exceeds maximum length");
	writeText(linux_file, linux_text);
	const auto link = root / "link.txt";
	fs::create_symlink(linux_file, link);
	expectError([&] { (void)loadArguments(FileType::PYTHON, link, ""); }, "Unable to open arguments file");
	expectError([&] { (void)loadArguments(FileType::PYTHON, root, ""); }, "not a regular file");
	expectError([&] { (void)loadArguments(FileType::PYTHON, "/dev/null", ""); }, "not a regular file");
	expectError([&] { (void)loadArguments(FileType::PYTHON, root / "control\n.txt", ""); }, "control characters");
	const auto linux_only = loadArguments(FileType::LINUX_EXECUTABLE, linux_file, root);
	require(linux_only.linux_args == linux_text && linux_only.windows_args.empty(), "Linux-only argument selection failed");
	const auto windows_only = loadArguments(FileType::WINDOWS_EXECUTABLE, root, windows_file);
	require(windows_only.linux_args.empty() && windows_only.windows_args == windows_text, "Windows-only argument selection failed");
	for (const auto type : {FileType::PDF, FileType::VIDEO_AUDIO, FileType::FOLDER, FileType::UNKNOWN_FILE_TYPE}) {
		const auto ignored = loadArguments(type, root, root);
		require(ignored.linux_args.empty() && ignored.windows_args.empty(), "non-program unexpectedly reads arguments");
	}
}

std::size_t descriptorCount() {
	return static_cast<std::size_t>(std::distance(fs::directory_iterator("/proc/self/fd"), fs::directory_iterator{}));
}

bool fifoRejected(const fs::path& fifo, bool windows) {
	const pid_t child = ::fork();
	require(child >= 0, "fork failed");
	if (child == 0) {
		::signal(SIGALRM, SIG_DFL);
		::alarm(2);
		try {
			const auto before = descriptorCount();
			for (int repeat = 0; repeat < 32; ++repeat) {
				expectError([&] {
					(void)loadArguments(FileType::PYTHON, windows ? fs::path{} : fifo, windows ? fifo : fs::path{});
				}, "not a regular file");
			}
			::_exit(before == descriptorCount() ? 0 : 2);
		} catch (...) { ::_exit(1); }
	}
	int status{};
	pid_t result;
	do { result = ::waitpid(child, &status, 0); } while (result < 0 && errno == EINTR);
	require(result == child, "waitpid failed");
	return WIFEXITED(status) && WEXITSTATUS(status) == 0;
}
} // namespace

int main() {
	try {
		TemporaryDirectory root;
		testInvocation();
		testArgumentFiles(root.path);
		const auto fifo = root.path / "arguments.txt";
		require(::mkfifo(fifo.c_str(), 0600) == 0, "mkfifo failed");
		const bool linux_rejected = fifoRejected(fifo, false);
		const bool windows_rejected = fifoRejected(fifo, true);
		require(linux_rejected && windows_rejected, "FIFO argument file blocked, leaked a descriptor, or was not rejected");
		std::cout << "All web argument-file tests passed.\n";
	} catch (const std::exception& error) {
		std::cerr << "FAIL: " << error.what() << '\n';
		return 1;
	}
}
