#include "encryption.h"
#include "compression.h"
#include "io_utils.h"
#include "key_codec.h"
#include "png_utils.h"

#include <algorithm>
#include <cstring>
#include <format>
#include <limits>
#include <new>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string_view>

namespace {
constexpr std::size_t STREAM_CHUNK_SIZE = 1 * 1024 * 1024;

using StreamHeader = std::array<Byte, crypto_secretstream_xchacha20poly1305_HEADERBYTES>;

struct KdfSecrets {
	Salt salt{};
	StreamHeader stream_header{};
};

static_assert(STREAM_FRAME_LEN_BYTES == sizeof(std::uint32_t),
	"The frame length is written by updateValue(), which encodes exactly 32 bits.");

[[nodiscard]] std::array<Byte, STREAM_FRAME_LEN_BYTES> encodeFrameLen(std::uint32_t frame_len) {
	std::array<Byte, STREAM_FRAME_LEN_BYTES> bytes{};
	updateValue(bytes, 0, frame_len);
	return bytes;
}

// Where an encrypted profile goes as it is built: appended to a vector, or
// handed piece by piece, in order, to a sink that streams it on (default-mode
// conceal writes it straight into the output file). Either way size() is the
// profile's length so far, which is what the output limit is checked against.
class VectorProfileOutput {
public:
	explicit VectorProfileOutput(vBytes& profile) : profile_(profile) {}
	[[nodiscard]] std::size_t size() const noexcept { return profile_.size(); }
	// The template is already in place in the vector.
	void emitHead(std::span<const Byte>) {}
	void append(std::span<const Byte> bytes) {
		appendBytes(profile_, bytes, "File Size Error: Encrypted output overflow.");
	}

private:
	vBytes& profile_;
};

class SinkProfileOutput {
public:
	explicit SinkProfileOutput(const ProfileSink& sink) : sink_(sink) {}
	[[nodiscard]] std::size_t size() const noexcept { return size_; }
	void emitHead(std::span<const Byte> head) { append(head); }
	void append(std::span<const Byte> bytes) {
		if (bytes.empty()) return;
		sink_(bytes);
		size_ = checkedAddSize(size_, bytes.size(), "File Size Error: Encrypted output overflow.");
	}

private:
	const ProfileSink& sink_;
	std::size_t size_{};
};

template <typename ProfileOutput>
void appendEncryptedFrame(
	ProfileOutput& encrypted,
	std::span<const Byte> cipher_frame,
	std::size_t max_encrypted_size) {
	if (cipher_frame.size() > static_cast<std::size_t>(std::numeric_limits<std::uint32_t>::max())) {
		throw std::runtime_error("crypto_secretstream frame too large.");
	}

	const auto frame_len = encodeFrameLen(static_cast<std::uint32_t>(cipher_frame.size()));
	const std::size_t final_size = checkedAddSize(
		checkedAddSize(encrypted.size(), frame_len.size(), "File Size Error: Encrypted output overflow."),
		cipher_frame.size(),
		"File Size Error: Encrypted output overflow."
	);
	if (final_size > max_encrypted_size) {
		throw std::runtime_error(
			"File Size Error: Compressed and encrypted payload exceeds the selected output size limit.");
	}

	encrypted.append(frame_len);
	encrypted.append(cipher_frame);
}

void initializeSecretStreamPush(
	crypto_secretstream_xchacha20poly1305_state& state,
	StreamHeader& stream_header,
	const Key& key) {

	if (crypto_secretstream_xchacha20poly1305_init_push(&state, stream_header.data(), key.data()) != 0) {
		throw std::runtime_error("crypto_secretstream init_push failed.");
	}
}

template <typename ProfileOutput>
void appendEncryptedFrames(
	ProfileOutput& encrypted,
	std::span<const Byte> plaintext,
	crypto_secretstream_xchacha20poly1305_state& state,
	vBytes& cipher_chunk,
	std::size_t max_encrypted_size,
	unsigned char final_tag = 0) {

	if (plaintext.empty() && final_tag == 0) {
		return;
	}

	std::size_t offset = 0;
	bool emit_empty_final = plaintext.empty() && final_tag != 0;

	while (emit_empty_final || offset < plaintext.size()) {
		const std::size_t remaining = plaintext.size() - offset;
		const std::size_t chunk_len = std::min(remaining, STREAM_CHUNK_SIZE);
		const bool is_final = emit_empty_final || (offset + chunk_len == plaintext.size());
		const unsigned char tag = is_final ? final_tag : 0;

		unsigned long long clen_ull = 0;
		if (crypto_secretstream_xchacha20poly1305_push(
				&state,
				cipher_chunk.data(),
				&clen_ull,
				(chunk_len == 0) ? nullptr : (plaintext.data() + static_cast<std::ptrdiff_t>(offset)),
				chunk_len,
				nullptr,
				0,
				tag) != 0) {
			throw std::runtime_error("crypto_secretstream push failed.");
		}

		if (clen_ull > static_cast<unsigned long long>(std::numeric_limits<std::uint32_t>::max())) {
			throw std::runtime_error("crypto_secretstream frame too large.");
		}
		appendEncryptedFrame(
			encrypted,
			std::span<const Byte>(cipher_chunk.data(), static_cast<std::size_t>(clen_ull)),
			max_encrypted_size
		);

		offset += chunk_len;
		emit_empty_final = false;
	}
}

// The secretstream rules every decryption shares, whatever holds the
// ciphertext: it opens with a copy of the stream header that must match the
// KDF metadata's; then each frame is a 4-byte length and at least an auth tag,
// at most one plaintext chunk, and must authenticate; the stream must end with
// a TAG_FINAL frame, and nothing may follow it.
//
// `fetch(n)` returns the next `n` ciphertext bytes (never more than one frame),
// valid until the next call: a view into memory or a buffer just read into.
// `deliver` receives each frame's plaintext, which is wiped once it returns.
// Returns false on any rule broken.
template <typename Fetch, typename Deliver>
[[nodiscard]] bool pullSecretStream(
	std::size_t cipher_len,
	const Key& key,
	const StreamHeader& header,
	Fetch&& fetch,
	Deliver&& deliver) {

	constexpr std::size_t ABYTES = crypto_secretstream_xchacha20poly1305_ABYTES;
	if (cipher_len < header.size() || !std::ranges::equal(fetch(header.size()), header)) {
		return false;
	}
	std::size_t remaining = cipher_len - header.size();

	crypto_secretstream_xchacha20poly1305_state stream_state{};
	ScopedWipe stream_state_wipe{stream_state};
	if (crypto_secretstream_xchacha20poly1305_init_pull(&stream_state, header.data(), key.data()) != 0) {
		return false;
	}

	vBytes plain_chunk(STREAM_CHUNK_SIZE);
	ScopedWipe plain_chunk_wipe{plain_chunk};

	while (remaining > 0) {
		if (remaining < STREAM_FRAME_LEN_BYTES) {
			return false;
		}
		const std::uint32_t frame_len = getValue(fetch(STREAM_FRAME_LEN_BYTES), 0);
		remaining -= STREAM_FRAME_LEN_BYTES;
		if (frame_len < ABYTES || frame_len > remaining || frame_len - ABYTES > plain_chunk.size()) {
			return false;
		}
		const std::span<const Byte> frame = fetch(frame_len);
		remaining -= frame_len;

		unsigned long long mlen = 0;
		unsigned char tag = 0;
		if (crypto_secretstream_xchacha20poly1305_pull(
				&stream_state, plain_chunk.data(), &mlen, &tag,
				frame.data(), frame.size(), nullptr, 0) != 0 ||
			mlen > frame_len - ABYTES) {
			return false;
		}
		if (mlen > 0) {
			deliver(std::span<const Byte>(plain_chunk.data(), static_cast<std::size_t>(mlen)));
			sodium_memzero(plain_chunk.data(), static_cast<std::size_t>(mlen));
		}
		if (tag == crypto_secretstream_xchacha20poly1305_TAG_FINAL) {
			return remaining == 0;
		}
	}
	return false;
}

// Decrypt in place: cipher at storage[cipher_start..cipher_start+cipher_len),
// plaintext written to storage[0..]. Plaintext write trails unread cipher by at least
// (cipher_start + header.size() + 21*N) bytes after frame N — always safe.
// On success, storage is resized to plaintext size. On failure, any partial plaintext is wiped.
[[nodiscard]] bool decryptWithSecretStreamInPlace(
	vBytes& storage,
	std::size_t cipher_start,
	std::size_t cipher_len,
	const Key& key,
	const StreamHeader& header) {

	if (!spanHasRange(storage, cipher_start, cipher_len)) {
		return false;
	}

	std::size_t cipher_pos = cipher_start;
	std::size_t plain_pos = 0;
	const bool ok = pullSecretStream(cipher_len, key, header,
		[&](std::size_t n) {
			const std::span<const Byte> bytes(storage.data() + cipher_pos, n);
			cipher_pos += n;
			return bytes;
		},
		[&](std::span<const Byte> plain) {
			std::memcpy(storage.data() + plain_pos, plain.data(), plain.size());
			plain_pos += plain.size();
		});
	if (!ok) {
		sodium_memzero(storage.data(), plain_pos);
		return false;
	}

	// Wipe trailing ciphertext bytes before truncating.
	if (plain_pos < storage.size()) {
		sodium_memzero(storage.data() + plain_pos, storage.size() - plain_pos);
	}
	storage.resize(plain_pos);
	return true;
}

// Takes the caller's RecoveryKey by reference: a by-value parameter would make
// a second copy of the secret, and scrubbing a parameter only reaches its stack
// slot, never a register the compiler chose to keep it in.
//
// KDF3 hashes the 16 raw KEY bytes.
void deriveKeyFromRecoveryKey(Key& out_key, const RecoveryKey& recovery_key, const Salt& salt) {
	if (!recovery_key.isKey()) {
		throw std::runtime_error("KDF Error: Missing recovery KEY.");
	}
	const auto* const password = reinterpret_cast<const char*>(recovery_key.key.data());
	const auto password_len = static_cast<unsigned long long>(recovery_key.key.size());

	// Wire-format parameters: they are not recorded in the KDF metadata (only the
	// algorithm byte is), so every image ever made depends on these exact values.
	// Pinned here rather than taken from libsodium's INTERACTIVE presets, which
	// are free to change between releases. 2 / 64 MiB is what those presets have
	// always been for Argon2id13, so existing images are unaffected.
	constexpr unsigned long long PAYLOAD_KDF_OPSLIMIT = 2;
	constexpr std::size_t PAYLOAD_KDF_MEMLIMIT = 64uz * 1024 * 1024;

	const int rc = crypto_pwhash(
		out_key.data(),
		out_key.size(),
		password,
		password_len,
		salt.data(),
		PAYLOAD_KDF_OPSLIMIT,
		PAYLOAD_KDF_MEMLIMIT,
		crypto_pwhash_ALG_ARGON2ID13
	);

	if (rc != 0) {
		throw std::runtime_error("KDF Error: Unable to derive encryption key.");
	}
}

// Fills `out_recovery_key` in place with a fresh 128-bit KEY (never all zero); see
// RecoveryKey for why no secret is returned by value anywhere in this file.
void generateRecoveryKey(RecoveryKey& out_recovery_key) {
	out_recovery_key.clear();
	Byte any = 0;
	while (any == 0) {
		randombytes_buf(out_recovery_key.key.data(), out_recovery_key.key.size());
		any = 0;
		for (const Byte b : out_recovery_key.key) any |= b;
	}
	out_recovery_key.kind = RecoveryKey::Kind::key128;
}

inline constexpr std::size_t MAX_FILENAME_PREFIX_BYTES =
	static_cast<std::size_t>(std::numeric_limits<Byte>::max()) + 1;

struct FilenamePrefix {
	std::array<Byte, MAX_FILENAME_PREFIX_BYTES> bytes{};
	std::size_t size{};

	[[nodiscard]] std::span<const Byte> view() const noexcept {
		return std::span<const Byte>(bytes.data(), size);
	}
};

[[nodiscard]] FilenamePrefix makeFilenamePrefix(const std::string& data_filename) {
	if (data_filename.empty() || data_filename.size() > static_cast<std::size_t>(std::numeric_limits<Byte>::max())) {
		throw std::runtime_error("Data File Error: Invalid data filename length.");
	}

	FilenamePrefix filename_prefix;
	filename_prefix.size = 1 + data_filename.size();
	filename_prefix.bytes[0] = static_cast<Byte>(data_filename.size());
	std::memcpy(
		filename_prefix.bytes.data() + 1,
		data_filename.data(),
		data_filename.size()
	);
	return filename_prefix;
}

void writeKdfMetadata(
	vBytes& profile_vec,
	const ProfileOffsets& offsets,
	const Salt& salt,
	const StreamHeader& stream_header,
	std::string_view corrupt_profile_error) {

	// The whole region is randomised first, so the bytes around the fields below
	// stay indistinguishable padding.
	Byte* const region = profile_vec.data() + offsets.kdf_metadata;
	randombytes_buf(region, KDF_METADATA_REGION_BYTES);
	std::memcpy(region + KDF_MAGIC_OFFSET, KDF_METADATA_MAGIC_V3.data(), KDF_METADATA_MAGIC_V3.size());
	region[KDF_ALG_OFFSET] = KDF_ALG_ARGON2ID13;
	region[KDF_SENTINEL_OFFSET] = KDF_SENTINEL;

	requireSpanRange(profile_vec, offsets.kdf_metadata + KDF_SALT_OFFSET, salt.size(), corrupt_profile_error);
	requireSpanRange(profile_vec, offsets.kdf_metadata + KDF_NONCE_OFFSET, stream_header.size(), corrupt_profile_error);
	std::memcpy(region + KDF_SALT_OFFSET, salt.data(), salt.size());
	std::memcpy(region + KDF_NONCE_OFFSET, stream_header.data(), stream_header.size());
}

[[nodiscard]] KdfSecrets readKdfSecrets(
	std::span<const Byte> data,
	const ProfileOffsets& offsets,
	std::string_view corrupt_file_error) {

	KdfSecrets secrets;
	requireSpanRange(data, offsets.kdf_metadata + KDF_SALT_OFFSET, secrets.salt.size(), corrupt_file_error);
	requireSpanRange(data, offsets.kdf_metadata + KDF_NONCE_OFFSET, secrets.stream_header.size(), corrupt_file_error);

	const Byte* const region = data.data() + offsets.kdf_metadata;
	std::memcpy(secrets.salt.data(), region + KDF_SALT_OFFSET, secrets.salt.size());
	std::memcpy(secrets.stream_header.data(), region + KDF_NONCE_OFFSET, secrets.stream_header.size());
	return secrets;
}

[[nodiscard]] std::string extractFilenamePrefix(vBytes& payload) {
	constexpr const char* CORRUPT_FILE_ERROR = "File Recovery Error: Embedded profile is corrupt.";
	if (payload.empty()) {
		throw std::runtime_error(CORRUPT_FILE_ERROR);
	}

	const std::size_t filename_len = payload[0];
	if (filename_len == 0) {
		throw std::runtime_error(CORRUPT_FILE_ERROR);
	}
	const std::size_t prefix_len = 1 + filename_len;
	requireSpanRange(payload, 0, prefix_len, CORRUPT_FILE_ERROR);

	std::string decrypted_filename(
		reinterpret_cast<const char*>(payload.data() + 1),
		filename_len
	);

	const std::size_t old_payload_size = payload.size();
	const std::size_t compressed_payload_size = old_payload_size - prefix_len;
	if (compressed_payload_size > 0) {
		std::memmove(
			payload.data(),
			payload.data() + static_cast<std::ptrdiff_t>(prefix_len),
			compressed_payload_size
		);
		sodium_memzero(
			payload.data() + static_cast<std::ptrdiff_t>(compressed_payload_size),
			prefix_len
		);
	} else {
		sodium_memzero(payload.data(), old_payload_size);
	}
	payload.resize(compressed_payload_size);
	return decrypted_filename;
}

} // namespace

namespace {

// Web variant: the recovery KEY arrives in pdv_out's <key_file> rather than
// from terminal entry, so there is none of the terminal/signal handling the
// main source needs for it.
constexpr const char* KEY_FILE_ERROR = "KEY File Error: Invalid file contents.";

// A 24-character KEY whose check pair does not match its body: a typo the user
// can find, reported before any key derivation.
constexpr const char* KEY_CHECK_ERROR =
	"KEY Entry Error: That KEY has a typo: its last two characters do not "
	"match the rest. Check each character, including upper and lower case.";

[[nodiscard]] constexpr bool isFileSpace(Byte b) noexcept {
	return b == ' ' || b == '\t' || b == '\r' || b == '\n';
}

} // namespace

void parseRecoveryKeyFile(std::span<const Byte> key_data, RecoveryKey& out_recovery_key) {
	out_recovery_key.clear();
	if (key_data.empty()) {
		throw std::runtime_error(KEY_FILE_ERROR);
	}

	std::size_t begin = 0;
	std::size_t end = key_data.size();
	while (begin < end && isFileSpace(key_data[begin])) ++begin;
	while (end > begin && isFileSpace(key_data[end - 1])) --end;

	const auto parsed = parseRecoveryKeyText(std::string_view(
		reinterpret_cast<const char*>(key_data.data() + begin), end - begin), out_recovery_key);
	if (parsed) {
		return;
	}

	// Raw binary fallback: exactly 16 bytes is the raw KEY. Only taken when the
	// file holds a byte that is not printable ASCII or whitespace, so a
	// plain-text file that failed the text parse -- say a mistyped KEY -- is
	// reported as the typo it is, not reinterpreted as a raw secret.
	const bool has_binary_byte = std::ranges::any_of(key_data, [](Byte b) static {
		return !((b >= 0x20 && b <= 0x7E) || isFileSpace(b));
	});
	if (has_binary_byte && key_data.size() == RecoveryKey::KEY_BYTES) {
		if (std::ranges::all_of(key_data, [](Byte b) static { return b == 0; })) {
			throw std::runtime_error(KEY_FILE_ERROR);
		}
		std::ranges::copy(key_data, out_recovery_key.key.begin());
		out_recovery_key.kind = RecoveryKey::Kind::key128;
		return;
	}

	throw std::runtime_error(
		parsed.error() == KeyParseError::checksum ? KEY_CHECK_ERROR : KEY_FILE_ERROR);
}

namespace {

constexpr const char* ENCRYPTED_OVERFLOW_ERROR = "File Size Error: Encrypted output overflow.";
constexpr std::size_t STREAM_FRAME_OVERHEAD =
	STREAM_FRAME_LEN_BYTES + crypto_secretstream_xchacha20poly1305_ABYTES;

// Bytes appendEncryptedFrames() adds for `plaintext_size` bytes of non-final
// plaintext: the data plus a length field and auth tag per frame.
[[nodiscard]] std::size_t framedCipherSize(std::size_t plaintext_size) {
	if (plaintext_size == 0) return 0;
	const std::size_t frame_count = 1 + ((plaintext_size - 1) / STREAM_CHUNK_SIZE);
	return checkedAddSize(
		plaintext_size,
		checkedMulSize(frame_count, STREAM_FRAME_OVERHEAD, ENCRYPTED_OVERFLOW_ERROR),
		ENCRYPTED_OVERFLOW_ERROR);
}

// Exact size of the profile encryptPayloadToProfile() builds from a template of
// `template_size` bytes, a `payload_size`-byte payload handed over in one piece
// (or in pieces that are whole multiples of the frame size), and a filename of
// `filename_length` bytes: stream header, filename frame, payload frames and
// the empty final frame.
[[nodiscard]] std::size_t encryptedProfileSize(
	std::size_t template_size,
	std::size_t payload_size,
	std::size_t filename_length) {

	std::size_t profile_size = checkedAddSize(
		template_size, crypto_secretstream_xchacha20poly1305_HEADERBYTES, ENCRYPTED_OVERFLOW_ERROR);
	profile_size = checkedAddSize(profile_size, framedCipherSize(1 + filename_length), ENCRYPTED_OVERFLOW_ERROR);
	profile_size = checkedAddSize(profile_size, framedCipherSize(payload_size), ENCRYPTED_OVERFLOW_ERROR);
	return checkedAddSize(profile_size, STREAM_FRAME_OVERHEAD, ENCRYPTED_OVERFLOW_ERROR);
}

// How a buffered profile's vector is sized while frames are appended to it.
// Only the Mastodon and Reddit profiles are buffered, and both are capped at a
// few tens of MiB, so the estimate (capped at the limit) is reserved whole up
// front. The vector grows past that only when the payload arrives in pieces
// smaller than a frame, which adds frames the estimate did not count.
class ProfileReservation {
public:
	ProfileReservation(vBytes& profile_vec, std::size_t estimated_size, std::size_t max_profile_size)
		: profile_vec_(profile_vec), max_size_(max_profile_size) {
		profile_vec_.reserve(std::min(estimated_size, max_profile_size));
	}

	// Make room for `extra` more bytes. A size past the output limit is left to
	// appendEncryptedFrame(), which reports it.
	void ensureRoomFor(std::size_t extra) {
		if (extra > max_size_ || profile_vec_.size() > max_size_ - extra) return;
		const std::size_t needed = profile_vec_.size() + extra;
		const std::size_t capacity = profile_vec_.capacity();
		if (needed <= capacity) return;
		const std::size_t doubled = capacity > max_size_ / 2 ? max_size_ : capacity * 2;
		profile_vec_.reserve(std::max(doubled, needed));
	}

private:
	vBytes& profile_vec_;
	std::size_t max_size_;
};

// Encrypts the payload into `profile_template` (the mode's profile template,
// its KDF metadata filled in here) followed by the ciphertext, all delivered
// to `output`. Returns the number of payload bytes encrypted.
template <typename ProfileOutput, typename PayloadProducer>
std::size_t encryptPayload(
	RecoveryKey& out_recovery_key,
	vBytes& profile_template,
	ProfileOutput& output,
	std::function<void(std::size_t)> ensure_room_for,
	const std::string& data_filename,
	bool has_mastodon_option,
	std::size_t max_profile_size,
	std::size_t estimated_profile_size,
	bool estimate_is_exact,
	PayloadProducer produce_payload) {

	const auto& offsets = has_mastodon_option ? MASTODON_OFFSETS : DEFAULT_OFFSETS;
	constexpr const char* CORRUPT_PROFILE_ERROR = "Internal Error: Corrupt profile template.";

	requireSpanRange(profile_template, offsets.kdf_metadata, KDF_METADATA_REGION_BYTES, CORRUPT_PROFILE_ERROR);
	if (offsets.encrypted_file != profile_template.size()) {
		throw std::runtime_error(CORRUPT_PROFILE_ERROR);
	}
	if (profile_template.size() > max_profile_size) {
		throw std::runtime_error(
			"File Size Error: Cover image leaves no room for an embedded payload.");
	}
	// A stored or prepared payload's size is known exactly, and the estimate
	// never exceeds the real profile (pieces smaller than a frame only add
	// frames), so one that cannot fit is refused here: before memory is reserved,
	// a KEY derived, or any of it encrypted. A deflated payload's estimate is
	// only an upper bound; it is checked as it streams.
	if (estimate_is_exact && estimated_profile_size > max_profile_size) {
		throw std::runtime_error(
			"File Size Error: Compressed and encrypted payload exceeds the selected output size limit.");
	}

	const FilenamePrefix filename_prefix = makeFilenamePrefix(data_filename);

	Key key{};
	ScopedWipe key_wipe{key};
	Salt salt{};
	StreamHeader stream_header{};
	// Generated straight into the caller's storage: there is never a second copy
	// to scrub, and the caller's RecoveryKey wipes it on every path out of here,
	// exception or not.
	generateRecoveryKey(out_recovery_key);

	randombytes_buf(salt.data(), salt.size());
	deriveKeyFromRecoveryKey(key, out_recovery_key, salt);

	crypto_secretstream_xchacha20poly1305_state stream_state{};
	ScopedWipe stream_state_wipe{stream_state};
	initializeSecretStreamPush(stream_state, stream_header, key);

	if (stream_header.size() > max_profile_size - profile_template.size()) {
		throw std::runtime_error(
			"File Size Error: Compressed and encrypted payload exceeds the selected output size limit.");
	}
	// The salt and stream header are all the head needs, so it is complete
	// before the first frame and can be streamed out ahead of the ciphertext.
	writeKdfMetadata(profile_template, offsets, salt, stream_header, CORRUPT_PROFILE_ERROR);
	output.emitHead(profile_template);
	output.append(stream_header);

	vBytes cipher_chunk(STREAM_CHUNK_SIZE + crypto_secretstream_xchacha20poly1305_ABYTES);

	appendEncryptedFrames(
		output, filename_prefix.view(), stream_state, cipher_chunk, max_profile_size);

	std::size_t payload_size = 0;
	const auto consume_payload = [&](std::span<const Byte> chunk) {
		if (chunk.empty()) {
			return;
		}
		payload_size += chunk.size();
		ensure_room_for(framedCipherSize(chunk.size()));
		appendEncryptedFrames(
			output, chunk, stream_state, cipher_chunk, max_profile_size);
	};
	produce_payload(consume_payload);

	if (payload_size == 0) {
		throw std::runtime_error("File Size Error: File is zero bytes. Probable compression failure.");
	}

	// Close the secretstream with an empty TAG_FINAL frame (~21 bytes overhead).
	ensure_room_for(STREAM_FRAME_OVERHEAD);
	appendEncryptedFrames(
		output,
		std::span<const Byte>{},
		stream_state,
		cipher_chunk,
		max_profile_size,
		crypto_secretstream_xchacha20poly1305_TAG_FINAL
	);
	return payload_size;
}

// The in-memory form: `profile_vec` holds the template on entry and the whole
// encrypted profile on return.
template <typename PayloadProducer>
std::size_t encryptPayloadToProfile(
	RecoveryKey& out_recovery_key,
	vBytes& profile_vec,
	const std::string& data_filename,
	bool has_mastodon_option,
	std::size_t max_profile_size,
	std::size_t estimated_payload_size,
	bool estimate_is_exact,
	PayloadProducer produce_payload) {

	const std::size_t estimated_profile_size =
		encryptedProfileSize(profile_vec.size(), estimated_payload_size, data_filename.size());
	std::optional<ProfileReservation> reservation;
	VectorProfileOutput output(profile_vec);
	return encryptPayload(
		out_recovery_key, profile_vec, output,
		[&](std::size_t extra) {
			// Reserved on first use, after the size checks and KEY generation.
			if (!reservation) {
				reservation.emplace(profile_vec, estimated_profile_size, max_profile_size);
			}
			reservation->ensureRoomFor(extra);
		},
		data_filename, has_mastodon_option, max_profile_size,
		estimated_profile_size, estimate_is_exact, std::move(produce_payload));
}

} // namespace

std::size_t encryptCompressedFileToProfile(
	RecoveryKey& out_recovery_key,
	vBytes& profile_vec,
	int data_fd,
	std::size_t data_file_size,
	const std::string& data_filename,
	bool is_compressed_file,
	bool has_mastodon_option,
	std::size_t max_profile_size) {

	return encryptPayloadToProfile(
		out_recovery_key,
		profile_vec,
		data_filename,
		has_mastodon_option,
		max_profile_size,
		// Exact for stored input; an upper bound for deflated input.
		zlibPayloadStreamBound(data_file_size, is_compressed_file),
		is_compressed_file,
		[&](const auto& consume_payload) {
			zlibDeflateFd(
				data_fd,
				data_file_size,
				is_compressed_file,
				consume_payload);
		});
}

std::size_t encryptCompressedFileToSink(
	RecoveryKey& out_recovery_key,
	vBytes& profile_template,
	int data_fd,
	std::size_t data_file_size,
	const std::string& data_filename,
	bool is_compressed_file,
	std::size_t max_profile_size,
	const ProfileSink& sink) {

	SinkProfileOutput output(sink);
	return encryptPayload(
		out_recovery_key, profile_template, output,
		[](std::size_t) {},
		data_filename, false, max_profile_size,
		encryptedProfileSize(
			profile_template.size(),
			// Exact for stored input; an upper bound for deflated input.
			zlibPayloadStreamBound(data_file_size, is_compressed_file),
			data_filename.size()),
		is_compressed_file,
		[&](const auto& consume_payload) {
			zlibDeflateFd(data_fd, data_file_size, is_compressed_file, consume_payload);
		});
}

void encryptPreparedDataToProfile(
	RecoveryKey& out_recovery_key,
	vBytes& profile_vec,
	std::span<const Byte> prepared_data,
	const std::string& data_filename,
	bool has_mastodon_option,
	std::size_t max_profile_size) {

	(void)encryptPayloadToProfile(
		out_recovery_key,
		profile_vec,
		data_filename,
		has_mastodon_option,
		max_profile_size,
		prepared_data.size(),
		true,
		[prepared_data](const auto& consume_payload) {
			consume_payload(prepared_data);
		});
}

std::size_t computeRedditEncryptedProfileSize(
	std::size_t prepared_data_size,
	std::size_t filename_length) {

	if (filename_length == 0 ||
		filename_length > static_cast<std::size_t>(std::numeric_limits<Byte>::max())) {
		throw std::runtime_error("Data File Error: Invalid data filename length.");
	}
	return encryptedProfileSize(DEFAULT_OFFSETS.encrypted_file, prepared_data_size, filename_length);
}

std::optional<std::span<const Byte>> findPdvrdtIccpPayload(std::span<const Byte> iccp_data) {
	constexpr std::size_t PROFILE_PREFIX_SIZE = MASTODON_OFFSETS.pdv_signature + PDVRDT_SIG.size();

	if (!bytesEqualAt(iccp_data, 0, PDVRDT_ICCP_PREFIX)) {
		return std::nullopt;
	}
	const std::span<const Byte> compressed = iccp_data.subspan(PDVRDT_ICCP_PREFIX.size());
	if (compressed.empty()) {
		return std::nullopt;
	}

	vBytes profile_prefix;
	try {
		profile_prefix = zlibInflatePrefix(compressed, PROFILE_PREFIX_SIZE);
	} catch (const std::runtime_error&) {
		return std::nullopt;
	}
	if (profile_prefix.size() != PROFILE_PREFIX_SIZE ||
		!hasPdvrdtProfileMarkers(profile_prefix, MASTODON_OFFSETS)) {
		return std::nullopt;
	}
	return compressed;
}

void deriveCarrierKeyFromRecoveryKey(const RecoveryKey& recovery_key, CarrierKey& out_key) {
	if (!recovery_key.isKey()) {
		throw std::runtime_error("KDF Error: Missing recovery KEY.");
	}
	// Wire-format parameters, deliberately fixed rather than libsodium's
	// changeable INTERACTIVE presets. The salt cannot be read from the encrypted
	// payload until the carrier has been located, so use a separate, fixed
	// domain salt. That permits cross-image amortization, but every candidate
	// still requires an Argon2id evaluation, and a 128-bit KEY cannot be
	// searched at all.
	static constexpr Salt DOMAIN_SALT = {
		'p','d','v','r','d','t','c','a','r','r','i','e','r','-','v','4'
	};
	constexpr std::string_view DOMAIN = "pdvrdt carrier v4";
	constexpr unsigned long long CARRIER_KDF_OPSLIMIT = 2;
	constexpr std::size_t CARRIER_KDF_MEMLIMIT = 64uz * 1024 * 1024;

	// Argon2id with the carrier parameters, then keyed BLAKE2b-256 of the
	// domain under the whole Argon2 output.
	std::array<Byte, 32> digest{};
	ScopedWipe digest_wipe{digest};
	if (crypto_pwhash(
			digest.data(), digest.size(),
			reinterpret_cast<const char*>(recovery_key.key.data()), recovery_key.key.size(),
			DOMAIN_SALT.data(), CARRIER_KDF_OPSLIMIT, CARRIER_KDF_MEMLIMIT,
			crypto_pwhash_ALG_ARGON2ID13) != 0) {
		throw std::runtime_error("KDF Error: Unable to derive Reddit carrier key.");
	}
	if (crypto_generichash(
			out_key.bytes.data(), out_key.bytes.size(),
			reinterpret_cast<const unsigned char*>(DOMAIN.data()), DOMAIN.size(),
			digest.data(), digest.size()) != 0) {
		throw std::runtime_error("KDF Error: Unable to derive Reddit carrier key.");
	}
}

std::optional<std::string> decryptDataFileWithKey(
	vBytes& png_vec,
	const RecoveryKey& recovery_key,
	bool is_mastodon_file,
	const std::function<void()>& on_key_derived) {
	const auto& offsets = is_mastodon_file ? MASTODON_OFFSETS : DEFAULT_OFFSETS;

	constexpr const char* CORRUPT_FILE_ERROR = "File Recovery Error: Embedded profile is corrupt.";
	requireSpanRange(png_vec, offsets.kdf_metadata, KDF_METADATA_REGION_BYTES, CORRUPT_FILE_ERROR);
	if (offsets.encrypted_file > png_vec.size()) {
		throw std::runtime_error(CORRUPT_FILE_ERROR);
	}

	if (kdfMetadataVersionAt(png_vec, offsets.kdf_metadata) != KdfVersion::key_v3) {
		throw std::runtime_error(UNSUPPORTED_FORMAT_ERROR);
	}

	Key key{};
	ScopedWipe key_wipe{key};
	const KdfSecrets secrets = readKdfSecrets(png_vec, offsets, CORRUPT_FILE_ERROR);
	deriveKeyFromRecoveryKey(key, recovery_key, secrets.salt);
	on_key_derived();

	const std::size_t ciphertext_length = png_vec.size() - offsets.encrypted_file;
	if (ciphertext_length < minimumStreamCipherSize()) {
		throw std::runtime_error(CORRUPT_FILE_ERROR);
	}

	if (!decryptWithSecretStreamInPlace(png_vec, offsets.encrypted_file, ciphertext_length, key, secrets.stream_header)) {
		return std::nullopt;
	}

	return extractFilenamePrefix(png_vec);
}

bool decryptStreamWithKey(
	std::span<const Byte> profile_head,
	std::size_t ciphertext_length,
	const RecoveryKey& recovery_key,
	const std::function<void()>& on_key_derived,
	const std::function<void(std::span<Byte>)>& read_ciphertext,
	const std::function<void(std::span<const Byte>)>& on_plaintext) {

	const ProfileOffsets& offsets = DEFAULT_OFFSETS;
	constexpr const char* CORRUPT_FILE_ERROR = "File Recovery Error: Embedded profile is corrupt.";
	requireSpanRange(profile_head, offsets.kdf_metadata, KDF_METADATA_REGION_BYTES, CORRUPT_FILE_ERROR);
	if (kdfMetadataVersionAt(profile_head, offsets.kdf_metadata) != KdfVersion::key_v3) {
		throw std::runtime_error(UNSUPPORTED_FORMAT_ERROR);
	}

	Key key{};
	ScopedWipe key_wipe{key};
	const KdfSecrets secrets = readKdfSecrets(profile_head, offsets, CORRUPT_FILE_ERROR);
	deriveKeyFromRecoveryKey(key, recovery_key, secrets.salt);
	on_key_derived();

	if (ciphertext_length < minimumStreamCipherSize()) {
		throw std::runtime_error(CORRUPT_FILE_ERROR);
	}

	// Each piece is read into one frame-sized buffer, used before the next read.
	vBytes cipher_frame(STREAM_CHUNK_SIZE + crypto_secretstream_xchacha20poly1305_ABYTES);
	return pullSecretStream(ciphertext_length, key, secrets.stream_header,
		[&](std::size_t n) {
			const std::span<Byte> bytes(cipher_frame.data(), n);
			read_ciphertext(bytes);
			return std::span<const Byte>(bytes);
		},
		on_plaintext);
}

