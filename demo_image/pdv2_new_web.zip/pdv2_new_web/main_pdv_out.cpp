// PNG Data Vehicle (pdv_out) Created by Nicholas Cleasby (@CleasbyCode) 24/01/2023

#include "args_out.h"
#include "io_utils.h"
#include "recover.h"

#include <iostream>
#include <print>
#include <stdexcept>

int main(int argc, char** argv) {
	try {
		if (sodium_init() < 0) {
			throw std::runtime_error("Libsodium initialization failed!");
		}

		auto args = ProgramArgs::parse(argc, argv);

		vBytes png_vec = readFile(args.image_file_path, FileTypeCheck::embedded_image);
		recoverData(png_vec, args.pin_file_path);
	}
	catch (const std::exception& e) {
		std::println(std::cerr, "\n{}\n", e.what());
		return 1;
	}
	return 0;
}
