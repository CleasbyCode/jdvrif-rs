#include "encryption_internal.h"
#include "encryption_stream_shared.h"
#include "file_utils.h"
#include "signal_utils.h"

#include <algorithm>
#include <array>
#include <cstring>
#include <fstream>
#include <limits>
#include <memory>
#include <span>
#include <stdexcept>

namespace {
constexpr const char* ENCRYPT_OVERFLOW_ERROR = "File Size Error: Encrypted output overflow.";
constexpr const char* CHUNK_LIMIT_ERROR = "File Size Error: Stream chunk exceeds size limit.";

[[nodiscard]] std::array<Byte, STREAM_FRAME_LEN_BYTES> encodeFrameLength(std::size_t frame_len) {
    throwIf(frame_len > static_cast<std::size_t>(std::numeric_limits<uint32_t>::max()), CHUNK_LIMIT_ERROR);

    return {
        static_cast<Byte>((frame_len >> 24) & 0xFF),
        static_cast<Byte>((frame_len >> 16) & 0xFF),
        static_cast<Byte>((frame_len >> 8) & 0xFF),
        static_cast<Byte>(frame_len & 0xFF)
    };
}

[[nodiscard]] std::size_t checkedCipherChunkSize(std::size_t plain_size) {
    constexpr std::size_t STREAM_ABYTES = crypto_secretstream_xchacha20poly1305_ABYTES;
    const std::size_t cipher_size = plain_size + STREAM_ABYTES;
    throwIf(cipher_size > static_cast<std::size_t>(std::numeric_limits<uint32_t>::max()), CHUNK_LIMIT_ERROR);
    return cipher_size;
}

template<typename EmitFrameFn>
void pushSecretStreamFrame(
    crypto_secretstream_xchacha20poly1305_state& state,
    std::span<const Byte> plain_chunk,
    std::span<const Byte> associated_data,
    bool is_final,
    CipherChunk& cipher_chunk,
    EmitFrameFn&& emit_frame) {

    const std::size_t cipher_size = checkedCipherChunkSize(plain_chunk.size());
    unsigned long long written = 0;
    const unsigned char tag = is_final ? crypto_secretstream_xchacha20poly1305_TAG_FINAL : 0;

    const int push_rc = crypto_secretstream_xchacha20poly1305_push(
        &state, cipher_chunk.data(), &written,
        plain_chunk.data(), static_cast<unsigned long long>(plain_chunk.size()),
        associated_data.data(), static_cast<unsigned long long>(associated_data.size()),
        tag);
    throwIf(push_rc != 0, "crypto_secretstream push failed");
    throwIf(written != cipher_size, "crypto_secretstream push produced unexpected size");

    emit_frame(std::span<const Byte>(cipher_chunk.data(), cipher_size));
}

template<typename SourceFn, typename EmitFrameFn>
void encryptSecretStreamFrames(
    const Key& key,
    StreamHeader& header,
    std::span<const Byte> associated_data,
    SourceFn&& source,
    EmitFrameFn&& emit_frame) {

    SecretStreamStateGuard stream_state;
    throwIf(
        crypto_secretstream_xchacha20poly1305_init_push(&stream_state.state, header.data(), key.data()) != 0,
        "crypto_secretstream init_push failed");

    auto cipher_chunk = std::make_unique<CipherChunk>();
    ZeroGuard<CipherChunk> cipher_chunk_guard{cipher_chunk.get()};

    source([&](std::span<const Byte> plain_chunk, bool is_final) {
        throwIfSignalCancellationRequested();
        pushSecretStreamFrame(stream_state.state, plain_chunk, associated_data, is_final, *cipher_chunk, emit_frame);
    });
}

void appendFramedCipherBytes(vBytes& output_vec, std::span<const Byte> cipher_frame) {
    const auto frame_len = encodeFrameLength(cipher_frame.size());
    const std::size_t base = output_vec.size();
    const std::size_t final_size = checkedAdd(
        checkedAdd(base, frame_len.size(), ENCRYPT_OVERFLOW_ERROR),
        cipher_frame.size(),
        ENCRYPT_OVERFLOW_ERROR);

    output_vec.resize(final_size);
    Byte* out = output_vec.data() + static_cast<std::ptrdiff_t>(base);
    std::memcpy(out, frame_len.data(), frame_len.size());
    std::memcpy(out + frame_len.size(), cipher_frame.data(), cipher_frame.size());
}

void writeFramedCipherBytes(std::ostream& output, std::span<const Byte> cipher_frame) {
    const auto frame_len = encodeFrameLength(cipher_frame.size());
    writeBytesOrThrow(output, frame_len, WRITE_COMPLETE_ERROR);
    writeBytesOrThrow(output, cipher_frame, WRITE_COMPLETE_ERROR);
}

template<typename ChunkFn>
void forEachPrefixedPlainChunkFromFile(
    const fs::path& data_path,
    std::size_t input_size,
    std::span<const Byte> prefix_plaintext,
    ChunkFn&& chunk_fn);

template<typename EmitFrameFn>
void encryptFileWithSecretStreamPrefixedImpl(
    const fs::path& data_path,
    std::size_t input_size,
    std::span<const Byte> prefix_plaintext,
    Byte authenticated_mode,
    const Key& key,
    StreamHeader& header,
    EmitFrameFn&& emit_frame) {
    const std::array<Byte, 1> associated_data{authenticated_mode};
    encryptSecretStreamFrames(
        key,
        header,
        associated_data,
        [&](auto&& emit_plain_chunk) { forEachPrefixedPlainChunkFromFile(data_path, input_size, prefix_plaintext, emit_plain_chunk); },
        emit_frame);
}

template<typename ChunkFn>
void forEachPrefixedPlainChunkFromFile(
    const fs::path& data_path,
    std::size_t input_size,
    std::span<const Byte> prefix_plaintext,
    ChunkFn&& chunk_fn) {

    throwIf(input_size == 0, "Data File Error: File is empty.");
    (void)checkedAdd(input_size, prefix_plaintext.size(), ENCRYPT_OVERFLOW_ERROR);

    std::ifstream input = openBinaryInputOrThrow(data_path, "Read Error: Failed to open file for encryption.");

    auto in_chunk_ptr = std::make_unique<std::array<Byte, STREAM_CHUNK_SIZE>>();
    auto& in_chunk = *in_chunk_ptr;
    ZeroGuard<std::array<Byte, STREAM_CHUNK_SIZE>> in_chunk_guard{&in_chunk};

    std::size_t prefix_offset = 0;
    std::size_t input_left = input_size;

    while (prefix_offset < prefix_plaintext.size() || input_left > 0) {
        throwIfSignalCancellationRequested();
        std::size_t filled = 0;

        if (prefix_offset < prefix_plaintext.size()) {
            const std::size_t prefix_bytes = std::min(STREAM_CHUNK_SIZE, prefix_plaintext.size() - prefix_offset);
            std::memcpy(
                in_chunk.data(),
                prefix_plaintext.data() + static_cast<std::ptrdiff_t>(prefix_offset),
                prefix_bytes);
            prefix_offset += prefix_bytes;
            filled = prefix_bytes;
        }

        if (filled < STREAM_CHUNK_SIZE && input_left > 0) {
            const std::size_t file_bytes = std::min(STREAM_CHUNK_SIZE - filled, input_left);
            const std::streamsize read_count = readSomeOrThrow(
                input,
                in_chunk.data() + static_cast<std::ptrdiff_t>(filled),
                file_bytes,
                "Read Error: Failed while reading input file.");
            throwIf(
                read_count != static_cast<std::streamsize>(file_bytes),
                "Read Error: Failed to read full input while encrypting.");

            filled += file_bytes;
            input_left -= file_bytes;
        }

        throwIf(filled == 0, "Internal Error: Plaintext size accounting mismatch.");

        const bool is_final = (prefix_offset == prefix_plaintext.size() && input_left == 0);
        chunk_fn(std::span<const Byte>(in_chunk.data(), filled), is_final);
        sodium_memzero(in_chunk.data(), filled);
    }

    throwIf(
        prefix_offset != prefix_plaintext.size() || input_left != 0,
        "Internal Error: Plaintext size accounting mismatch.");

    requireNoTrailingDataOrThrow(input, "Read Error: Input file changed while encrypting.");
    throwIfSignalCancellationRequested();
}
} // namespace

[[nodiscard]] std::size_t computeStreamEncryptedSize(std::size_t plaintext_size) {
    constexpr std::size_t STREAM_ABYTES = crypto_secretstream_xchacha20poly1305_ABYTES;
    if (plaintext_size == 0) return 0;
    const std::size_t chunk_count = 1 + ((plaintext_size - 1) / STREAM_CHUNK_SIZE);
    const std::size_t per_chunk_overhead = STREAM_ABYTES + STREAM_FRAME_LEN_BYTES;

    throwIf(
        chunk_count > (std::numeric_limits<std::size_t>::max() - plaintext_size) / per_chunk_overhead,
        ENCRYPT_OVERFLOW_ERROR);
    return plaintext_size + chunk_count * per_chunk_overhead;
}

[[nodiscard]] std::size_t computeStreamEncryptedSizePrefixed(
    std::size_t input_plaintext_size,
    std::size_t prefix_plaintext_size) {
    throwIf(
        prefix_plaintext_size > std::numeric_limits<std::size_t>::max() - input_plaintext_size,
        ENCRYPT_OVERFLOW_ERROR);
    return computeStreamEncryptedSize(input_plaintext_size + prefix_plaintext_size);
}

void encryptFileWithSecretStreamPrefixed(
    const fs::path& data_path,
    std::size_t input_size,
    std::span<const Byte> prefix_plaintext,
    Byte authenticated_mode,
    const Key& key,
    std::array<Byte, crypto_secretstream_xchacha20poly1305_HEADERBYTES>& header,
    vBytes& output_vec) {

    const std::size_t total_plain_size = checkedAdd(input_size, prefix_plaintext.size(), ENCRYPT_OVERFLOW_ERROR);

    output_vec.clear();
    output_vec.reserve(computeStreamEncryptedSize(total_plain_size));
    encryptFileWithSecretStreamPrefixedImpl(
        data_path,
        input_size,
        prefix_plaintext,
        authenticated_mode,
        key,
        header,
        [&](std::span<const Byte> cipher_frame) {
            appendFramedCipherBytes(output_vec, cipher_frame);
        });
}

void encryptFileWithSecretStreamPrefixedToFile(
    const fs::path& data_path,
    std::size_t input_size,
    std::span<const Byte> prefix_plaintext,
    Byte authenticated_mode,
    const Key& key,
    std::array<Byte, crypto_secretstream_xchacha20poly1305_HEADERBYTES>& header,
    const fs::path& output_path) {

    // output_path is a StagingFile (see file_utils.h): the inode exists but has
    // no directory entry, so ciphertext never appears under a name on disk.
    std::ofstream output = openBinaryOutputForStagingOrThrow(output_path);
    encryptFileWithSecretStreamPrefixedImpl(
        data_path,
        input_size,
        prefix_plaintext,
        authenticated_mode,
        key,
        header,
        [&](std::span<const Byte> cipher_frame) {
            writeFramedCipherBytes(output, cipher_frame);
        });
    closeOutputOrThrow(output, WRITE_COMPLETE_ERROR);
}
