#include "encryption.h"
#include "compression.h"
#include "io_utils.h"
#include "png_utils.h"

#include <algorithm>
#include <charconv>
#include <cstring>
#include <limits>
#include <ranges>
#include <span>
#include <stdexcept>

namespace {
constexpr auto KDF_METADATA_MAGIC_V2 = std::to_array<Byte>({'K', 'D', 'F', '2'});

struct SensitiveKeyData {
	Key key{};

	~SensitiveKeyData() {
		sodium_memzero(key.data(), key.size());
	}

	SensitiveKeyData(const SensitiveKeyData&) = delete;
	SensitiveKeyData& operator=(const SensitiveKeyData&) = delete;
	SensitiveKeyData() = default;
};

struct SensitiveBytesGuard {
	vBytes* bytes{};
	bool active{true};

	SensitiveBytesGuard(const SensitiveBytesGuard&) = delete;
	SensitiveBytesGuard& operator=(const SensitiveBytesGuard&) = delete;

	explicit SensitiveBytesGuard(vBytes& in_bytes)
		: bytes(&in_bytes) {}

	~SensitiveBytesGuard() {
		if (active && bytes != nullptr && !bytes->empty()) {
			sodium_memzero(bytes->data(), bytes->size());
		}
	}

	void release() noexcept {
		active = false;
	}
};

struct SecretStreamStateGuard {
	crypto_secretstream_xchacha20poly1305_state state{};

	SecretStreamStateGuard(const SecretStreamStateGuard&) = delete;
	SecretStreamStateGuard& operator=(const SecretStreamStateGuard&) = delete;
	SecretStreamStateGuard() = default;

	~SecretStreamStateGuard() {
		sodium_memzero(&state, sizeof(state));
	}
};

constexpr std::size_t
	STREAM_CHUNK_SIZE      = 1 * 1024 * 1024,
	STREAM_FRAME_LEN_BYTES = 4;

using StreamHeader = std::array<Byte, crypto_secretstream_xchacha20poly1305_HEADERBYTES>;

void writeFrameLen(vBytes& out, std::uint32_t frame_len) {
	const std::array<Byte, STREAM_FRAME_LEN_BYTES> bytes{
		static_cast<Byte>((frame_len >> 24) & 0xFF),
		static_cast<Byte>((frame_len >> 16) & 0xFF),
		static_cast<Byte>((frame_len >> 8)  & 0xFF),
		static_cast<Byte>(frame_len & 0xFF)
	};
	out.insert(out.end(), bytes.begin(), bytes.end());
}

void appendEncryptedFrames(
	vBytes& encrypted,
	std::span<const Byte> plaintext,
	crypto_secretstream_xchacha20poly1305_state& state,
	vBytes& cipher_chunk,
	unsigned char final_tag = 0) {

	if (plaintext.empty() && final_tag == 0) {
		return;
	}

	std::size_t offset = 0;
	bool emit_empty_final = plaintext.empty() && final_tag != 0;

	while (emit_empty_final || offset < plaintext.size()) {
		const std::size_t remaining = plaintext.size() - offset;
		const std::size_t chunk_len = std::min(remaining, STREAM_CHUNK_SIZE);
		const bool is_final = emit_empty_final || (offset + chunk_len == plaintext.size());
		const unsigned char tag = is_final ? final_tag : 0;

		unsigned long long clen_ull = 0;
		if (crypto_secretstream_xchacha20poly1305_push(
				&state,
				cipher_chunk.data(),
				&clen_ull,
				(chunk_len == 0) ? nullptr : (plaintext.data() + static_cast<std::ptrdiff_t>(offset)),
				chunk_len,
				nullptr,
				0,
				tag) != 0) {
			throw std::runtime_error("crypto_secretstream push failed.");
		}

		if (clen_ull > static_cast<unsigned long long>(std::numeric_limits<std::uint32_t>::max())) {
			throw std::runtime_error("crypto_secretstream frame too large.");
		}
		writeFrameLen(encrypted, static_cast<std::uint32_t>(clen_ull));
		encrypted.insert(
			encrypted.end(),
			cipher_chunk.begin(),
			cipher_chunk.begin() + static_cast<std::ptrdiff_t>(clen_ull)
		);

		offset += chunk_len;
		emit_empty_final = false;
	}
}

[[nodiscard]] std::uint32_t readFrameLen(std::span<const Byte> data, std::size_t index) {
	return (static_cast<std::uint32_t>(data[index]) << 24) |
		   (static_cast<std::uint32_t>(data[index + 1]) << 16) |
		   (static_cast<std::uint32_t>(data[index + 2]) << 8) |
		    static_cast<std::uint32_t>(data[index + 3]);
}

[[nodiscard]] std::optional<vBytes> decryptWithSecretStream(
	std::span<const Byte> framed_ciphertext,
	const Key& key,
	const StreamHeader& header) {

	if (!spanHasRange(framed_ciphertext, 0, header.size())) {
		return std::nullopt;
	}
	if (!std::ranges::equal(framed_ciphertext.first(header.size()), header)) {
		return std::nullopt;
	}

	SecretStreamStateGuard stream_state;
	if (crypto_secretstream_xchacha20poly1305_init_pull(&stream_state.state, header.data(), key.data()) != 0) {
		return std::nullopt;
	}

	vBytes decrypted;
	decrypted.reserve(framed_ciphertext.size() - header.size());
	SensitiveBytesGuard decrypted_guard(decrypted);
	vBytes plain_chunk(STREAM_CHUNK_SIZE);
	SensitiveBytesGuard plain_chunk_guard(plain_chunk);

	std::size_t offset = header.size();
	bool has_final_tag = false;

	while (offset < framed_ciphertext.size()) {
		if (framed_ciphertext.size() - offset < STREAM_FRAME_LEN_BYTES) {
			return std::nullopt;
		}

		const std::uint32_t frame_len = readFrameLen(framed_ciphertext, offset);
		offset += STREAM_FRAME_LEN_BYTES;

		if (frame_len < crypto_secretstream_xchacha20poly1305_ABYTES ||
			frame_len > framed_ciphertext.size() - offset) {
			return std::nullopt;
		}

		const std::size_t max_plain_chunk = static_cast<std::size_t>(frame_len) - crypto_secretstream_xchacha20poly1305_ABYTES;
		if (max_plain_chunk > plain_chunk.size()) {
			return std::nullopt;
		}

		unsigned long long mlen = 0;
		unsigned char tag = 0;
		if (crypto_secretstream_xchacha20poly1305_pull(
				&stream_state.state,
				plain_chunk.data(),
				&mlen,
				&tag,
				framed_ciphertext.data() + static_cast<std::ptrdiff_t>(offset),
				frame_len,
				nullptr,
				0) != 0) {
			return std::nullopt;
		}
		if (mlen > max_plain_chunk) {
			return std::nullopt;
		}
		decrypted.insert(
			decrypted.end(),
			plain_chunk.begin(),
			plain_chunk.begin() + static_cast<std::ptrdiff_t>(mlen)
		);

		offset += frame_len;
		if (tag == crypto_secretstream_xchacha20poly1305_TAG_FINAL) {
			has_final_tag = true;
			break;
		}
	}

	if (!has_final_tag || offset != framed_ciphertext.size()) {
		return std::nullopt;
	}

	decrypted_guard.release();
	// Move (not copy) into the returned optional. A copy would leave the
	// plaintext in the local buffer, which is freed without wiping.
	return std::optional<vBytes>{std::move(decrypted)};
}

void deriveKeyFromPin(Key& out_key, std::uint64_t pin, const Salt& salt) {
	std::array<char, 32> pin_buf{};
	auto [ptr, ec] = std::to_chars(pin_buf.data(), pin_buf.data() + pin_buf.size(), pin);
	if (ec != std::errc{}) {
		sodium_memzero(pin_buf.data(), pin_buf.size());
		throw std::runtime_error("KDF Error: Failed to encode recovery PIN.");
	}

	const auto pin_len = static_cast<unsigned long long>(ptr - pin_buf.data());
	const int rc = crypto_pwhash(
		out_key.data(),
		out_key.size(),
		pin_buf.data(),
		pin_len,
		salt.data(),
		crypto_pwhash_OPSLIMIT_INTERACTIVE,
		crypto_pwhash_MEMLIMIT_INTERACTIVE,
		crypto_pwhash_ALG_ARGON2ID13
	);

	sodium_memzero(pin_buf.data(), pin_buf.size());

	if (rc != 0) {
		throw std::runtime_error("KDF Error: Unable to derive encryption key.");
	}
}

void writeKdfMetadata(
	vBytes& profile_vec,
	const ProfileOffsets& offsets,
	const Salt& salt,
	const StreamHeader& stream_header,
	const char* corrupt_profile_error) {
	randombytes_buf(profile_vec.data() + offsets.kdf_metadata, KDF_METADATA_REGION_BYTES);
	std::ranges::copy(
		KDF_METADATA_MAGIC_V2,
		profile_vec.begin() + static_cast<std::ptrdiff_t>(offsets.kdf_metadata + KDF_MAGIC_OFFSET)
	);
	profile_vec[offsets.kdf_metadata + KDF_ALG_OFFSET] = KDF_ALG_ARGON2ID13;
	profile_vec[offsets.kdf_metadata + KDF_SENTINEL_OFFSET] = KDF_SENTINEL;

	requireSpanRange(profile_vec, offsets.kdf_metadata + KDF_SALT_OFFSET, salt.size(), corrupt_profile_error);
	requireSpanRange(profile_vec, offsets.kdf_metadata + KDF_NONCE_OFFSET, stream_header.size(), corrupt_profile_error);
	std::ranges::copy(salt, profile_vec.begin() + static_cast<std::ptrdiff_t>(offsets.kdf_metadata + KDF_SALT_OFFSET));
	std::ranges::copy(stream_header, profile_vec.begin() + static_cast<std::ptrdiff_t>(offsets.kdf_metadata + KDF_NONCE_OFFSET));
}

[[nodiscard]] std::uint64_t readPinValue(std::span<const Byte> pin_data) {
	constexpr std::size_t PIN_BYTE_LENGTH = 8;
	if (pin_data.size() != PIN_BYTE_LENGTH) {
		throw std::runtime_error("PIN File Error: Invalid file size.");
	}

	std::uint64_t value = 0;
	for (Byte byte : pin_data) {
		value = (value << 8) | static_cast<std::uint64_t>(byte);
	}
	return value;
}

[[nodiscard]] bool hasSupportedKdfMetadata(std::span<const Byte> data, std::size_t base_index) {
	if (!spanHasRange(data, base_index, KDF_METADATA_REGION_BYTES)) {
		return false;
	}

	const auto header = std::span<const Byte>(
		data.data() + base_index + KDF_MAGIC_OFFSET,
		KDF_METADATA_MAGIC_V2.size()
	);
	return
		data[base_index + KDF_ALG_OFFSET] == KDF_ALG_ARGON2ID13 &&
		data[base_index + KDF_SENTINEL_OFFSET] == KDF_SENTINEL &&
		std::ranges::equal(header, KDF_METADATA_MAGIC_V2);
}

[[nodiscard]] std::uint64_t generateRecoveryPin() {
	std::uint64_t pin = 0;
	do {
		randombytes_buf(&pin, sizeof(pin));
	} while (pin == 0);
	return pin;
}

[[nodiscard]] std::string extractFilenamePrefix(vBytes& payload) {
	constexpr const char* CORRUPT_FILE_ERROR = "File Recovery Error: Embedded profile is corrupt.";
	if (payload.empty()) {
		throw std::runtime_error(CORRUPT_FILE_ERROR);
	}

	const std::size_t filename_len = payload[0];
	if (filename_len == 0) {
		throw std::runtime_error(CORRUPT_FILE_ERROR);
	}
	const std::size_t prefix_len = 1 + filename_len;
	requireSpanRange(payload, 0, prefix_len, CORRUPT_FILE_ERROR);

	std::string decrypted_filename(
		reinterpret_cast<const char*>(payload.data() + 1),
		filename_len
	);

	const std::size_t old_payload_size = payload.size();
	const std::size_t compressed_payload_size = old_payload_size - prefix_len;
	if (compressed_payload_size > 0) {
		std::memmove(
			payload.data(),
			payload.data() + static_cast<std::ptrdiff_t>(prefix_len),
			compressed_payload_size
		);
		sodium_memzero(
			payload.data() + static_cast<std::ptrdiff_t>(compressed_payload_size),
			prefix_len
		);
	} else {
		sodium_memzero(payload.data(), old_payload_size);
	}
	payload.resize(compressed_payload_size);
	return decrypted_filename;
}
} // namespace

std::uint64_t encryptCompressedFileToProfile(
	vBytes& profile_vec,
	const fs::path& data_file_path,
	const std::string& data_filename,
	Option option,
	bool is_compressed_file,
	bool has_mastodon_option) {

	const auto& offsets = has_mastodon_option ? MASTODON_OFFSETS : DEFAULT_OFFSETS;
	constexpr const char* CORRUPT_PROFILE_ERROR = "Internal Error: Corrupt profile template.";

	requireSpanRange(profile_vec, offsets.kdf_metadata, KDF_METADATA_REGION_BYTES, CORRUPT_PROFILE_ERROR);
	if (offsets.encrypted_file != profile_vec.size()) {
		throw std::runtime_error(CORRUPT_PROFILE_ERROR);
	}

	if (data_filename.empty() || data_filename.size() > static_cast<std::size_t>(std::numeric_limits<Byte>::max())) {
		throw std::runtime_error("Data File Error: Invalid data filename length.");
	}

	vBytes filename_prefix(1 + data_filename.size());
	SensitiveBytesGuard filename_prefix_guard(filename_prefix);
	filename_prefix[0] = static_cast<Byte>(data_filename.size());
	std::memcpy(
		filename_prefix.data() + 1,
		data_filename.data(),
		data_filename.size()
	);

	SensitiveKeyData key;
	Salt salt{};
	StreamHeader stream_header{};
	const std::uint64_t pin = generateRecoveryPin();

	randombytes_buf(salt.data(), salt.size());
	deriveKeyFromPin(key.key, pin, salt);

	SecretStreamStateGuard stream_state;
	if (crypto_secretstream_xchacha20poly1305_init_push(&stream_state.state, stream_header.data(), key.key.data()) != 0) {
		throw std::runtime_error("crypto_secretstream init_push failed.");
	}

	profile_vec.insert(profile_vec.end(), stream_header.begin(), stream_header.end());

	vBytes cipher_chunk(STREAM_CHUNK_SIZE + crypto_secretstream_xchacha20poly1305_ABYTES);
	vBytes pending_compressed_chunk;
	SensitiveBytesGuard pending_chunk_guard(pending_compressed_chunk);
	pending_compressed_chunk.reserve(STREAM_CHUNK_SIZE * 2);

	appendEncryptedFrames(profile_vec, filename_prefix, stream_state.state, cipher_chunk);

	bool saw_compressed_output = false;
	zlibDeflateFile(data_file_path, option, is_compressed_file, [&](std::span<const Byte> chunk) {
		if (chunk.empty()) {
			return;
		}

		saw_compressed_output = true;
		if (!pending_compressed_chunk.empty()) {
			appendEncryptedFrames(profile_vec, pending_compressed_chunk, stream_state.state, cipher_chunk);
			sodium_memzero(pending_compressed_chunk.data(), pending_compressed_chunk.size());
			pending_compressed_chunk.clear();
		}

		pending_compressed_chunk.assign(chunk.begin(), chunk.end());
	});

	if (!saw_compressed_output || pending_compressed_chunk.empty()) {
		throw std::runtime_error("File Size Error: File is zero bytes. Probable compression failure.");
	}

	appendEncryptedFrames(
		profile_vec,
		pending_compressed_chunk,
		stream_state.state,
		cipher_chunk,
		crypto_secretstream_xchacha20poly1305_TAG_FINAL
	);
	sodium_memzero(pending_compressed_chunk.data(), pending_compressed_chunk.size());
	pending_compressed_chunk.clear();
	writeKdfMetadata(profile_vec, offsets, salt, stream_header, CORRUPT_PROFILE_ERROR);

	return pin;
}

std::optional<std::string> decryptDataFile(vBytes& png_vec, vBytes& pin_vec, bool is_mastodon_file) {
	const auto& offsets = is_mastodon_file ? MASTODON_OFFSETS : DEFAULT_OFFSETS;

	constexpr const char* CORRUPT_FILE_ERROR = "File Recovery Error: Embedded profile is corrupt.";
	requireSpanRange(png_vec, offsets.kdf_metadata, KDF_METADATA_REGION_BYTES, CORRUPT_FILE_ERROR);
	if (offsets.encrypted_file > png_vec.size()) {
		throw std::runtime_error(CORRUPT_FILE_ERROR);
	}

	if (!hasSupportedKdfMetadata(png_vec, offsets.kdf_metadata)) {
		throw std::runtime_error(
			"File Decryption Error: Unsupported legacy encrypted file format. "
			"Use an older pdvrdt release to recover this file.");
	}

	SensitiveBytesGuard pin_guard(pin_vec);
	const std::uint64_t recovery_pin = readPinValue(pin_vec);
	if (!pin_vec.empty()) {
		sodium_memzero(pin_vec.data(), pin_vec.size());
		pin_vec.clear();
	}
	pin_guard.release();

	SensitiveKeyData key;
	Salt salt{};
	StreamHeader stream_header{};

	requireSpanRange(png_vec, offsets.kdf_metadata + KDF_SALT_OFFSET, salt.size(), CORRUPT_FILE_ERROR);
	requireSpanRange(png_vec, offsets.kdf_metadata + KDF_NONCE_OFFSET, stream_header.size(), CORRUPT_FILE_ERROR);

	std::ranges::copy_n(
		png_vec.begin() + static_cast<std::ptrdiff_t>(offsets.kdf_metadata + KDF_SALT_OFFSET),
		salt.size(),
		salt.begin()
	);
	std::ranges::copy_n(
		png_vec.begin() + static_cast<std::ptrdiff_t>(offsets.kdf_metadata + KDF_NONCE_OFFSET),
		stream_header.size(),
		stream_header.begin()
	);

	deriveKeyFromPin(key.key, recovery_pin, salt);

	const std::size_t ciphertext_length = png_vec.size() - offsets.encrypted_file;
	const std::size_t min_stream_cipher_size =
		StreamHeader{}.size() + STREAM_FRAME_LEN_BYTES + crypto_secretstream_xchacha20poly1305_ABYTES;
	if (ciphertext_length < min_stream_cipher_size) {
		throw std::runtime_error(CORRUPT_FILE_ERROR);
	}

	const std::span<const Byte> framed_ciphertext(
		png_vec.data() + static_cast<std::ptrdiff_t>(offsets.encrypted_file),
		ciphertext_length
	);
	auto decrypted = decryptWithSecretStream(framed_ciphertext, key.key, stream_header);
	if (!decrypted) {
		return std::nullopt;
	}
	png_vec = std::move(*decrypted);

	return extractFilenamePrefix(png_vec);
}
