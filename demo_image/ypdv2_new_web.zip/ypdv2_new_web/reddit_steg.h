#pragma once

#include "common.h"

#include <cstdint>
#include <optional>
#include <span>

// Decoded, normalized carrier state for Reddit's metadata-free PNG path.
// The RGB samples are retained until encryption has completed so the final
// payload can be embedded without decoding or transcoding the cover twice.
struct RedditPngCarrier {
	vBytes rgb{};
	std::uint32_t width{};
	std::uint32_t height{};
	std::size_t payload_capacity{};
};

// Decode the already validated/optimized pdvrdt cover to opaque RGB8 and
// calculate the exact adaptive (15,4) carrier capacity.
[[nodiscard]] RedditPngCarrier prepareRedditPngCarrier(std::span<const Byte> png);

// Embed a raw payload using the PNGSTEG1 carrier format and encode a
// non-interlaced, metadata-free RGB PNG.
[[nodiscard]] vBytes embedRedditPngPayload(
	RedditPngCarrier& carrier,
	std::span<const Byte> payload);

// Return nullopt for an ordinary PNG or a CRC-valid generic PNGSTEG1 carrier.
// Once the PNGSTEG1 header is identified, structural or CRC failures are
// reported as corruption before the recovery PIN is requested.
[[nodiscard]] std::optional<vBytes> extractRedditPngPayload(
	std::span<const Byte> png);
