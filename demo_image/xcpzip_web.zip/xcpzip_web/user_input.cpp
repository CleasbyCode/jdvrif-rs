#include "pdvzip.h"

#include <format>
#include <fstream>
#include <limits>
#include <stdexcept>

namespace {

constexpr std::size_t MAX_ARG_LENGTH = 1024;

[[nodiscard]] bool fileTypeAcceptsArguments(FileType file_type) {
	return (file_type > FileType::PDF && file_type < FileType::UNKNOWN_FILE_TYPE)
		|| file_type == FileType::LINUX_EXECUTABLE
		|| file_type == FileType::JAR;
}

void validateArgsFilePath(const fs::path& filepath) {
	if (!hasValidFilename(filepath)) {
		throw std::runtime_error("Input Error: Arguments filename contains unsupported control characters.");
	}
	if (!fs::is_regular_file(filepath)) {
		throw std::runtime_error(std::format(
			"Input Error: Arguments file \"{}\" is not a regular file.", filepath.string()));
	}
}

[[nodiscard]] std::uintmax_t argsFileSize(const fs::path& filepath) {
	const auto file_size = fs::file_size(filepath);
	if (file_size > MAX_ARG_LENGTH) {
		throw std::runtime_error(std::format(
			"Input Error: Arguments file \"{}\" exceeds maximum length.", filepath.string()));
	}
	return file_size;
}

[[nodiscard]] std::string readArgsFileContents(const fs::path& filepath, std::uintmax_t file_size) {
	std::ifstream ifs(filepath, std::ios::binary);
	if (!ifs) {
		throw std::runtime_error(std::format(
			"Input Error: Unable to open arguments file \"{}\".", filepath.string()));
	}

	if (file_size > static_cast<std::uintmax_t>(std::numeric_limits<std::streamsize>::max())) {
		throw std::runtime_error("Input Error: Arguments file is too large to read.");
	}

	std::string data(static_cast<std::size_t>(file_size), '\0');
	if (!ifs.read(data.data(), static_cast<std::streamsize>(file_size))
		|| ifs.gcount() != static_cast<std::streamsize>(file_size)) {
		throw std::runtime_error(std::format(
			"Input Error: Failed to read arguments file \"{}\".", filepath.string()));
	}

	while (!data.empty() && (data.back() == '\n' || data.back() == '\r')) {
		data.pop_back();
	}

	return data;
}

std::string readArgsFile(const fs::path& filepath) {
	if (filepath.empty() || !fs::exists(filepath)) {
		return {};
	}

	validateArgsFilePath(filepath);

	const std::uintmax_t file_size = argsFileSize(filepath);
	if (file_size == 0) {
		return {};
	}

	return readArgsFileContents(filepath, file_size);
}

} // anonymous namespace

UserArguments loadArguments(
	FileType file_type,
	const fs::path& linux_args_file,
	const fs::path& windows_args_file) {

	UserArguments args;

	if (!fileTypeAcceptsArguments(file_type)) {
		return args;
	}

	if (file_type != FileType::WINDOWS_EXECUTABLE) {
		args.linux_args = readArgsFile(linux_args_file);
	}

	if (file_type != FileType::LINUX_EXECUTABLE) {
		args.windows_args = readArgsFile(windows_args_file);
	}

	return args;
}
