#include "conceal.h"
#include "encryption.h"
#include "image.h"
#include "io_utils.h"
#include "png_utils.h"
#include "compression.h"

#include <zlib.h>

#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <cerrno>
#include <format>
#include <initializer_list>
#include <limits>
#include <print>
#include <span>
#include <stdexcept>
#include <string_view>
#include <system_error>
#include <utility>

namespace {

// Profile template for default mode: data stored in a custom IDAT chunk.
constexpr auto DEFAULT_PROFILE = std::to_array<Byte>({
	0x75, 0x5D, 0x19, 0x3D, 0x72, 0xCE, 0x28, 0xA5, 0x60, 0x59, 0x17, 0x98, 0x13, 0x40, 0xB4, 0xDB,
	0x3D, 0x18, 0xEC, 0x10, 0xFA, 0xE8, 0xA1, 0xC3, 0x99, 0xD1, 0xCC, 0x34, 0x72, 0xA3, 0xC5, 0xB1,
	0xEF, 0xF6, 0x12, 0x18, 0x26, 0xF3, 0xAF, 0x77, 0x16, 0x44, 0x95, 0xEA, 0xBB, 0x27, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0xC6, 0x50, 0x3C, 0xEA, 0x5E, 0x9D, 0xF9, 0x90, 0x82
});

// ICC color profile template for Mastodon mode: data stored in an iCCP chunk.
constexpr auto MASTODON_PROFILE = std::to_array<Byte>({
	0x00, 0x00, 0x02, 0x98, 0x6C, 0x63, 0x6D, 0x73, 0x02, 0x10, 0x00, 0x00, 0x6D, 0x6E, 0x74, 0x72,
	0x52, 0x47, 0x42, 0x20, 0x58, 0x59, 0x5A, 0x20, 0x07, 0xE2, 0x00, 0x03, 0x00, 0x14, 0x00, 0x09,
	0x00, 0x0E, 0x00, 0x1D, 0x61, 0x63, 0x73, 0x70, 0x4D, 0x53, 0x46, 0x54, 0x00, 0x00, 0x00, 0x00,
	0x73, 0x61, 0x77, 0x73, 0x63, 0x74, 0x72, 0x6C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF6, 0xD6, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0xD3, 0x2D,
	0x68, 0x61, 0x6E, 0x64, 0xEB, 0x77, 0x1F, 0x3C, 0xAA, 0x53, 0x51, 0x02, 0xE9, 0x3E, 0x28, 0x6C,
	0x91, 0x46, 0xAE, 0x57, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x09, 0x64, 0x65, 0x73, 0x63, 0x00, 0x00, 0x00, 0xF0, 0x00, 0x00, 0x00, 0x1C,
	0x77, 0x74, 0x70, 0x74, 0x00, 0x00, 0x01, 0x0C, 0x00, 0x00, 0x00, 0x14, 0x72, 0x58, 0x59, 0x5A,
	0x00, 0x00, 0x01, 0x20, 0x00, 0x00, 0x00, 0x14, 0x67, 0x58, 0x59, 0x5A, 0x00, 0x00, 0x01, 0x34,
	0x00, 0x00, 0x00, 0x14, 0x62, 0x58, 0x59, 0x5A, 0x00, 0x00, 0x01, 0x48, 0x00, 0x00, 0x00, 0x14,
	0x72, 0x54, 0x52, 0x43, 0x00, 0x00, 0x01, 0x5C, 0x00, 0x00, 0x00, 0x34, 0x67, 0x54, 0x52, 0x43,
	0x00, 0x00, 0x01, 0x5C, 0x00, 0x00, 0x00, 0x34, 0x62, 0x54, 0x52, 0x43, 0x00, 0x00, 0x01, 0x5C,
	0x00, 0x00, 0x00, 0x34, 0x63, 0x70, 0x72, 0x74, 0x00, 0x00, 0x01, 0x90, 0x00, 0x00, 0x00, 0x01,
	0x64, 0x65, 0x73, 0x63, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x6E, 0x52, 0x47, 0x42,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x58, 0x59, 0x5A, 0x20,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF3, 0x54, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x16, 0xC9,
	0x58, 0x59, 0x5A, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x6F, 0xA0, 0x00, 0x00, 0x38, 0xF2,
	0x00, 0x00, 0x03, 0x8F, 0x58, 0x59, 0x5A, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x62, 0x96,
	0x00, 0x00, 0xB7, 0x89, 0x00, 0x00, 0x18, 0xDA, 0x58, 0x59, 0x5A, 0x20, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x24, 0xA0, 0x00, 0x00, 0x0F, 0x85, 0x00, 0x00, 0xB6, 0xC4, 0x63, 0x75, 0x72, 0x76,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x14, 0x00, 0x00, 0x01, 0x07, 0x02, 0xB5, 0x05, 0x6B,
	0x09, 0x36, 0x0E, 0x50, 0x14, 0xB1, 0x1C, 0x80, 0x25, 0xC8, 0x30, 0xA1, 0x3D, 0x19, 0x4B, 0x40,
	0x5B, 0x27, 0x6C, 0xDB, 0x80, 0x6B, 0x95, 0xE3, 0xAD, 0x50, 0xC6, 0xC2, 0xE2, 0x31, 0xFF, 0xFF,
	0x00, 0x12, 0xB7, 0x19, 0x18, 0xA4, 0xEF, 0x15, 0x8F, 0x9E, 0x7B, 0xB4, 0xF3, 0xAA, 0x0A, 0x5C,
	0x80, 0x54, 0xAF, 0xC8, 0x0E, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xC6, 0x50, 0x3C, 0xEA, 0x5E, 0x9D, 0xF9, 0x90
});

struct PlatformLimits {
	std::string_view name;
	std::size_t max_size;
	bool requires_good_dims;
};

constexpr std::array PLATFORM_LIMITS = {
	PlatformLimits{ "Flickr",    200ULL * 1024 * 1024, false },
	PlatformLimits{ "ImgBB",      32ULL * 1024 * 1024, false },
	PlatformLimits{ "PostImage",  32ULL * 1024 * 1024, false },
	PlatformLimits{ "ImgPile",     8ULL * 1024 * 1024, false },
	PlatformLimits{ "X-Twitter",   5ULL * 1024 * 1024, true  },
};

[[nodiscard]] std::pair<std::size_t, std::string_view> sizeLimitForOption(Option option) {
	constexpr std::size_t
		MAX_SIZE_DEFAULT  = 2ULL * 1024 * 1024 * 1024,
		MAX_SIZE_REDDIT   = 20ULL * 1024 * 1024,
		MAX_SIZE_MASTODON = 16ULL * 1024 * 1024;

	switch (option) {
		case Option::Mastodon: return { MAX_SIZE_MASTODON, "Mastodon" };
		case Option::Reddit:   return { MAX_SIZE_REDDIT,   "Reddit" };
		default:               return { MAX_SIZE_DEFAULT,  "pdvrdt" };
	}
}

void validateSizeLimit(std::size_t size, Option option, std::string_view subject) {
	const auto [limit, label] = sizeLimitForOption(option);
	if (size > limit) {
		throw std::runtime_error(std::format(
			"File Size Error: {} exceeds maximum size limit for {}.", subject, label));
	}
}

void validateDataFilename(const std::string& data_filename) {
	constexpr std::size_t FILENAME_MAX_LEN = 20;
	if (data_filename.size() > FILENAME_MAX_LEN) {
		throw std::runtime_error("Data File Error: For compatibility requirements, length of data filename must not exceed 20 characters.");
	}
}

[[nodiscard]] bool isLikelyCompressedInputFile(const fs::path& path) {
	return hasFileExtension(path, {
		".zip", ".jar", ".rar", ".7z", ".bz2", ".gz", ".xz", ".lz", ".lz4", ".cab", ".rpm", ".deb",
		".mp4", ".mp3", ".exe", ".jpg", ".jpeg", ".jfif", ".png", ".webp", ".gif", ".ogg", ".flac"
	});
}

[[nodiscard]] std::uint32_t checkedChunkDataSize(std::size_t payload_size, std::size_t chunk_diff) {
	if (payload_size > std::numeric_limits<std::uint32_t>::max() - chunk_diff) {
		throw std::runtime_error("PNG Error: Chunk payload exceeds PNG chunk size limit.");
	}
	return static_cast<std::uint32_t>(payload_size + chunk_diff);
}

[[nodiscard]] std::size_t checkedChunkTotalSize(std::size_t payload_size, std::size_t chunk_diff) {
	constexpr std::size_t CHUNK_OVERHEAD = 12;
	return static_cast<std::size_t>(checkedChunkDataSize(payload_size, chunk_diff)) + CHUNK_OVERHEAD;
}

[[nodiscard]] std::uint32_t checkedChunkDataSizeFromParts(std::initializer_list<std::span<const Byte>> chunk_data_parts) {
	std::size_t total = 0;
	for (const auto part : chunk_data_parts) {
		if (part.size() > std::numeric_limits<std::uint32_t>::max() - total) {
			throw std::runtime_error("PNG Error: Chunk payload exceeds PNG chunk size limit.");
		}
		total += part.size();
	}
	return static_cast<std::uint32_t>(total);
}

struct OutputFileHandle {
	fs::path path{};
	int fd{-1};
};

[[nodiscard]] OutputFileHandle createUniqueOutputFile() {
	constexpr std::size_t MAX_ATTEMPTS = 2048;

	for (std::size_t i = 0; i < MAX_ATTEMPTS; ++i) {
		const uint32_t rand_num = 100000 + randombytes_uniform(900000);
		const fs::path candidate = std::format("prdt_{}.png", rand_num);

		int flags = O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC;
#ifdef O_NOFOLLOW
		flags |= O_NOFOLLOW;
#endif
		const int fd = ::open(candidate.c_str(), flags, S_IRUSR | S_IWUSR);
		if (fd >= 0) {
			return OutputFileHandle{ .path = candidate, .fd = fd };
		}

		if (errno == EEXIST) {
			continue;
		}

		const std::error_code ec(errno, std::generic_category());
		throw std::runtime_error(std::format("Write Error: Unable to create output file: {}", ec.message()));
	}
	throw std::runtime_error("Write Error: Unable to allocate output filename.");
}

void writeUint32OrThrow(int fd, std::uint32_t value) {
	std::array<Byte, 4> bytes{};
	updateValue(bytes, 0, value);
	writeAllToFd(fd, bytes);
}

uLong updateCrc32(uLong crc, std::span<const Byte> data) {
	std::size_t offset = 0;
	while (offset < data.size()) {
		const std::size_t chunk_size = std::min<std::size_t>(
			data.size() - offset,
			static_cast<std::size_t>(std::numeric_limits<uInt>::max())
		);
		crc = crc32(
			crc,
			data.data() + static_cast<std::ptrdiff_t>(offset),
			static_cast<uInt>(chunk_size)
		);
		offset += chunk_size;
	}
	return crc;
}

void writeChunkFromParts(int fd, std::span<const Byte> chunk_type, std::initializer_list<std::span<const Byte>> chunk_data_parts) {
	if (chunk_type.size() != 4) {
		throw std::invalid_argument("PNG Error: Invalid chunk type size.");
	}

	const std::uint32_t chunk_data_size = checkedChunkDataSizeFromParts(chunk_data_parts);
	writeUint32OrThrow(fd, chunk_data_size);
	writeAllToFd(fd, chunk_type);

	uLong crc = crc32(0L, Z_NULL, 0);
	crc = updateCrc32(crc, chunk_type);

	for (const auto part : chunk_data_parts) {
		writeAllToFd(fd, part);
		crc = updateCrc32(crc, part);
	}

	writeUint32OrThrow(fd, static_cast<std::uint32_t>(crc));
}

void verifyFdSize(int fd, std::size_t expected_size) {
	struct stat st{};
	if (::fstat(fd, &st) != 0) {
		const std::error_code ec(errno, std::generic_category());
		throw std::runtime_error(std::format("Write Error: Unable to verify output file size: {}", ec.message()));
	}
	if (st.st_size < 0 || static_cast<std::uintmax_t>(st.st_size) != static_cast<std::uintmax_t>(expected_size)) {
		throw std::runtime_error(std::format(
			"Write Error: Output file size mismatch. Expected {} bytes, wrote {} bytes.",
			expected_size,
			st.st_size < 0 ? 0 : static_cast<std::uintmax_t>(st.st_size)));
	}
}

void writeRedditPaddingChunk(int fd) {
	constexpr std::uint32_t REDDIT_PADDING_BYTES = 0x80000;
	constexpr auto TYPE_IDAT = std::to_array<Byte>({ 0x49, 0x44, 0x41, 0x54 });
	constexpr auto IDAT_REDDIT_CRC = std::to_array<Byte>({ 0xA3, 0x1A, 0x50, 0xFA });

	writeUint32OrThrow(fd, REDDIT_PADDING_BYTES);
	writeAllToFd(fd, TYPE_IDAT);

	std::array<Byte, 8192> zeros{};
	std::size_t remaining = REDDIT_PADDING_BYTES;
	while (remaining != 0) {
		const std::size_t chunk_size = std::min(remaining, zeros.size());
		writeAllToFd(fd, std::span<const Byte>(zeros.data(), chunk_size));
		remaining -= chunk_size;
	}

	writeAllToFd(fd, IDAT_REDDIT_CRC);
}

std::vector<std::string> getCompatiblePlatforms(Option option, std::size_t output_size, bool has_bad_dims, bool twitter_iccp_compatible) {

	if (option == Option::Reddit) {
		return { "Reddit. (Only share this \"file-embedded\" PNG image on Reddit)." };
	}

	if (option == Option::Mastodon) {
		if (twitter_iccp_compatible && !has_bad_dims) {
			return { "Mastodon and X-Twitter." };
		}
		return { "Mastodon. (Only share this \"file-embedded\" PNG image on Mastodon)." };
	}

	std::vector<std::string> platforms;
	for (const auto& [name, max_size, needs_good_dims] : PLATFORM_LIMITS) {
		if (output_size <= max_size && (!needs_good_dims || !has_bad_dims)) {
			platforms.emplace_back(name);
		}
	}

	if (platforms.empty()) {
		platforms.emplace_back(
			"Unknown!\n\n Due to the large file size of the output PNG image, I'm unaware of any\n"
			" compatible platforms that this image can be posted on. Local use only?");
	}

	return platforms;
}

template <typename Writer>
void writeOutputFile(std::size_t output_size, std::uint64_t& pin, Writer&& writer) {
	OutputFileHandle output_file = createUniqueOutputFile();

	try {
		std::forward<Writer>(writer)(output_file.fd);
		verifyFdSize(output_file.fd, output_size);
		closeFdOrThrow(output_file.fd);
	} catch (...) {
		closeFdNoThrow(output_file.fd);
		cleanupPathNoThrow(output_file.path);
		throw;
	}

	std::println("\nSaved \"file-embedded\" PNG image: {} ({} bytes).", output_file.path.string(), output_size);
	std::println("\nRecovery PIN: [***{}***]\n\nImportant: Keep your PIN safe, so that you can extract the hidden file.\n\nComplete!\n", pin);
	sodium_memzero(&pin, sizeof(pin));
}

[[nodiscard]] vBytes makeProfileTemplate(bool is_mastodon) {
	if (is_mastodon) {
		return vBytes(MASTODON_PROFILE.begin(), MASTODON_PROFILE.end());
	}
	return vBytes(DEFAULT_PROFILE.begin(), DEFAULT_PROFILE.end());
}

void printPlatformCompatibility(Option option, std::size_t output_size, bool has_bad_dims, bool twitter_iccp_compatible) {
	const auto platforms = getCompatiblePlatforms(option, output_size, has_bad_dims, twitter_iccp_compatible);

	std::println("\nPlatform compatibility for output image:-\n");
	for (const auto& platform : platforms) {
		std::println(" ✓ {}", platform);
	}
}

void writePngTailFrom(int fd, const vBytes& png_vec, std::size_t offset) {
	writeAllToFd(
		fd,
		std::span<const Byte>(
			png_vec.data() + static_cast<std::ptrdiff_t>(offset),
			png_vec.size() - offset
		)
	);
}

[[nodiscard]] vBytes deflateMastodonProfile(const vBytes& profile_vec, Option option, bool is_compressed) {
	vBytes compressed_profile;
	zlibDeflateSpan(
		std::span<const Byte>(profile_vec.data(), profile_vec.size()),
		option,
		is_compressed,
		[&](std::span<const Byte> chunk) {
			compressed_profile.insert(compressed_profile.end(), chunk.begin(), chunk.end());
		}
	);
	return compressed_profile;
}

void writeMastodonOutput(
	const vBytes& png_vec,
	const vBytes& profile_vec,
	Option option,
	bool is_compressed,
	bool has_bad_dims,
	std::uint64_t& pin) {

	constexpr std::size_t
		MASTODON_INSERT_INDEX     = 0x21,
		TWITTER_ICCP_MAX_CHUNK_SIZE = 10ULL * 1024,
		TWITTER_IMAGE_MAX_SIZE      = 5ULL * 1024 * 1024,
		ICCP_SIZE_DIFF              = 5;
	constexpr auto TYPE_ICCP = std::to_array<Byte>({ 0x69, 0x43, 0x43, 0x50 });
	constexpr auto ICCP_PREFIX = std::to_array<Byte>({ 0x69, 0x63, 0x63, 0x00, 0x00 });

	const vBytes compressed_profile = deflateMastodonProfile(profile_vec, option, is_compressed);
	const std::uint32_t mastodon_chunk_data_size = checkedChunkDataSize(compressed_profile.size(), ICCP_SIZE_DIFF);
	if (MASTODON_INSERT_INDEX > png_vec.size()) {
		throw std::runtime_error("Image File Error: Invalid PNG insertion point for iCCP chunk.");
	}

	const std::size_t output_size = checkedAddSize(
		png_vec.size(),
		checkedChunkTotalSize(compressed_profile.size(), ICCP_SIZE_DIFF),
		"File Size Error: Final output size overflow."
	);
	const bool twitter_iccp_compatible =
		output_size <= TWITTER_IMAGE_MAX_SIZE &&
		mastodon_chunk_data_size <= TWITTER_ICCP_MAX_CHUNK_SIZE;

	validateSizeLimit(output_size, option, "Final output PNG");
	printPlatformCompatibility(option, output_size, has_bad_dims, twitter_iccp_compatible);

	writeOutputFile(output_size, pin, [&](int fd) {
		writeAllToFd(fd, std::span<const Byte>(png_vec.data(), MASTODON_INSERT_INDEX));
		writeChunkFromParts(fd, TYPE_ICCP, {
			std::span<const Byte>(ICCP_PREFIX.data(), ICCP_PREFIX.size()),
			std::span<const Byte>(compressed_profile.data(), compressed_profile.size())
		});
		writePngTailFrom(fd, png_vec, MASTODON_INSERT_INDEX);
	});
}

void writeDefaultOutput(
	const vBytes& png_vec,
	const vBytes& profile_vec,
	Option option,
	bool is_reddit,
	bool has_bad_dims,
	std::uint64_t& pin) {

	constexpr std::size_t
		DEFAULT_INSERT_DIFF = 12,
		IDAT_SIZE_DIFF = 3,
		REDDIT_PADDING_CHUNK_TOTAL_SIZE = 0x80000 + 12;
	constexpr auto TYPE_IDAT = std::to_array<Byte>({ 0x49, 0x44, 0x41, 0x54 });
	constexpr auto IDAT_PREFIX = std::to_array<Byte>({ 0x78, 0x5E, 0x5C });

	if (png_vec.size() < DEFAULT_INSERT_DIFF) {
		throw std::runtime_error("Image File Error: Invalid PNG insertion point for IDAT chunk.");
	}

	const std::size_t insert_index = png_vec.size() - DEFAULT_INSERT_DIFF;
	std::size_t output_size = checkedAddSize(
		png_vec.size(),
		checkedChunkTotalSize(profile_vec.size(), IDAT_SIZE_DIFF),
		"File Size Error: Final output size overflow."
	);
	if (is_reddit) {
		output_size = checkedAddSize(
			output_size,
			REDDIT_PADDING_CHUNK_TOTAL_SIZE,
			"File Size Error: Final output size overflow."
		);
	}

	validateSizeLimit(output_size, option, "Final output PNG");
	printPlatformCompatibility(option, output_size, has_bad_dims, false);

	writeOutputFile(output_size, pin, [&](int fd) {
		writeAllToFd(fd, std::span<const Byte>(png_vec.data(), insert_index));
		if (is_reddit) {
			writeRedditPaddingChunk(fd);
		}
		writeChunkFromParts(fd, TYPE_IDAT, {
			std::span<const Byte>(IDAT_PREFIX.data(), IDAT_PREFIX.size()),
			std::span<const Byte>(profile_vec.data(), profile_vec.size())
		});
		writePngTailFrom(fd, png_vec, insert_index);
	});
}
} // namespace

void concealData(vBytes& png_vec, Option option, const fs::path& data_file_path) {
	constexpr std::size_t LARGE_FILE_SIZE = 300ULL * 1024 * 1024;

	const bool is_mastodon = (option == Option::Mastodon);
	const bool is_reddit   = (option == Option::Reddit);

	const std::size_t data_file_size = getFileSizeChecked(data_file_path);
	std::string data_filename = data_file_path.filename().string();
	validateDataFilename(data_filename);

	if (data_file_size > LARGE_FILE_SIZE) {
		std::println("\nPlease wait. Larger files will take longer to complete this process.");
	}

	const bool has_bad_dims = optimizeImage(png_vec);

	const bool is_compressed = isLikelyCompressedInputFile(data_file_path);
	vBytes profile_vec = makeProfileTemplate(is_mastodon);
	std::uint64_t pin = encryptCompressedFileToProfile(
		profile_vec,
		data_file_path,
		data_filename,
		option,
		is_compressed,
		is_mastodon
	);

	if (is_mastodon) {
		writeMastodonOutput(png_vec, profile_vec, option, is_compressed, has_bad_dims, pin);
	} else {
		writeDefaultOutput(png_vec, profile_vec, option, is_reddit, has_bad_dims, pin);
	}
}
