#include "segmentation.h"
#include "binary_io.h"
#include "embedded_layout.h"
#include "file_utils.h"
#include "signal_utils.h"

#include <algorithm>
#include <cstring>
#include <limits>
#include <string>
#include <stdexcept>

#include <fcntl.h>
#include <unistd.h>

namespace {
constexpr std::size_t
    SOI_SIG_LENGTH           = 2,
    SEGMENT_SIG_LENGTH       = 2,
    SEGMENT_HEADER_LENGTH    = ICC_SEGMENT_LAYOUT.segment_header_length,
    SEGMENT_DATA_SIZE        = ICC_SEGMENT_LAYOUT.per_segment_payload_size,
    INITIAL_HEADER_BYTES     = ICC_SEGMENT_LAYOUT.initial_header_bytes,
    PROFILE_DATA_SIZE        = ICC_SEGMENT_LAYOUT.profile_data_size,
    PROFILE_SIZE_DIFF        = ICC_SEGMENT_LAYOUT.profile_size_diff,
    VALUE_BYTE_LENGTH        = 4,
    MAX_SINGLE_SEGMENT_SIZE  = SEGMENT_DATA_SIZE + SOI_SIG_LENGTH + SEGMENT_SIG_LENGTH + SEGMENT_HEADER_LENGTH;

constexpr auto ICC_HEADER_TEMPLATE = std::to_array<Byte>({
    0xFF, 0xE2, 0x00, 0x00,
    'I','C','C','_','P','R','O','F','I','L','E',
    0x00, 0x00, 0x01
});

[[nodiscard]] std::array<Byte, 18> makeIccHeader(uint16_t segment_length, std::size_t segment_index) {
    auto header = ICC_HEADER_TEMPLATE;
    header[2] = static_cast<Byte>(segment_length >> 8);
    header[3] = static_cast<Byte>(segment_length & 0xFF);
    header[15] = static_cast<Byte>(segment_index >> 8);
    header[16] = static_cast<Byte>(segment_index & 0xFF);
    return header;
}

// Payload = an optional in-memory template prefix (the bytes of segment_vec
// beyond its header) followed by the encrypted file. The encrypted portion is
// held as a raw fd so it can be streamed to the output via sendfile(2) instead
// of being copied through user space.
struct PayloadSource {
    std::span<const Byte> template_payload{};
    int         encrypted_fd{-1};
    std::size_t template_offset{0};
    std::size_t encrypted_offset{0};
    std::size_t encrypted_left{0};

    PayloadSource(
        std::span<const Byte> template_payload_arg,
        const fs::path& encrypted_path,
        std::size_t encrypted_size)
        : template_payload(template_payload_arg),
          encrypted_left(encrypted_size) {
        encrypted_fd = ::open(encrypted_path.c_str(), O_RDONLY | O_CLOEXEC);
        if (encrypted_fd < 0) {
            throw std::runtime_error("Read Error: Failed to open encrypted payload.");
        }
        (void)::posix_fadvise(encrypted_fd, 0, 0, POSIX_FADV_SEQUENTIAL);
    }

    ~PayloadSource() {
        if (encrypted_fd >= 0) ::close(encrypted_fd);
    }

    PayloadSource(const PayloadSource&) = delete;
    PayloadSource& operator=(const PayloadSource&) = delete;

    // Append `size` payload bytes to output: the template prefix (buffered copy)
    // first, then the encrypted-file remainder via sendfile (zero-copy).
    void copyTo(OutputFile& output, std::size_t size) {
        std::size_t left = size;
        if (template_offset < template_payload.size()) {
            const std::size_t take = std::min(left, template_payload.size() - template_offset);
            output.write(template_payload.subspan(template_offset, take), WRITE_COMPLETE_ERROR);
            template_offset += take;
            left -= take;
        }
        if (left > 0) {
            if (left > encrypted_left) {
                throw std::runtime_error("Read Error: Encrypted payload is shorter than expected.");
            }
            output.sendFrom(encrypted_fd, encrypted_offset, left, "Read Error: Failed while reading encrypted payload.");
            encrypted_offset += left;
            encrypted_left   -= left;
        }
    }

    [[nodiscard]] bool exhausted() const noexcept {
        return template_offset == template_payload.size() && encrypted_left == 0;
    }
};

void writeOutput(OutputFile& output, std::span<const Byte> bytes) {
    output.write(bytes, WRITE_COMPLETE_ERROR);
}

void copyFileToOutput(const fs::path& input_path, OutputFile& output, std::size_t length) {
    PayloadSource payload_source(std::span<const Byte>{}, input_path, length);
    payload_source.copyTo(output, length);
    if (!payload_source.exhausted()) {
        throw std::runtime_error("Read Error: Encrypted payload is longer than expected.");
    }
}

[[nodiscard]] std::size_t requiredIccSegments(std::size_t payload_size) {
    if (payload_size == 0) {
        throw std::runtime_error("File Size Error: Segment count exceeds supported limit.");
    }

    const std::size_t segments_required = 1 + ((payload_size - 1) / SEGMENT_DATA_SIZE);
    if (segments_required > static_cast<std::size_t>(std::numeric_limits<uint16_t>::max())) {
        throw std::runtime_error("File Size Error: Segment count exceeds supported limit.");
    }
    return segments_required;
}

[[nodiscard]] SegmentedEmbedSummary writeIccDataToOutput(
    OutputFile& output,
    vBytes& segment_vec,
    const fs::path& encrypted_path,
    std::size_t encrypted_size) {

    if (segment_vec.size() < INITIAL_HEADER_BYTES) {
        throw std::runtime_error("File Extraction Error: Corrupt segment header.");
    }

    const std::size_t single_segment_size = checkedAdd(
        segment_vec.size(),
        encrypted_size,
        "File Size Error: Segment output size overflow.");

    if (single_segment_size <= MAX_SINGLE_SEGMENT_SIZE) {
        const std::size_t segment_size = single_segment_size - (SOI_SIG_LENGTH + SEGMENT_SIG_LENGTH);
        const std::size_t profile_size = segment_size - PROFILE_SIZE_DIFF;

        updateValue(segment_vec, ICC_SEGMENT_LAYOUT.segment_header_size_index, segment_size);
        updateValue(segment_vec, ICC_SEGMENT_LAYOUT.profile_size_index, profile_size);
        updateValue(segment_vec, ICC_SEGMENT_LAYOUT.encrypted_file_size_index, single_segment_size - PROFILE_DATA_SIZE, VALUE_BYTE_LENGTH);

        writeOutput(output, std::span<const Byte>(segment_vec));
        copyFileToOutput(encrypted_path, output, encrypted_size);

        return SegmentedEmbedSummary{
            .embedded_image_size = single_segment_size,
            .first_segment_size = static_cast<uint16_t>(segment_size),
            .total_segments = 0,
        };
    }

    const std::size_t payload_prefix_size = segment_vec.size() - INITIAL_HEADER_BYTES;
    const std::size_t payload_size = checkedAdd(
        payload_prefix_size,
        encrypted_size,
        "File Size Error: Segment output size overflow.");
    const std::size_t segments_required = requiredIccSegments(payload_size);

    updateValue(segment_vec, ICC_SEGMENT_LAYOUT.template_total_profile_header_segments_index, segments_required);

    const std::size_t total_header_bytes = checkedMul(
        segments_required,
        SEGMENT_SIG_LENGTH + SEGMENT_HEADER_LENGTH,
        "File Size Error: Segment output size overflow.");
    const std::size_t icc_data_size = checkedAdd(
        SOI_SIG_LENGTH,
        checkedAdd(payload_size, total_header_bytes, "File Size Error: Segment output size overflow."),
        "File Size Error: Segment output size overflow.");
    updateValue(segment_vec, ICC_SEGMENT_LAYOUT.encrypted_file_size_index, icc_data_size - PROFILE_DATA_SIZE, VALUE_BYTE_LENGTH);

    writeOutput(output, std::span<const Byte>(segment_vec.data(), SOI_SIG_LENGTH));

    PayloadSource payload_source(
        std::span<const Byte>(segment_vec.data() + INITIAL_HEADER_BYTES, payload_prefix_size),
        encrypted_path,
        encrypted_size);

    // Each segment is an 18-byte ICC header (buffered into the OutputFile,
    // coalescing many headers into few write(2) calls) followed by its data
    // portion, which copyTo() streams straight from the encrypted file via
    // sendfile(2) — the payload never passes through user space.
    std::size_t payload_left = payload_size;
    for (std::size_t seg = 1; seg <= segments_required; ++seg) {
        throwIfSignalCancellationRequested();
        const std::size_t data_size = std::min(payload_left, SEGMENT_DATA_SIZE);
        const auto header = makeIccHeader(static_cast<uint16_t>(data_size + SEGMENT_HEADER_LENGTH), seg);

        writeOutput(output, std::span<const Byte>(header));
        payload_source.copyTo(output, data_size);

        payload_left -= data_size;
    }

    if (payload_left != 0 || !payload_source.exhausted()) {
        throw std::runtime_error("Read Error: Encrypted payload size mismatch.");
    }

    return SegmentedEmbedSummary{
        .embedded_image_size = icc_data_size,
        .first_segment_size = static_cast<uint16_t>(std::min(payload_size, SEGMENT_DATA_SIZE) + SEGMENT_HEADER_LENGTH),
        .total_segments = static_cast<uint16_t>(segments_required),
    };
}
} // namespace

void filterPlatforms(vString& platforms_vec, std::size_t embedded_size, uint16_t first_segment_size, uint16_t total_segments) {
    std::erase_if(platforms_vec, [&](const std::string& platform) {
        for (const auto& [name, max_img, max_seg, max_segs] : PLATFORM_LIMITS) {
            if (platform == name) {
                return embedded_size > max_img
                    || first_segment_size > max_seg
                    || total_segments > max_segs;
            }
        }
        return false;
    });

    if (platforms_vec.empty()) {
        platforms_vec.emplace_back(
            "\b\bUnknown!\n\n Due to the large file size of the output JPG image, "
            "I'm unaware of any\n compatible platforms that this image can be "
            "posted on. Local use only?");
    }
}

[[nodiscard]] SegmentedEmbedSummary writeEmbeddedJpgFromEncryptedFile(
    OutputFile& output,
    vBytes& segment_vec,
    const fs::path& encrypted_path,
    std::span<const Byte> jpg_vec) {

    const std::size_t encrypted_size = checkedFileSize(
        encrypted_path,
        "Read Error: Invalid encrypted payload size.",
        true);

    SegmentedEmbedSummary summary = writeIccDataToOutput(output, segment_vec, encrypted_path, encrypted_size);
    writeOutput(output, jpg_vec);
    summary.embedded_image_size = checkedAdd(
        summary.embedded_image_size,
        jpg_vec.size(),
        "File Size Error: Embedded image size overflow.");
    return summary;
}
