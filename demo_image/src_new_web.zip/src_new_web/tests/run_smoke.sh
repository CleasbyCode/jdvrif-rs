#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [[ -f "$ROOT_DIR/compile_pdvrdt.sh" ]]; then
  SRC_DIR="$ROOT_DIR"
elif [[ -f "$ROOT_DIR/src/compile_pdvrdt.sh" ]]; then
  SRC_DIR="$ROOT_DIR/src"
else
  echo "FAIL: unable to locate compile_pdvrdt.sh from $ROOT_DIR" >&2
  exit 1
fi
WORK_DIR="${TMPDIR:-/tmp}/pdvrdt_smoke"

build_pdvrdt() {
  (
    cd "$SRC_DIR"
    bash ./compile_pdvrdt.sh
  )
}

make_cover_png() {
  local generator_cpp="$WORK_DIR/make_cover.cpp"
  cat > "$generator_cpp" <<'CPP'
#include "lodepng/lodepng.h"
#include <vector>
#include <cstdint>

int main() {
  const unsigned w = 96;
  const unsigned h = 96;
  std::vector<unsigned char> img(static_cast<std::size_t>(w) * h * 4);

  for (unsigned y = 0; y < h; ++y) {
    for (unsigned x = 0; x < w; ++x) {
      const std::size_t i = static_cast<std::size_t>(y) * w * 4 + static_cast<std::size_t>(x) * 4;
      img[i + 0] = static_cast<unsigned char>((x * 3 + y) & 0xFF);
      img[i + 1] = static_cast<unsigned char>((y * 5 + x) & 0xFF);
      img[i + 2] = static_cast<unsigned char>((x + y * 2) & 0xFF);
      img[i + 3] = 255;
    }
  }

  return lodepng_encode32_file("cover.png", img.data(), w, h);
}
CPP

  (
    cd "$WORK_DIR"
    g++ -std=c++23 -O2 -I"$SRC_DIR" "$generator_cpp" "$SRC_DIR/lodepng/lodepng.cpp" -o make_cover
    ./make_cover
  )
}

run_mode() {
  local mode_name="$1"
  local mode_arg="$2"
  local secret="secret_${mode_name}.txt"
  local ref="${secret}.ref"

  printf 'pdvrdt smoke payload for mode=%s\nline2\n' "$mode_name" > "$secret"
  cp "$secret" "$ref"

  local conceal_out
  if [[ -n "$mode_arg" ]]; then
    conceal_out=$(./pdvrdt conceal "$mode_arg" cover.png "$secret")
  else
    conceal_out=$(./pdvrdt conceal cover.png "$secret")
  fi

  local pin
  pin=$(printf '%s\n' "$conceal_out" | sed -n 's/.*Recovery PIN: \[\*\*\*\([0-9][0-9]*\)\*\*\*\].*/\1/p' | tail -n1)
  local out_img
  out_img=$(printf '%s\n' "$conceal_out" | sed -n 's/^Saved "file-embedded" PNG image: \([^ ]*\) (.*/\1/p' | tail -n1)

  if [[ -z "$pin" || -z "$out_img" || ! -f "$out_img" ]]; then
    echo "FAIL: unable to parse conceal output for $mode_name" >&2
    printf '%s\n' "$conceal_out" >&2
    return 1
  fi

  rm -f "$secret"
  local recover_out
  recover_out=$(printf '%s\n' "$pin" | ./pdvrdt recover "$out_img")

  local rec_file
  rec_file=$(printf '%s\n' "$recover_out" | sed -n 's/^Extracted hidden file: \([^ ]*\) (.*/\1/p' | tail -n1)

  if [[ -z "$rec_file" || ! -f "$rec_file" ]]; then
    echo "FAIL: unable to parse recover output for $mode_name" >&2
    printf '%s\n' "$recover_out" >&2
    return 1
  fi

  if ! cmp -s "$ref" "$rec_file"; then
    echo "FAIL: payload mismatch for $mode_name" >&2
    return 1
  fi

  echo "PASS $mode_name : $out_img -> $rec_file"
  rm -f "$ref" "$rec_file" "$out_img"
}

main() {
  rm -rf "$WORK_DIR"
  mkdir -p "$WORK_DIR"

  echo "[1/3] Building pdvrdt"
  build_pdvrdt

  cp "$SRC_DIR/pdvrdt" "$WORK_DIR/"

  echo "[2/3] Generating deterministic PNG cover fixture"
  make_cover_png

  echo "[3/3] Running smoke round-trips"
  (
    cd "$WORK_DIR"
    run_mode default ""
    run_mode mastodon "-m"
    run_mode reddit "-r"
  )

  echo "ALL_SMOKE_TESTS_PASSED"
}

main "$@"
