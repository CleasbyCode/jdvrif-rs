#include "encryption.h"
#include "io_utils.h"

#include <algorithm>
#include <charconv>
#include <cstring>
#include <limits>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string_view>

namespace {
constexpr auto KDF_METADATA_MAGIC_V2 = std::to_array<Byte>({'K', 'D', 'F', '2'});

struct SensitiveKeyData {
  Key key{};

  ~SensitiveKeyData() {
    sodium_memzero(key.data(), key.size());
  }

  SensitiveKeyData(const SensitiveKeyData&) = delete;
  SensitiveKeyData& operator=(const SensitiveKeyData&) = delete;
  SensitiveKeyData() = default;
};

struct SensitiveBytesGuard {
  vBytes* bytes{};
  bool active{true};

  SensitiveBytesGuard(const SensitiveBytesGuard&) = delete;
  SensitiveBytesGuard& operator=(const SensitiveBytesGuard&) = delete;

  explicit SensitiveBytesGuard(vBytes& in_bytes) : bytes(&in_bytes) {}

  ~SensitiveBytesGuard() {
    if (active && bytes != nullptr && !bytes->empty()) {
      sodium_memzero(bytes->data(), bytes->size());
    }
  }

  void release() noexcept {
    active = false;
  }
};

constexpr std::size_t STREAM_CHUNK_SIZE = 1 * 1024 * 1024, STREAM_FRAME_LEN_BYTES = 4;

using StreamHeader = std::array<Byte, crypto_secretstream_xchacha20poly1305_HEADERBYTES>;

[[nodiscard]] std::size_t computeStreamEncryptedSize(std::size_t plaintext_size) {
  const std::size_t chunks = (plaintext_size == 0) ? 1 : ((plaintext_size - 1) / STREAM_CHUNK_SIZE) + 1;
  const std::size_t per_chunk_overhead = STREAM_FRAME_LEN_BYTES + crypto_secretstream_xchacha20poly1305_ABYTES;

  if (chunks > (std::numeric_limits<std::size_t>::max() - StreamHeader{}.size() - plaintext_size) / per_chunk_overhead) {
    throw std::runtime_error("Data File Error: Data file too large to encrypt.");
  }

  return StreamHeader{}.size() + plaintext_size + (chunks * per_chunk_overhead);
}

void writeFrameLen(vBytes& out, std::uint32_t frame_len) {
  out.push_back(static_cast<Byte>((frame_len >> 24) & 0xFF));
  out.push_back(static_cast<Byte>((frame_len >> 16) & 0xFF));
  out.push_back(static_cast<Byte>((frame_len >> 8) & 0xFF));
  out.push_back(static_cast<Byte>(frame_len & 0xFF));
}

[[nodiscard]] std::uint32_t readFrameLen(std::span<const Byte> data, std::size_t index) {
  return (static_cast<std::uint32_t>(data[index]) << 24) | (static_cast<std::uint32_t>(data[index + 1]) << 16) |
         (static_cast<std::uint32_t>(data[index + 2]) << 8) | static_cast<std::uint32_t>(data[index + 3]);
}
void encryptWithSecretStream(vBytes& plaintext, const Key& key, StreamHeader& header) {
  crypto_secretstream_xchacha20poly1305_state state{};
  if (crypto_secretstream_xchacha20poly1305_init_push(&state, header.data(), key.data()) != 0)
    throw std::runtime_error("crypto_secretstream init_push failed.");
  vBytes encrypted;
  encrypted.reserve(computeStreamEncryptedSize(plaintext.size()));
  encrypted.insert(encrypted.end(), header.begin(), header.end());
  vBytes cipher_chunk(STREAM_CHUNK_SIZE + crypto_secretstream_xchacha20poly1305_ABYTES);
  std::size_t offset = 0;
  bool emitted_final = false;

  // Store each ciphertext frame as [length][ciphertext] so recovery can
  // validate bounds before attempting to decrypt any chunk data.
  while (!emitted_final) {
    const std::size_t remaining = plaintext.size() - offset, chunk_len = std::min(remaining, STREAM_CHUNK_SIZE);
    const bool is_final = (offset + chunk_len == plaintext.size());
    const unsigned char tag = is_final ? crypto_secretstream_xchacha20poly1305_TAG_FINAL : 0;
    unsigned long long clen_ull = 0;
    if (crypto_secretstream_xchacha20poly1305_push(
            &state, cipher_chunk.data(), &clen_ull, (chunk_len == 0) ? nullptr : (plaintext.data() + offset), chunk_len, nullptr, 0, tag) !=
        0)
      throw std::runtime_error("crypto_secretstream push failed.");
    if (clen_ull > std::numeric_limits<std::uint32_t>::max())
      throw std::runtime_error("crypto_secretstream frame too large.");
    const auto clen = static_cast<std::uint32_t>(clen_ull);
    writeFrameLen(encrypted, clen);
    encrypted.insert(encrypted.end(), cipher_chunk.begin(), cipher_chunk.begin() + clen);
    offset += chunk_len;
    emitted_final = is_final;
  }
  if (!plaintext.empty())
    sodium_memzero(plaintext.data(), plaintext.size());
  plaintext = std::move(encrypted);
}
[[nodiscard]] std::optional<vBytes>
decryptWithSecretStream(std::span<const Byte> framed_ciphertext, const Key& key, const StreamHeader& header) {
  if (!spanHasRange(framed_ciphertext, 0, header.size()) || !std::ranges::equal(framed_ciphertext.first(header.size()), header))
    return std::nullopt;
  crypto_secretstream_xchacha20poly1305_state state{};
  if (crypto_secretstream_xchacha20poly1305_init_pull(&state, header.data(), key.data()) != 0)
    return std::nullopt;
  vBytes decrypted;
  decrypted.reserve(framed_ciphertext.size() - header.size());
  SensitiveBytesGuard decrypted_guard(decrypted);
  vBytes plain_chunk(STREAM_CHUNK_SIZE);
  SensitiveBytesGuard plain_chunk_guard(plain_chunk);
  std::size_t offset = header.size();
  bool has_final_tag = false;
  while (offset < framed_ciphertext.size()) {
    if (framed_ciphertext.size() - offset < STREAM_FRAME_LEN_BYTES)
      return std::nullopt;
    const std::uint32_t frame_len = readFrameLen(framed_ciphertext, offset);
    offset += STREAM_FRAME_LEN_BYTES;
    if (frame_len < crypto_secretstream_xchacha20poly1305_ABYTES || frame_len > framed_ciphertext.size() - offset)
      return std::nullopt;
    const std::size_t max_plain_chunk = static_cast<std::size_t>(frame_len) - crypto_secretstream_xchacha20poly1305_ABYTES;
    if (max_plain_chunk > plain_chunk.size())
      return std::nullopt;
    unsigned long long mlen = 0;
    unsigned char tag = 0;
    if (crypto_secretstream_xchacha20poly1305_pull(
            &state, plain_chunk.data(), &mlen, &tag, framed_ciphertext.data() + offset, frame_len, nullptr, 0) != 0 ||
        mlen > max_plain_chunk)
      return std::nullopt;
    decrypted.insert(decrypted.end(), plain_chunk.begin(), plain_chunk.begin() + mlen);
    offset += frame_len;
    if (tag == crypto_secretstream_xchacha20poly1305_TAG_FINAL) {
      has_final_tag = true;
      break;
    }
  }
  if (!has_final_tag || offset != framed_ciphertext.size())
    return std::nullopt;
  decrypted_guard.release();
  return decrypted;
}
void deriveKeyFromPin(Key& out_key, std::uint64_t pin, const Salt& salt) {
  std::array<char, 32> pin_buf{};
  auto [ptr, ec] = std::to_chars(pin_buf.data(), pin_buf.data() + pin_buf.size(), pin);
  if (ec != std::errc{}) {
    sodium_memzero(pin_buf.data(), pin_buf.size());
    throw std::runtime_error("KDF Error: Failed to encode recovery PIN.");
  }
  const auto pin_len = static_cast<unsigned long long>(ptr - pin_buf.data());
  const int rc = crypto_pwhash(out_key.data(),
                               out_key.size(),
                               pin_buf.data(),
                               pin_len,
                               salt.data(),
                               crypto_pwhash_OPSLIMIT_INTERACTIVE,
                               crypto_pwhash_MEMLIMIT_INTERACTIVE,
                               crypto_pwhash_ALG_ARGON2ID13);
  sodium_memzero(pin_buf.data(), pin_buf.size());
  if (rc != 0)
    throw std::runtime_error("KDF Error: Unable to derive encryption key.");
}

[[nodiscard]] KdfMetadataVersion getKdfMetadataVersion(std::span<const Byte> data, std::size_t base_index) {
  if (!spanHasRange(data, base_index, KDF_METADATA_REGION_BYTES) || data[base_index + KDF_ALG_OFFSET] != KDF_ALG_ARGON2ID13 ||
      data[base_index + KDF_SENTINEL_OFFSET] != KDF_SENTINEL) {
    return KdfMetadataVersion::none;
  }
  return std::ranges::equal(std::span(data.data() + base_index + KDF_MAGIC_OFFSET, KDF_METADATA_MAGIC_V2.size()), KDF_METADATA_MAGIC_V2)
             ? KdfMetadataVersion::v2_secretbox
             : KdfMetadataVersion::none;
}

[[nodiscard]] std::uint64_t generateRecoveryPin() {
  std::uint64_t pin = 0;
  while (pin == 0) {
    randombytes_buf(&pin, sizeof(pin));
  }
  return pin;
}

template <typename T> [[nodiscard]] T fromBigEndian(T value) {
  if constexpr (std::endian::native == std::endian::little) {
    return std::byteswap(value);
  } else {
    return value;
  }
}

[[nodiscard]] std::uint64_t getPinFromFile(vBytes& pin_vec) {
  SensitiveBytesGuard pin_guard(pin_vec);
  constexpr std::size_t PIN_INDEX = 0, PIN_BYTES = sizeof(std::uint64_t);
  requireSpanRange(pin_vec, PIN_INDEX, PIN_BYTES, "PIN File Error: Invalid file size.");

  std::uint64_t encoded = 0;
  std::memcpy(&encoded, pin_vec.data() + static_cast<std::ptrdiff_t>(PIN_INDEX), sizeof(encoded));
  return fromBigEndian(encoded);
}

[[nodiscard]] std::string extractFilenamePrefix(vBytes& payload) {
  constexpr const char* CORRUPT_FILE_ERROR = "File Recovery Error: Embedded profile is corrupt.";
  if (payload.empty() || payload[0] == 0)
    throw std::runtime_error(CORRUPT_FILE_ERROR);

  const std::size_t filename_len = payload[0];
  const std::size_t prefix_len = 1 + filename_len;
  requireSpanRange(payload, 0, prefix_len, CORRUPT_FILE_ERROR);

  std::string decrypted_filename(reinterpret_cast<const char*>(payload.data() + 1), filename_len);
  payload.erase(payload.begin(), payload.begin() + static_cast<std::ptrdiff_t>(prefix_len));
  return decrypted_filename;
}
} // namespace

std::uint64_t encryptDataFile(vBytes& profile_vec, vBytes& data_vec, const std::string& data_filename, const ProfileOffsets& offsets) {
  constexpr const char* CORRUPT_PROFILE_ERROR = "Internal Error: Corrupt profile template.";

  requireSpanRange(profile_vec, offsets.kdf_metadata, KDF_METADATA_REGION_BYTES, CORRUPT_PROFILE_ERROR);
  if (offsets.encrypted_file != profile_vec.size()) {
    throw std::runtime_error(CORRUPT_PROFILE_ERROR);
  }

  if (data_filename.empty() || data_filename.size() > static_cast<std::size_t>(std::numeric_limits<Byte>::max())) {
    throw std::runtime_error("Data File Error: Invalid data filename length.");
  }

  const std::size_t prefix_len = 1 + data_filename.size();
  if (data_vec.size() > std::numeric_limits<std::size_t>::max() - prefix_len) {
    throw std::runtime_error("Data File Error: Data file too large to encrypt.");
  }

  // Prefix plaintext with [filename_len][filename] in-place.
  const std::size_t payload_size = data_vec.size();
  data_vec.resize(payload_size + prefix_len);
  if (payload_size > 0) {
    std::memmove(data_vec.data() + static_cast<std::ptrdiff_t>(prefix_len), data_vec.data(), payload_size);
  }
  data_vec[0] = static_cast<Byte>(data_filename.size());
  std::memcpy(data_vec.data() + 1, data_filename.data(), data_filename.size());

  SensitiveKeyData key;
  Salt salt{};
  StreamHeader stream_header{};
  const std::uint64_t pin = generateRecoveryPin();

  randombytes_buf(salt.data(), salt.size());
  deriveKeyFromPin(key.key, pin, salt);
  encryptWithSecretStream(data_vec, key.key, stream_header);

  profile_vec.reserve(profile_vec.size() + data_vec.size());
  profile_vec.insert(profile_vec.end(), data_vec.begin(), data_vec.end());
  data_vec.clear();

  // Write KDF metadata into the fixed 56-byte region.
  randombytes_buf(profile_vec.data() + offsets.kdf_metadata, KDF_METADATA_REGION_BYTES);
  profile_vec[offsets.kdf_metadata + KDF_MAGIC_OFFSET + 0] = 'K';
  profile_vec[offsets.kdf_metadata + KDF_MAGIC_OFFSET + 1] = 'D';
  profile_vec[offsets.kdf_metadata + KDF_MAGIC_OFFSET + 2] = 'F';
  profile_vec[offsets.kdf_metadata + KDF_MAGIC_OFFSET + 3] = '2';
  profile_vec[offsets.kdf_metadata + KDF_ALG_OFFSET] = KDF_ALG_ARGON2ID13;
  profile_vec[offsets.kdf_metadata + KDF_SENTINEL_OFFSET] = KDF_SENTINEL;

  requireSpanRange(profile_vec, offsets.kdf_metadata + KDF_SALT_OFFSET, salt.size(), CORRUPT_PROFILE_ERROR);
  requireSpanRange(profile_vec, offsets.kdf_metadata + KDF_NONCE_OFFSET, stream_header.size(), CORRUPT_PROFILE_ERROR);
  std::ranges::copy(salt, profile_vec.begin() + static_cast<std::ptrdiff_t>(offsets.kdf_metadata + KDF_SALT_OFFSET));
  std::ranges::copy(stream_header, profile_vec.begin() + static_cast<std::ptrdiff_t>(offsets.kdf_metadata + KDF_NONCE_OFFSET));

  return pin;
}

std::optional<std::string> decryptDataFile(vBytes& profile_vec, vBytes& pin_vec, const ProfileOffsets& offsets) {
  constexpr const char* CORRUPT_FILE_ERROR = "File Recovery Error: Embedded profile is corrupt.";
  requireSpanRange(profile_vec, offsets.kdf_metadata, KDF_METADATA_REGION_BYTES, CORRUPT_FILE_ERROR);
  if (offsets.encrypted_file > profile_vec.size()) {
    throw std::runtime_error(CORRUPT_FILE_ERROR);
  }

  const KdfMetadataVersion metadata_version = getKdfMetadataVersion(profile_vec, offsets.kdf_metadata);
  if (metadata_version != KdfMetadataVersion::v2_secretbox) {
    throw std::runtime_error("File Decryption Error: Unsupported legacy encrypted file format. "
                             "Use an older wbpdv release to recover this file.");
  }

  const std::uint64_t recovery_pin = getPinFromFile(pin_vec);

  SensitiveKeyData key;
  Salt salt{};
  StreamHeader stream_header{};

  requireSpanRange(profile_vec, offsets.kdf_metadata + KDF_SALT_OFFSET, salt.size(), CORRUPT_FILE_ERROR);
  requireSpanRange(profile_vec, offsets.kdf_metadata + KDF_NONCE_OFFSET, stream_header.size(), CORRUPT_FILE_ERROR);

  std::ranges::copy_n(profile_vec.begin() + static_cast<std::ptrdiff_t>(offsets.kdf_metadata + KDF_SALT_OFFSET), salt.size(), salt.begin());
  std::ranges::copy_n(profile_vec.begin() + static_cast<std::ptrdiff_t>(offsets.kdf_metadata + KDF_NONCE_OFFSET),
                      stream_header.size(),
                      stream_header.begin());

  deriveKeyFromPin(key.key, recovery_pin, salt);

  const std::size_t ciphertext_length = profile_vec.size() - offsets.encrypted_file;
  const std::size_t min_stream_cipher_size = StreamHeader{}.size() + STREAM_FRAME_LEN_BYTES + crypto_secretstream_xchacha20poly1305_ABYTES;
  if (ciphertext_length < min_stream_cipher_size) {
    throw std::runtime_error(CORRUPT_FILE_ERROR);
  }

  const std::span<const Byte> framed_ciphertext(profile_vec.data() + static_cast<std::ptrdiff_t>(offsets.encrypted_file),
                                                ciphertext_length);
  auto decrypted = decryptWithSecretStream(framed_ciphertext, key.key, stream_header);
  if (!decrypted) {
    return std::nullopt;
  }
  profile_vec = std::move(*decrypted);

  return extractFilenamePrefix(profile_vec);
}
