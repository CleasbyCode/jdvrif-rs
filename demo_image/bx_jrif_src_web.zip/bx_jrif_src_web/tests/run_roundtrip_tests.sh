#!/bin/bash
# Fresh KDF3 conceal/recover tests for the split web binaries.
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
TESTS="$ROOT/tests"
FIXTURES="$TESTS/fixtures"
IN_BIN="${JDV_IN_BIN:-$ROOT/jdv_in}"
OUT_BIN="${JDV_OUT_BIN:-$ROOT/jdv_out}"
NO_BUILD=0

usage() {
    cat <<'EOF'
Usage: tests/run_roundtrip_tests.sh [options]

Options:
  --no-build        Reuse existing binaries.
  --in-bin <path>   Use an explicit jdv_in binary path.
  --out-bin <path>  Use an explicit jdv_out binary path.
  -h, --help        Show this help.

JDV_IN_BIN and JDV_OUT_BIN provide the same binary overrides.
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --no-build)
            NO_BUILD=1
            shift
            ;;
        --in-bin)
            [[ $# -ge 2 ]] || { echo "--in-bin requires a path" >&2; exit 2; }
            IN_BIN="$2"
            NO_BUILD=1
            shift 2
            ;;
        --out-bin)
            [[ $# -ge 2 ]] || { echo "--out-bin requires a path" >&2; exit 2; }
            OUT_BIN="$2"
            NO_BUILD=1
            shift 2
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            usage >&2
            exit 2
            ;;
    esac
done

if [[ "$IN_BIN" != /* ]]; then IN_BIN="$(pwd -P)/${IN_BIN#./}"; fi
if [[ "$OUT_BIN" != /* ]]; then OUT_BIN="$(pwd -P)/${OUT_BIN#./}"; fi

if [[ "$NO_BUILD" -eq 0 ]]; then
    (cd "$ROOT" && bash ./compile_jdv_in.sh && bash ./compile_jdv_out.sh)
fi
for binary in "$IN_BIN" "$OUT_BIN"; do
    if [[ ! -x "$binary" ]]; then
        echo "Binary not found or not executable: $binary" >&2
        exit 1
    fi
done
for command_name in cmp python3 sed; do
    command -v "$command_name" >/dev/null 2>&1 || {
        echo "Missing required command: $command_name" >&2
        exit 1
    }
done

extract_embedded_image() {
    sed -n 's/.*Saved "file-embedded" JPG image: \(.*\) ([0-9][0-9]* bytes)\..*/\1/p' "$1" | tail -n 1
}

extract_pin() {
    sed -n 's/.*Recovery PIN: \[\*\*\*\([0-9][0-9]*\)\*\*\*\].*/\1/p' "$1" | tail -n 1
}

extract_recovered_file() {
    sed -n 's/.*Extracted hidden file: \(.*\) ([0-9][0-9]* bytes)\..*/\1/p' "$1" | tail -n 1
}

assert_kdf3_and_layout() {
    python3 - "$1" "$2" "$3" "$4" "$5" <<'PY'
import sys
from pathlib import Path

data = Path(sys.argv[1]).read_bytes()
option = sys.argv[2]
minimum_icc_segments = int(sys.argv[3])
expect_photoshop = int(sys.argv[4])
expect_xmp = int(sys.argv[5])

if data.count(b"KDF3") != 1:
    raise SystemExit("fresh output does not contain exactly one KDF3 marker")
if option == "-b":
    if (b"Photoshop 3.0" in data) != bool(expect_photoshop):
        raise SystemExit("unexpected Photoshop-segment state")
    if (b"<rdf:li" in data) != bool(expect_xmp):
        raise SystemExit("unexpected XMP-segment state")
else:
    mntr = data.find(b"mntrRGB")
    if mntr < 8:
        raise SystemExit("ICC signature not found")
    base = mntr - 8
    count_at = base + 0x2C8
    if count_at + 2 > len(data):
        raise SystemExit("ICC segment count is out of bounds")
    count = int.from_bytes(data[count_at:count_at + 2], "big")
    if count < minimum_icc_segments:
        raise SystemExit(
            f"expected at least {minimum_icc_segments} ICC segments, got {count}"
        )
PY
}

PASS=0
FAIL=0
WORK="$(mktemp -d "${TMPDIR:-/tmp}/jdv-web-roundtrip.XXXXXX")"
trap 'rm -rf "$WORK"' EXIT

mkdir -p "$WORK/input_payloads"
cp "$FIXTURES/payloads/payload_text.txt" "$WORK/input_payloads/payload space.txt"

run_case() {
    local case_id="$1"
    local option="$2"
    local cover_name="$3"
    local payload_path="$4"
    local min_icc="$5"
    local expect_photoshop="$6"
    local expect_xmp="$7"
    local cover="$FIXTURES/covers/$cover_name"
    local case_dir="$WORK/$case_id"
    local embedded pin recovered

    [[ -f "$cover" && -f "$payload_path" ]] || {
        echo "missing input fixture for $case_id" >&2
        return 1
    }
    mkdir -p "$case_dir"
    if [[ -n "$option" ]]; then
        (cd "$case_dir" && "$IN_BIN" "$option" "$cover" "$payload_path" > conceal.log 2>&1) || {
            echo "jdv_in failed for $case_id" >&2
            cat "$case_dir/conceal.log" >&2
            return 1
        }
    else
        (cd "$case_dir" && "$IN_BIN" "$cover" "$payload_path" > conceal.log 2>&1) || {
            echo "jdv_in failed for $case_id" >&2
            cat "$case_dir/conceal.log" >&2
            return 1
        }
    fi

    embedded="$(extract_embedded_image "$case_dir/conceal.log")"
    pin="$(extract_pin "$case_dir/conceal.log")"
    if [[ -z "$embedded" || -z "$pin" || ! -f "$case_dir/$embedded" ]]; then
        echo "could not parse jdv_in output for $case_id" >&2
        cat "$case_dir/conceal.log" >&2
        return 1
    fi
    # `|| return 1` is required, not decorative: run_case is invoked from an
    # `if`, which disables errexit for its whole body, so a bare assertion here
    # would have its failure silently discarded.
    assert_kdf3_and_layout "$case_dir/$embedded" "$option" "$min_icc" \
        "$expect_photoshop" "$expect_xmp" || return 1

    printf '%s\n' "$pin" > "$case_dir/pin.txt"
    chmod 600 "$case_dir/pin.txt"
    if ! (cd "$case_dir" && "$OUT_BIN" "$embedded" pin.txt > recover.log 2>&1); then
        echo "jdv_out failed for $case_id" >&2
        cat "$case_dir/recover.log" >&2
        return 1
    fi
    recovered="$(extract_recovered_file "$case_dir/recover.log")"
    if [[ -z "$recovered" || ! -f "$case_dir/$recovered" ]]; then
        echo "could not identify recovered output for $case_id" >&2
        cat "$case_dir/recover.log" >&2
        return 1
    fi
    cmp -s "$case_dir/$recovered" "$payload_path" || {
        echo "recovered bytes differ for $case_id" >&2
        return 1
    }
}

CASES=(
    $'default\t.\tcover_default.jpg\tpayload_text.txt\t0\t0\t0'
    $'default_multiseg\t.\tcover_default.jpg\tpayload_multi.bin\t2\t0\t0'
    $'default_space_name\t.\tcover_default.jpg\t@space\t0\t0\t0'
    $'default_zip\t.\tcover_default.jpg\tpayload_archive.zip\t0\t0\t0'
    $'bluesky_single\t-b\tcover_bluesky.jpg\tbsingle.bin\t0\t0\t0'
    $'bluesky_split\t-b\tcover_bluesky.jpg\tbsplit.bin\t0\t1\t0'
    $'bluesky_xmp\t-b\tcover_bluesky.jpg\tbxmp.bin\t0\t1\t1'
)

for row in "${CASES[@]}"; do
    IFS=$'\t' read -r case_id option cover_name payload_name min_icc expect_photoshop expect_xmp <<< "$row"
    if [[ "$option" == "." ]]; then option=""; fi
    if [[ "$payload_name" == "@space" ]]; then
        payload_path="$WORK/input_payloads/payload space.txt"
    else
        payload_path="$FIXTURES/payloads/$payload_name"
    fi
    if run_case "$case_id" "$option" "$cover_name" "$payload_path" "$min_icc" \
        "$expect_photoshop" "$expect_xmp"; then
        echo "[PASS] $case_id"
        PASS=$((PASS + 1))
    else
        echo "[FAIL] $case_id" >&2
        FAIL=$((FAIL + 1))
    fi
done

echo
echo "KDF3 round-trip summary: PASS=$PASS FAIL=$FAIL"
echo "jdv_in:  $IN_BIN"
echo "jdv_out: $OUT_BIN"
[[ "$FAIL" -eq 0 ]]
