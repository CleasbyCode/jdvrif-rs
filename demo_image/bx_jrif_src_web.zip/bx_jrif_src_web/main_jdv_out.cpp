// JPG Data Vehicle (jdv_out) Created by Nicholas Cleasby (@CleasbyCode) 10/04/2023

#include "common.h"
#include "file_utils.h"
#include "key_file.h"
#include "program_args_out.h"
#include "recover.h"
#include "process_hardening.h"
#include "signal_utils.h"

#include <iostream>
#include <print>
#include <stdexcept>

namespace {
struct KeyFileGuard {
    vBytes& bytes;

    explicit KeyFileGuard(vBytes& value) noexcept : bytes(value) {}
    KeyFileGuard(const KeyFileGuard&) = delete;
    KeyFileGuard& operator=(const KeyFileGuard&) = delete;

    ~KeyFileGuard() {
        if (!bytes.empty()) {
            sodium_memzero(bytes.data(), bytes.size());
        }
        bytes.clear();
    }
};

[[nodiscard]] int run(int argc, char** argv) {
    throwIf(sodium_init() < 0, "Libsodium initialization failed!");
    auto args = ProgramArgs::parse(argc, argv);
    // Read up front, so a missing or oversized KEY file fails before the image
    // is touched; recovery parses it when it needs the KEY (getRecoveryKey).
    vBytes key_file = readFile(args.key_file_path, FileTypeCheck::key_file);
    KeyFileGuard key_file_guard(key_file);
    setKeyFile(key_file);
    recoverData(args.image_file_path);
    return 0;
}
} // namespace

int main(int argc, char** argv) {
    disableCoreDumps();
    try {
        installProcessSignalHandlers();
        return run(argc, argv);
    } catch (const SignalCancellation& interruption) {
        reraiseSignalAfterCleanup(interruption.signalNumber());
    } catch (const std::exception& e) {
        std::println(std::cerr, "\n{}\n", e.what());
        return 1;
    } catch (...) {
        std::println(std::cerr, "\nUnknown fatal error.\n");
        return 1;
    }
}
