# Web variant regression checks

Build both web programs with `bash compile_pdv_in.sh` and
`bash compile_pdv_out.sh`, then run from the web source directory:

```sh
python3 tests/run_web_regressions.py --cli-bin /path/to/current/pdvrdt
```

The suite uses the golden images and expected payloads in `../src/tests`.
Use `--fixtures /path/to/src/tests` if the source trees are elsewhere.
`--cli-bin` enables compatibility checks in both directions between the web
programs and the updated CLI. Without it, only the web checks run.

For ASan/UBSan, build both programs with `PDVRDT_BUILD_MODE=sanitize`, then run:

```sh
python3 tests/run_web_regressions.py \
  --in-bin ./pdv_in-san --out-bin ./pdv_out-san \
  --cli-bin /path/to/current/pdvrdt-san
```

Checks cover legacy and current carriers, all three concealment modes,
eight-byte big-endian PIN files, recovery filename collisions, malformed PNG
palettes, and PNG decompression limits. Test output files stay in temporary
directories; existing fixtures and PIN files are preserved.
