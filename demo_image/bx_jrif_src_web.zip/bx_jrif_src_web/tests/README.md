# Split-interface regression tests

The fixtures and tests in this directory are self-contained. They verify both
web-variant executables rather than relying on the combined main-project CLI:

- `run_golden_tests.sh` recovers all five legacy KDF2 fixtures with PIN files.
- `run_roundtrip_tests.sh` creates and recovers fresh KDF3 default and Bluesky
  images, including the ICC, Photoshop, and XMP multi-segment paths.
- `run_security_smoke.sh` covers authenticated compression semantics, wrong and
  oversized PIN files, truncated ciphertext, fixed ICC layout enforcement,
  transactional PIN delivery, the final Bluesky output limit, mode-specific
  JPEG quality and transformation limits, signal cleanup, dangling symlink
  collisions, and the default recovery-cap wiggle room. Optional fixture
  generators are skipped when Pillow, FFmpeg, or ImageMagick is unavailable.

Run the complete suite with:

```sh
bash tests/run_tests.sh
```

To test binaries built elsewhere:

```sh
bash tests/run_tests.sh --no-build \
  --in-bin /path/to/jdv_in \
  --out-bin /path/to/jdv_out
```

The same paths can be supplied through `JDV_IN_BIN` and `JDV_OUT_BIN`.
