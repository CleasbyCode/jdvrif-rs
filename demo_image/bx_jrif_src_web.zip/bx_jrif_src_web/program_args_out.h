#pragma once

#include "common.h"

#include <string>

struct ProgramArgs {
    fs::path image_file_path;
    fs::path pin_file_path;

    static ProgramArgs parse(int argc, char** argv);
};
