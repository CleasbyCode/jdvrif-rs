#!/usr/bin/env python3
"""Build the web variant and run its review-fix regressions in a temporary directory.

Usage: python3 tests/run_tests.py [--build-dir /tmp/pdvzip-web-tests]
Requires CMake, GCC 14+ (or compatible Clang), zlib, Python 3, Bash, and UnZip.
"""

import argparse
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import tempfile


def run(command, **kwargs):
    subprocess.run([str(value) for value in command], check=True, **kwargs)


def check(source, build):
    run(["cmake", "-S", source, "-B", build,
         "-DPDVZIP_OPT_LEVEL=-O2", "-DPDVZIP_ENABLE_LTO=OFF"])
    run(["cmake", "--build", build, "--parallel", "4"])
    cache = (build / "CMakeCache.txt").read_text()
    compiler = next(line.split("=", 1)[1] for line in cache.splitlines()
                    if line.startswith("CMAKE_CXX_COMPILER:FILEPATH="))
    objects = sorted(path for path in (build / "CMakeFiles/pdvzip.dir").rglob("*.o")
                     if path.name != "main.cpp.o")
    if not objects:
        raise RuntimeError("CMake produced no core objects for regression tests")
    suites = sorted((source / "tests").glob("*_tests.cpp"))
    output = build / "regressions"
    output.mkdir(exist_ok=True)

    def compile_suite(suite):
        executable = output / suite.stem
        command = [compiler, "-std=c++23", "-O1", "-I", source,
                   "-DLODEPNG_NO_COMPILE_DISK", "-DLODEPNG_NO_COMPILE_ANCILLARY_CHUNKS",
                   "-DLODEPNG_NO_COMPILE_CRC", suite, *objects, "-lz", "-o", executable]
        if suite.stem == "output_descriptor_tests":
            command.append("-Wl,--wrap=write,--wrap=fchmod,--wrap=fsync,--wrap=close")
        run(command)
        return executable

    with ThreadPoolExecutor(max_workers=2) as executor:
        executables = list(executor.map(compile_suite, suites))
    for executable in executables:
        print(f"Running {executable.name}", flush=True)
        run([executable], cwd=source)
    for script in ("linux_extraction_tests.py", "indexed_image_memory_test.py"):
        run(["python3", source / "tests" / script, build / "pdvzip"], cwd=source)
    print(f"All {len(suites)} C++ suites, Linux launcher tests, and indexed memory test passed.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-dir", type=lambda value: Path(value).resolve())
    args = parser.parse_args()
    source = Path(__file__).resolve().parents[1]
    if args.build_dir:
        check(source, args.build_dir)
    else:
        with tempfile.TemporaryDirectory(prefix="pdvzip-web-tests-") as temporary:
            check(source, Path(temporary))


if __name__ == "__main__":
    main()
