# Web variant regression checks

Build both web programs with `bash compile_pdv_in.sh` and
`bash compile_pdv_out.sh`, then run from the web source directory:

```sh
python3 tests/run_web_regressions.py --cli-bin /path/to/current/pdvrdt
```

The suite uses the golden images and expected payloads in `../src/tests`.
Use `--fixtures /path/to/src/tests` if the source trees are elsewhere.
`--cli-bin` enables compatibility checks in both directions between the web
programs and the updated CLI. Without it, only the web checks run.

For ASan/UBSan, build both programs with `PDVRDT_BUILD_MODE=sanitize`, then run:

```sh
python3 tests/run_web_regressions.py \
  --in-bin ./pdv_in-san --out-bin ./pdv_out-san \
  --cli-bin /path/to/current/pdvrdt-san
```

Checks cover the current carriers, all three concealment modes, KEY text
files and the raw 16-byte KEY form, typo and wrong-KEY errors, refusal of
images and numeric PINs (text or raw 8-byte) from before pdvrdt 6.0, recovery
filename collisions, malformed PNG palettes, PNG decompression limits, and
process hardening (core dumps off, memory unreadable to other processes,
escaped program name; via `../src/tests/run_process_hardening_tests.py`).
Test output files stay in temporary directories; existing fixtures and KEY
files are preserved.
