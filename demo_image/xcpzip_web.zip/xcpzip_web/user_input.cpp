#include "pdvzip.h"

#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <cerrno>
#include <format>
#include <limits>
#include <stdexcept>
#include <system_error>

namespace {

constexpr std::size_t MAX_ARG_LENGTH = 1024;

struct ScopedFd {
	int fd{-1};

	explicit ScopedFd(int file_descriptor) noexcept : fd(file_descriptor) {}
	~ScopedFd() {
		if (fd >= 0) {
			::close(fd);
		}
	}

	ScopedFd(const ScopedFd&) = delete;
	ScopedFd& operator=(const ScopedFd&) = delete;

	ScopedFd(ScopedFd&& other) noexcept : fd(other.fd) {
		other.fd = -1;
	}

	[[nodiscard]] int get() const noexcept { return fd; }
};

[[nodiscard]] bool fileTypeAcceptsArguments(FileType file_type) {
	return (file_type > FileType::PDF && file_type < FileType::UNKNOWN_FILE_TYPE)
		|| file_type == FileType::LINUX_EXECUTABLE
		|| file_type == FileType::JAR;
}

void validateArgsFilePath(const fs::path& filepath) {
	if (!hasValidFilename(filepath)) {
		throw std::runtime_error("Input Error: Arguments filename contains unsupported control characters.");
	}
}

[[nodiscard]] std::size_t argsFileSize(int fd, const fs::path& filepath) {
	struct stat st{};
	if (::fstat(fd, &st) != 0) {
		const std::error_code ec(errno, std::generic_category());
		throw std::runtime_error(std::format(
			"Input Error: Unable to stat arguments file \"{}\": {}.",
			filepath.string(), ec.message()));
	}
	if (!S_ISREG(st.st_mode)) {
		throw std::runtime_error(std::format(
			"Input Error: Arguments file \"{}\" is not a regular file.", filepath.string()));
	}
	if (st.st_size < 0) {
		throw std::runtime_error(std::format(
			"Input Error: Arguments file \"{}\" has an invalid size.", filepath.string()));
	}

	const auto file_size = static_cast<std::uintmax_t>(st.st_size);
	if (file_size > MAX_ARG_LENGTH) {
		throw std::runtime_error(std::format(
			"Input Error: Arguments file \"{}\" exceeds maximum length.", filepath.string()));
	}
	return static_cast<std::size_t>(file_size);
}

[[nodiscard]] std::string readArgsFileContents(int fd, const fs::path& filepath, std::size_t file_size) {
	std::string data(file_size, '\0');
	std::size_t total_read = 0;
	while (total_read < file_size) {
		const std::size_t remaining = file_size - total_read;
		const std::size_t chunk = std::min<std::size_t>(
			remaining,
			static_cast<std::size_t>(std::numeric_limits<ssize_t>::max()));
		const ssize_t rc = ::read(fd, data.data() + total_read, chunk);
		if (rc < 0) {
			if (errno == EINTR) {
				continue;
			}
			const std::error_code ec(errno, std::generic_category());
			throw std::runtime_error(std::format(
				"Input Error: Failed to read arguments file \"{}\": {}.",
				filepath.string(), ec.message()));
		}
		if (rc == 0) {
			throw std::runtime_error(std::format(
				"Input Error: Failed to read full arguments file \"{}\".", filepath.string()));
		}
		total_read += static_cast<std::size_t>(rc);
	}

	while (!data.empty() && (data.back() == '\n' || data.back() == '\r')) {
		data.pop_back();
	}

	return data;
}

std::string readArgsFile(const fs::path& filepath) {
	if (filepath.empty()) {
		return {};
	}

	validateArgsFilePath(filepath);

	int flags = O_RDONLY | O_CLOEXEC;
#ifdef O_NOFOLLOW
	flags |= O_NOFOLLOW;
#endif
	const int raw_fd = ::open(filepath.c_str(), flags);
	if (raw_fd < 0 && errno == ENOENT) {
		return {};
	}
	if (raw_fd < 0) {
		const std::error_code ec(errno, std::generic_category());
		throw std::runtime_error(std::format(
			"Input Error: Unable to open arguments file \"{}\": {}.",
			filepath.string(), ec.message()));
	}
	const ScopedFd handle(raw_fd);

	const std::size_t file_size = argsFileSize(handle.get(), filepath);
	if (file_size == 0) {
		return {};
	}

	return readArgsFileContents(handle.get(), filepath, file_size);
}

} // anonymous namespace

UserArguments loadArguments(
	FileType file_type,
	const fs::path& linux_args_file,
	const fs::path& windows_args_file) {

	UserArguments args;

	if (!fileTypeAcceptsArguments(file_type)) {
		return args;
	}

	if (file_type != FileType::WINDOWS_EXECUTABLE) {
		args.linux_args = readArgsFile(linux_args_file);
	}

	if (file_type != FileType::LINUX_EXECUTABLE) {
		args.windows_args = readArgsFile(windows_args_file);
	}

	return args;
}
