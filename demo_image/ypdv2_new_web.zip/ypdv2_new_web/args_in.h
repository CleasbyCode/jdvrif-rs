#pragma once

#include "common.h"

struct ProgramArgs {
	Mode mode{Mode::conceal};
	Option option{Option::None};
	fs::path image_file_path{};
	fs::path data_file_path{};

	static ProgramArgs parse(int argc, char** argv);
};
