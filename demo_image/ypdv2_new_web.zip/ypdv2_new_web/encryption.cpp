#include "encryption.h"
#include "compression.h"
#include "io_utils.h"
#include "png_utils.h"

#include <algorithm>
#include <charconv>
#include <cstring>
#include <limits>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string_view>

namespace {
constexpr std::size_t STREAM_CHUNK_SIZE = 1 * 1024 * 1024;

using StreamHeader = std::array<Byte, crypto_secretstream_xchacha20poly1305_HEADERBYTES>;

struct KdfSecrets {
	Salt salt{};
	StreamHeader stream_header{};
};

static_assert(STREAM_FRAME_LEN_BYTES == sizeof(std::uint32_t),
	"The frame length is written by updateValue(), which encodes exactly 32 bits.");

[[nodiscard]] std::array<Byte, STREAM_FRAME_LEN_BYTES> encodeFrameLen(std::uint32_t frame_len) {
	std::array<Byte, STREAM_FRAME_LEN_BYTES> bytes{};
	updateValue(bytes, 0, frame_len);
	return bytes;
}

void appendEncryptedFrame(
	vBytes& encrypted,
	std::span<const Byte> cipher_frame,
	std::size_t max_encrypted_size) {
	if (cipher_frame.size() > static_cast<std::size_t>(std::numeric_limits<std::uint32_t>::max())) {
		throw std::runtime_error("crypto_secretstream frame too large.");
	}

	const auto frame_len = encodeFrameLen(static_cast<std::uint32_t>(cipher_frame.size()));
	const std::size_t base = encrypted.size();
	const std::size_t final_size = checkedAddSize(
		checkedAddSize(base, frame_len.size(), "File Size Error: Encrypted output overflow."),
		cipher_frame.size(),
		"File Size Error: Encrypted output overflow."
	);
	if (final_size > max_encrypted_size) {
		throw std::runtime_error(
			"File Size Error: Compressed and encrypted payload exceeds the selected output size limit.");
	}

	encrypted.resize(final_size);
	Byte* out = encrypted.data() + static_cast<std::ptrdiff_t>(base);
	std::memcpy(out, frame_len.data(), frame_len.size());
	std::memcpy(out + frame_len.size(), cipher_frame.data(), cipher_frame.size());
}

void initializeSecretStreamPush(
	crypto_secretstream_xchacha20poly1305_state& state,
	StreamHeader& stream_header,
	const Key& key) {

	if (crypto_secretstream_xchacha20poly1305_init_push(&state, stream_header.data(), key.data()) != 0) {
		throw std::runtime_error("crypto_secretstream init_push failed.");
	}
}

void appendEncryptedFrames(
	vBytes& encrypted,
	std::span<const Byte> plaintext,
	crypto_secretstream_xchacha20poly1305_state& state,
	vBytes& cipher_chunk,
	std::size_t max_encrypted_size,
	unsigned char final_tag = 0) {

	if (plaintext.empty() && final_tag == 0) {
		return;
	}

	std::size_t offset = 0;
	bool emit_empty_final = plaintext.empty() && final_tag != 0;

	while (emit_empty_final || offset < plaintext.size()) {
		const std::size_t remaining = plaintext.size() - offset;
		const std::size_t chunk_len = std::min(remaining, STREAM_CHUNK_SIZE);
		const bool is_final = emit_empty_final || (offset + chunk_len == plaintext.size());
		const unsigned char tag = is_final ? final_tag : 0;

		unsigned long long clen_ull = 0;
		if (crypto_secretstream_xchacha20poly1305_push(
				&state,
				cipher_chunk.data(),
				&clen_ull,
				(chunk_len == 0) ? nullptr : (plaintext.data() + static_cast<std::ptrdiff_t>(offset)),
				chunk_len,
				nullptr,
				0,
				tag) != 0) {
			throw std::runtime_error("crypto_secretstream push failed.");
		}

		if (clen_ull > static_cast<unsigned long long>(std::numeric_limits<std::uint32_t>::max())) {
			throw std::runtime_error("crypto_secretstream frame too large.");
		}
		appendEncryptedFrame(
			encrypted,
			std::span<const Byte>(cipher_chunk.data(), static_cast<std::size_t>(clen_ull)),
			max_encrypted_size
		);

		offset += chunk_len;
		emit_empty_final = false;
	}
}

[[nodiscard]] std::uint32_t readFrameLen(std::span<const Byte> data, std::size_t index) {
	return getValue(data, index);
}

// Decrypt in place: cipher at storage[cipher_start..cipher_start+cipher_len),
// plaintext written to storage[0..]. Plaintext write trails unread cipher by at least
// (cipher_start + header.size() + 21*N) bytes after frame N — always safe.
// On success, storage is resized to plaintext size. On failure, any partial plaintext is wiped.
[[nodiscard]] bool decryptWithSecretStreamInPlace(
	vBytes& storage,
	std::size_t cipher_start,
	std::size_t cipher_len,
	const Key& key,
	const StreamHeader& header) {

	if (cipher_len < header.size()) {
		return false;
	}
	if (!spanHasRange(storage, cipher_start, cipher_len)) {
		return false;
	}
	if (!std::ranges::equal(
			std::span<const Byte>(storage.data() + cipher_start, header.size()),
			header)) {
		return false;
	}

	crypto_secretstream_xchacha20poly1305_state stream_state{};
	ScopedWipe stream_state_wipe{stream_state};
	if (crypto_secretstream_xchacha20poly1305_init_pull(&stream_state, header.data(), key.data()) != 0) {
		return false;
	}

	vBytes plain_chunk(STREAM_CHUNK_SIZE);
	ScopedWipe plain_chunk_wipe{plain_chunk};

	std::size_t cipher_pos = cipher_start + header.size();
	const std::size_t cipher_end = cipher_start + cipher_len;
	std::size_t plain_pos = 0;
	bool has_final_tag = false;

	auto fail = [&]() -> bool {
		sodium_memzero(storage.data(), plain_pos);
		return false;
	};

	while (cipher_pos < cipher_end) {
		if (cipher_end - cipher_pos < STREAM_FRAME_LEN_BYTES) {
			return fail();
		}

		const std::uint32_t frame_len = readFrameLen(storage, cipher_pos);
		cipher_pos += STREAM_FRAME_LEN_BYTES;

		if (frame_len < crypto_secretstream_xchacha20poly1305_ABYTES ||
			frame_len > cipher_end - cipher_pos) {
			return fail();
		}

		const std::size_t max_plain_chunk = static_cast<std::size_t>(frame_len) - crypto_secretstream_xchacha20poly1305_ABYTES;
		if (max_plain_chunk > plain_chunk.size()) {
			return fail();
		}

		unsigned long long mlen = 0;
		unsigned char tag = 0;
		if (crypto_secretstream_xchacha20poly1305_pull(
				&stream_state,
				plain_chunk.data(),
				&mlen,
				&tag,
				storage.data() + cipher_pos,
				frame_len,
				nullptr,
				0) != 0) {
			return fail();
		}
		if (mlen > max_plain_chunk) {
			return fail();
		}
		if (mlen > 0) {
			std::memcpy(storage.data() + plain_pos, plain_chunk.data(), mlen);
			plain_pos += mlen;
		}

		cipher_pos += frame_len;
		if (tag == crypto_secretstream_xchacha20poly1305_TAG_FINAL) {
			has_final_tag = true;
			break;
		}
	}

	if (!has_final_tag || cipher_pos != cipher_end) {
		return fail();
	}

	// Wipe trailing ciphertext bytes before truncating.
	if (plain_pos < storage.size()) {
		sodium_memzero(storage.data() + plain_pos, storage.size() - plain_pos);
	}
	storage.resize(plain_pos);
	return true;
}

// Takes the caller's SensitiveU64 by reference rather than the integer by
// value. A by-value parameter made a second copy of the secret that this
// function then had to scrub -- and scrubbing a parameter only reaches its stack
// slot, never a register the compiler chose to keep it in. Borrowing means there
// is no second copy to begin with, and the one home the secret does have is
// wiped by its owner on scope exit. Only the decimal rendering below is
// transient here, and that is scrubbed on every path out.
void deriveKeyFromPin(Key& out_key, const SensitiveU64& pin, const Salt& salt) {
	std::array<char, 32> pin_buf{};
	ScopedWipe pin_buf_wipe{pin_buf};

	auto [ptr, ec] = std::to_chars(pin_buf.data(), pin_buf.data() + pin_buf.size(), pin.value);
	if (ec != std::errc{}) {
		throw std::runtime_error("KDF Error: Failed to encode recovery PIN.");
	}

	const auto pin_len = static_cast<unsigned long long>(ptr - pin_buf.data());
	const int rc = crypto_pwhash(
		out_key.data(),
		out_key.size(),
		pin_buf.data(),
		pin_len,
		salt.data(),
		crypto_pwhash_OPSLIMIT_INTERACTIVE,
		crypto_pwhash_MEMLIMIT_INTERACTIVE,
		crypto_pwhash_ALG_ARGON2ID13
	);

	if (rc != 0) {
		throw std::runtime_error("KDF Error: Unable to derive encryption key.");
	}
}

// Fills `out_pin` in place; see SensitiveU64 for why no secret is returned by
// value anywhere in this file.
void generateRecoveryPin(SensitiveU64& out_pin) {
	out_pin.value = 0;
	while (out_pin.value == 0) {
		randombytes_buf(&out_pin.value, sizeof(out_pin.value));
	}
}

inline constexpr std::size_t MAX_FILENAME_PREFIX_BYTES =
	static_cast<std::size_t>(std::numeric_limits<Byte>::max()) + 1;

struct FilenamePrefix {
	std::array<Byte, MAX_FILENAME_PREFIX_BYTES> bytes{};
	std::size_t size{};

	[[nodiscard]] std::span<const Byte> view() const noexcept {
		return std::span<const Byte>(bytes.data(), size);
	}
};

[[nodiscard]] FilenamePrefix makeFilenamePrefix(const std::string& data_filename) {
	if (data_filename.empty() || data_filename.size() > static_cast<std::size_t>(std::numeric_limits<Byte>::max())) {
		throw std::runtime_error("Data File Error: Invalid data filename length.");
	}

	FilenamePrefix filename_prefix;
	filename_prefix.size = 1 + data_filename.size();
	filename_prefix.bytes[0] = static_cast<Byte>(data_filename.size());
	std::memcpy(
		filename_prefix.bytes.data() + 1,
		data_filename.data(),
		data_filename.size()
	);
	return filename_prefix;
}

void writeKdfMetadata(
	vBytes& profile_vec,
	const ProfileOffsets& offsets,
	const Salt& salt,
	const StreamHeader& stream_header,
	std::string_view corrupt_profile_error) {

	// The whole region is randomised first, so the bytes around the fields below
	// stay indistinguishable padding.
	Byte* const region = profile_vec.data() + offsets.kdf_metadata;
	randombytes_buf(region, KDF_METADATA_REGION_BYTES);
	std::memcpy(region + KDF_MAGIC_OFFSET, KDF_METADATA_MAGIC_V2.data(), KDF_METADATA_MAGIC_V2.size());
	region[KDF_ALG_OFFSET] = KDF_ALG_ARGON2ID13;
	region[KDF_SENTINEL_OFFSET] = KDF_SENTINEL;

	requireSpanRange(profile_vec, offsets.kdf_metadata + KDF_SALT_OFFSET, salt.size(), corrupt_profile_error);
	requireSpanRange(profile_vec, offsets.kdf_metadata + KDF_NONCE_OFFSET, stream_header.size(), corrupt_profile_error);
	std::memcpy(region + KDF_SALT_OFFSET, salt.data(), salt.size());
	std::memcpy(region + KDF_NONCE_OFFSET, stream_header.data(), stream_header.size());
}

[[nodiscard]] KdfSecrets readKdfSecrets(
	std::span<const Byte> data,
	const ProfileOffsets& offsets,
	std::string_view corrupt_file_error) {

	KdfSecrets secrets;
	requireSpanRange(data, offsets.kdf_metadata + KDF_SALT_OFFSET, secrets.salt.size(), corrupt_file_error);
	requireSpanRange(data, offsets.kdf_metadata + KDF_NONCE_OFFSET, secrets.stream_header.size(), corrupt_file_error);

	const Byte* const region = data.data() + offsets.kdf_metadata;
	std::memcpy(secrets.salt.data(), region + KDF_SALT_OFFSET, secrets.salt.size());
	std::memcpy(secrets.stream_header.data(), region + KDF_NONCE_OFFSET, secrets.stream_header.size());
	return secrets;
}

// Web variant: the recovery PIN is supplied as a file of exactly 8 big-endian
// bytes, so there is no interactive entry path (and none of the terminal/signal
// handling the main source needs for it). The size is already enforced by
// FileTypeCheck::pin_file; re-check here so this stays correct on its own.
//
// Written through `out_pin` rather than returned: see SensitiveU64 in common.h.
void readPinValue(SensitiveU64& out_pin, std::span<const Byte> pin_data) {
	constexpr std::size_t PIN_BYTE_LENGTH = 8;
	if (pin_data.size() != PIN_BYTE_LENGTH) {
		throw std::runtime_error("PIN File Error: Invalid file size.");
	}
	// getValue() reads the 32-bit fields both file formats are built from, so the
	// 64-bit PIN is assembled from its two halves rather than widening it there.
	out_pin.value =
		(static_cast<std::uint64_t>(getValue(pin_data, 0)) << 32) |
		 static_cast<std::uint64_t>(getValue(pin_data, 4));
}

[[nodiscard]] std::string extractFilenamePrefix(vBytes& payload) {
	constexpr const char* CORRUPT_FILE_ERROR = "File Recovery Error: Embedded profile is corrupt.";
	if (payload.empty()) {
		throw std::runtime_error(CORRUPT_FILE_ERROR);
	}

	const std::size_t filename_len = payload[0];
	if (filename_len == 0) {
		throw std::runtime_error(CORRUPT_FILE_ERROR);
	}
	const std::size_t prefix_len = 1 + filename_len;
	requireSpanRange(payload, 0, prefix_len, CORRUPT_FILE_ERROR);

	std::string decrypted_filename(
		reinterpret_cast<const char*>(payload.data() + 1),
		filename_len
	);

	const std::size_t old_payload_size = payload.size();
	const std::size_t compressed_payload_size = old_payload_size - prefix_len;
	if (compressed_payload_size > 0) {
		std::memmove(
			payload.data(),
			payload.data() + static_cast<std::ptrdiff_t>(prefix_len),
			compressed_payload_size
		);
		sodium_memzero(
			payload.data() + static_cast<std::ptrdiff_t>(compressed_payload_size),
			prefix_len
		);
	} else {
		sodium_memzero(payload.data(), old_payload_size);
	}
	payload.resize(compressed_payload_size);
	return decrypted_filename;
}

} // namespace

namespace {

template <typename PayloadProducer>
void encryptPayloadToProfile(
	SensitiveU64& out_pin,
	vBytes& profile_vec,
	const std::string& data_filename,
	bool has_mastodon_option,
	std::size_t max_profile_size,
	PayloadProducer produce_payload) {

	const auto& offsets = has_mastodon_option ? MASTODON_OFFSETS : DEFAULT_OFFSETS;
	constexpr const char* CORRUPT_PROFILE_ERROR = "Internal Error: Corrupt profile template.";

	requireSpanRange(profile_vec, offsets.kdf_metadata, KDF_METADATA_REGION_BYTES, CORRUPT_PROFILE_ERROR);
	if (offsets.encrypted_file != profile_vec.size()) {
		throw std::runtime_error(CORRUPT_PROFILE_ERROR);
	}
	if (profile_vec.size() > max_profile_size) {
		throw std::runtime_error(
			"File Size Error: Cover image leaves no room for an embedded payload.");
	}

	const FilenamePrefix filename_prefix = makeFilenamePrefix(data_filename);

	Key key{};
	ScopedWipe key_wipe{key};
	Salt salt{};
	StreamHeader stream_header{};
	// Generated straight into the caller's storage: there is never a second copy
	// to scrub, and the caller's SensitiveU64 wipes it on every path out of here,
	// exception or not.
	generateRecoveryPin(out_pin);

	randombytes_buf(salt.data(), salt.size());
	deriveKeyFromPin(key, out_pin, salt);

	crypto_secretstream_xchacha20poly1305_state stream_state{};
	ScopedWipe stream_state_wipe{stream_state};
	initializeSecretStreamPush(stream_state, stream_header, key);

	if (stream_header.size() > max_profile_size - profile_vec.size()) {
		throw std::runtime_error(
			"File Size Error: Compressed and encrypted payload exceeds the selected output size limit.");
	}
	appendBytes(profile_vec, std::span<const Byte>(stream_header), "File Size Error: Encrypted output overflow.");

	vBytes cipher_chunk(STREAM_CHUNK_SIZE + crypto_secretstream_xchacha20poly1305_ABYTES);

	appendEncryptedFrames(
		profile_vec, filename_prefix.view(), stream_state, cipher_chunk, max_profile_size);

	bool saw_compressed_output = false;
	const auto consume_payload = [&](std::span<const Byte> chunk) {
		if (chunk.empty()) {
			return;
		}
		saw_compressed_output = true;
		appendEncryptedFrames(
			profile_vec, chunk, stream_state, cipher_chunk, max_profile_size);
	};
	produce_payload(consume_payload);

	if (!saw_compressed_output) {
		throw std::runtime_error("File Size Error: File is zero bytes. Probable compression failure.");
	}

	// Close the secretstream with an empty TAG_FINAL frame (~21 bytes overhead).
	appendEncryptedFrames(
		profile_vec,
		std::span<const Byte>{},
		stream_state,
		cipher_chunk,
		max_profile_size,
		crypto_secretstream_xchacha20poly1305_TAG_FINAL
	);

	writeKdfMetadata(profile_vec, offsets, salt, stream_header, CORRUPT_PROFILE_ERROR);
}

} // namespace

void encryptCompressedFileToProfile(
	SensitiveU64& out_pin,
	vBytes& profile_vec,
	int data_fd,
	std::size_t data_file_size,
	const std::string& data_filename,
	bool is_compressed_file,
	bool has_mastodon_option,
	std::size_t max_profile_size) {

	encryptPayloadToProfile(
		out_pin,
		profile_vec,
		data_filename,
		has_mastodon_option,
		max_profile_size,
		[&](const auto& consume_payload) {
			zlibDeflateFd(
				data_fd,
				data_file_size,
				is_compressed_file,
				consume_payload);
		});
}

void encryptPreparedDataToProfile(
	SensitiveU64& out_pin,
	vBytes& profile_vec,
	std::span<const Byte> prepared_data,
	const std::string& data_filename,
	bool has_mastodon_option,
	std::size_t max_profile_size) {

	encryptPayloadToProfile(
		out_pin,
		profile_vec,
		data_filename,
		has_mastodon_option,
		max_profile_size,
		[prepared_data](const auto& consume_payload) {
			consume_payload(prepared_data);
		});
}

std::optional<std::span<const Byte>> findPdvrdtIccpPayload(std::span<const Byte> iccp_data) {
	constexpr std::size_t PROFILE_PREFIX_SIZE = MASTODON_OFFSETS.pdv_signature + PDVRDT_SIG.size();

	if (!bytesEqualAt(iccp_data, 0, PDVRDT_ICCP_PREFIX)) {
		return std::nullopt;
	}
	const std::span<const Byte> compressed = iccp_data.subspan(PDVRDT_ICCP_PREFIX.size());
	if (compressed.empty()) {
		return std::nullopt;
	}

	vBytes profile_prefix;
	try {
		profile_prefix = zlibInflatePrefix(compressed, PROFILE_PREFIX_SIZE);
	} catch (const std::runtime_error&) {
		return std::nullopt;
	}
	if (profile_prefix.size() != PROFILE_PREFIX_SIZE ||
		!hasPdvrdtProfileMarkers(profile_prefix, MASTODON_OFFSETS)) {
		return std::nullopt;
	}
	return compressed;
}

std::optional<std::string> decryptDataFile(vBytes& png_vec, vBytes& pin_vec, bool is_mastodon_file) {
	const auto& offsets = is_mastodon_file ? MASTODON_OFFSETS : DEFAULT_OFFSETS;

	constexpr const char* CORRUPT_FILE_ERROR = "File Recovery Error: Embedded profile is corrupt.";
	requireSpanRange(png_vec, offsets.kdf_metadata, KDF_METADATA_REGION_BYTES, CORRUPT_FILE_ERROR);
	if (offsets.encrypted_file > png_vec.size()) {
		throw std::runtime_error(CORRUPT_FILE_ERROR);
	}

	if (!hasSupportedKdfMetadataAt(png_vec, offsets.kdf_metadata)) {
		throw std::runtime_error(
			"File Decryption Error: Unsupported legacy encrypted file format. "
			"Use an older pdvrdt release to recover this file.");
	}

	// Take the PIN out of the caller's buffer and scrub the buffer immediately:
	// from here on the secret lives only in recovery_pin, which wipes on scope
	// exit. The guard covers the window in which both copies exist.
	ScopedWipe pin_guard{pin_vec};
	SensitiveU64 recovery_pin;
	readPinValue(recovery_pin, pin_vec);
	if (!pin_vec.empty()) {
		sodium_memzero(pin_vec.data(), pin_vec.size());
		pin_vec.clear();
	}
	pin_guard.release();

	Key key{};
	ScopedWipe key_wipe{key};
	const KdfSecrets secrets = readKdfSecrets(png_vec, offsets, CORRUPT_FILE_ERROR);
	deriveKeyFromPin(key, recovery_pin, secrets.salt);

	const std::size_t ciphertext_length = png_vec.size() - offsets.encrypted_file;
	if (ciphertext_length < minimumStreamCipherSize()) {
		throw std::runtime_error(CORRUPT_FILE_ERROR);
	}

	if (!decryptWithSecretStreamInPlace(png_vec, offsets.encrypted_file, ciphertext_length, key, secrets.stream_header)) {
		return std::nullopt;
	}

	return extractFilenamePrefix(png_vec);
}
