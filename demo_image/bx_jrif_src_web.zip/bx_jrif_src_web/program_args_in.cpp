#include "program_args_in.h"

#include <format>
#include <stdexcept>
#include <string>
#include <string_view>

namespace {
[[nodiscard]] std::string_view argAt(int argc, char** argv, int index) {
    if (index < 0 || index >= argc || argv[index] == nullptr) {
        return {};
    }
    return argv[index];
}

[[nodiscard]] std::string programName(int argc, char** argv) {
    if (argc <= 0 || argv[0] == nullptr) return "jdv_in";
    return fs::path(argv[0]).filename().string();
}

[[nodiscard]] std::string usageText(int argc, char** argv) {
    return std::format("Usage: {} [-b|-r] <cover_image> <secret_file>", programName(argc, argv));
}

[[nodiscard]] bool parseConcealOption(std::string_view arg, Option& option) {
    if (arg == "-b") {
        option = Option::Bluesky;
        return true;
    }
    if (arg == "-r") {
        option = Option::Reddit;
        return true;
    }
    return false;
}
} // namespace

ProgramArgs ProgramArgs::parse(int argc, char** argv) {
    const std::string usage = usageText(argc, argv);

    ProgramArgs out;
    int image_index = 1;

    if (parseConcealOption(argAt(argc, argv, image_index), out.option)) {
        ++image_index;
    }

    if (argc != image_index + 2) {
        die(usage);
    }

    out.image_file_path = argAt(argc, argv, image_index);
    out.data_file_path = argAt(argc, argv, image_index + 1);
    return out;
}

[[noreturn]] void ProgramArgs::die(const std::string& message) {
    throw std::runtime_error(message);
}
