// PNG Data Vehicle (pdv_in) Created by Nicholas Cleasby (@CleasbyCode) 24/01/2023

#include "args_in.h"
#include "conceal.h"
#include "io_utils.h"
#include "process_hardening.h"

#include <iostream>
#include <print>
#include <stdexcept>

int main(int argc, char** argv) {
	disableCoreDumps();
	try {
		if (sodium_init() < 0) {
			throw std::runtime_error("Libsodium initialization failed!");
		}

		auto args = ProgramArgs::parse(argc, argv);

		const FileTypeCheck image_check =
			args.mode == Mode::capsize || args.option == Option::Reddit
				? FileTypeCheck::reddit_cover_image
				: FileTypeCheck::cover_image;
		vBytes png_vec = readFile(args.image_file_path, image_check);
		if (args.mode == Mode::capsize) {
			displayRedditCapacity(png_vec, args.image_file_path);
		} else {
			concealData(png_vec, args.option, args.image_file_path, args.data_file_path);
		}
	}
	catch (const std::exception& e) {
		std::println(std::cerr, "\n{}\n", e.what());
		return 1;
	}
	return 0;
}
