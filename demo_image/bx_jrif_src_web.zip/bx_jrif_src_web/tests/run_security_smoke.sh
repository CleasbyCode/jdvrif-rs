#!/bin/bash
# Focused regressions for security/correctness fixes shared with the main CLI.
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
TESTS="$ROOT/tests"
FIXTURES="$TESTS/fixtures"
IN_BIN="${JDV_IN_BIN:-$ROOT/jdv_in}"
OUT_BIN="${JDV_OUT_BIN:-$ROOT/jdv_out}"
NO_BUILD=0

usage() {
    cat <<'EOF'
Usage: tests/run_security_smoke.sh [options]

Options:
  --no-build        Reuse existing binaries.
  --in-bin <path>   Use an explicit jdv_in binary path.
  --out-bin <path>  Use an explicit jdv_out binary path.
  -h, --help        Show this help.

JDV_IN_BIN and JDV_OUT_BIN provide the same binary overrides.
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --no-build)
            NO_BUILD=1
            shift
            ;;
        --in-bin)
            [[ $# -ge 2 ]] || { echo "--in-bin requires a path" >&2; exit 2; }
            IN_BIN="$2"
            NO_BUILD=1
            shift 2
            ;;
        --out-bin)
            [[ $# -ge 2 ]] || { echo "--out-bin requires a path" >&2; exit 2; }
            OUT_BIN="$2"
            NO_BUILD=1
            shift 2
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            usage >&2
            exit 2
            ;;
    esac
done

if [[ "$IN_BIN" != /* ]]; then IN_BIN="$(pwd -P)/${IN_BIN#./}"; fi
if [[ "$OUT_BIN" != /* ]]; then OUT_BIN="$(pwd -P)/${OUT_BIN#./}"; fi
if [[ "$NO_BUILD" -eq 0 ]]; then
    (cd "$ROOT" && bash ./compile_jdv_in.sh && bash ./compile_jdv_out.sh)
fi
for binary in "$IN_BIN" "$OUT_BIN"; do
    [[ -x "$binary" ]] || { echo "Binary not found or not executable: $binary" >&2; exit 1; }
done
for command_name in cmp find grep python3 sed stat; do
    command -v "$command_name" >/dev/null 2>&1 || {
        echo "Missing required command: $command_name" >&2
        exit 1
    }
done

COVER="$FIXTURES/covers/cover_default.jpg"
PAYLOAD="$FIXTURES/payloads/payload_text.txt"
WORK="$(mktemp -d "${TMPDIR:-/tmp}/jdv-web-security.XXXXXX")"
trap 'rm -rf "$WORK"' EXIT

extract_embedded_image() {
    sed -n 's/.*Saved "file-embedded" JPG image: \(.*\) ([0-9][0-9]* bytes)\..*/\1/p' "$1" | tail -n 1
}

extract_pin() {
    sed -nE 's/.*Recovery KEY: \[\*\*\*([1-9A-HJ-NP-Za-km-z-]+)\*\*\*\].*/\1/p' "$1" | tail -n 1
}

# Well-formed 128-bit PINs (design test vectors) that conceal never mints in
# practice: wrong-PIN cases use these so they reach key derivation.
WRONG_PIN="1111-1111-1111-1111-1111-126X"
WRONG_PIN_ALT="112d-rXXU-ifSr-RnXL-GbXg-8Egs"
PIN128_RE='^[1-9A-HJ-NP-Za-km-z]{4}(-[1-9A-HJ-NP-Za-km-z]{4}){5}$'
# The messages a v10 image gives ($DEFAULT_IMAGE); test_pinfile_word_matches_image
# covers the PIN and KEY/PIN wording of older and carrier images.
PIN_FILE_ERROR='KEY File Error: Invalid file contents.'
PIN_CHECK_ERROR='KEY Entry Error: That KEY has a typo: its last two characters do not match the rest. Check each character, including upper and lower case.'
MISMATCH_NEEDS_PIN128='File Extraction Error: This image was made by jdvrif v10 or later and needs its 24-character recovery KEY.'
MISMATCH_NEEDS_LEGACY='File Extraction Error: This image was made before jdvrif v10 and needs the numeric recovery PIN it was created with.'

extract_recovered_file() {
    sed -n 's/.*Extracted hidden file: \(.*\) ([0-9][0-9]* bytes)\..*/\1/p' "$1" | tail -n 1
}

# AddressSanitizer reserves a multi-terabyte shadow mapping at startup, so an
# instrumented binary aborts under `ulimit -v` before reaching any jdv_in code.
# Tests that use an address-space cap must drop it for such a build. Detect this
# from the binary itself: ASAN_OPTIONS is only set if the caller exported it,
# which makes it an unreliable signal when running the suite directly.
binary_is_sanitized() {
    [[ -n "${ASAN_OPTIONS:-}" ]] && return 0
    ldd "$1" 2>/dev/null | grep -q 'libasan' && return 0
    grep -qa '__asan_init' "$1" 2>/dev/null && return 0
    return 1
}

assert_no_stage_files() {
    local found
    found="$(find "$1" -maxdepth 1 \
        \( -name '.jdvrif_*' -o -name '.*.jdvrif_tmp_*' \) -print -quit)"
    if [[ -n "$found" ]]; then
        echo "staging file remains: $found" >&2
        return 1
    fi
}

prepare_fixture() {
    local dir="$WORK/fresh_default"
    local embedded pin
    mkdir -p "$dir"
    (cd "$dir" && "$IN_BIN" "$COVER" "$PAYLOAD" > conceal.log 2>&1)
    embedded="$(extract_embedded_image "$dir/conceal.log")"
    pin="$(extract_pin "$dir/conceal.log")"
    [[ -n "$embedded" && -n "$pin" && -f "$dir/$embedded" ]] || {
        cat "$dir/conceal.log" >&2
        return 1
    }
    printf '%s\n' "$pin" > "$dir/pin.txt"
    chmod 600 "$dir/pin.txt"
    DEFAULT_IMAGE="$dir/$embedded"
    DEFAULT_PIN_FILE="$dir/pin.txt"
}

prepare_fixture

test_authenticated_compression_mode() {
    local dir="$WORK/compression_tamper"
    mkdir -p "$dir"
    cp "$DEFAULT_PIN_FILE" "$dir/pin.txt"
    python3 - "$DEFAULT_IMAGE" "$dir/mode.jpg" "$dir/downgrade.jpg" <<'PY'
import sys
from pathlib import Path

data = bytearray(Path(sys.argv[1]).read_bytes())
mntr = data.find(b"mntrRGB")
if mntr < 8:
    raise SystemExit("ICC signature not found")
base = mntr - 8
compression_flag = base + 0x68
kdf_marker = base + 0x2FB
# Accept any framing that authenticates the mode (KDF3, KDF4, KDF5, ...) so
# retiring a mint version stays a one-line change here.
if bytes(data[kdf_marker:kdf_marker + 4]) not in (b"KDF3", b"KDF4", b"KDF5"):
    raise SystemExit(
        f"fresh fixture does not use an authenticated KDF framing: "
        f"{bytes(data[kdf_marker:kdf_marker + 4])!r}")
if data[compression_flag] == 0x58:
    raise SystemExit("fresh small payload unexpectedly bypassed compression")

data[compression_flag] = 0x58
Path(sys.argv[2]).write_bytes(data)
data[kdf_marker:kdf_marker + 4] = b"KDF2"
Path(sys.argv[3]).write_bytes(data)
PY
    local image
    for image in mode.jpg downgrade.jpg; do
        if (cd "$dir" && "$OUT_BIN" "$image" pin.txt > "recover-$image.log" 2>&1); then
            echo "tampered compression semantics were accepted from $image" >&2
            return 1
        fi
    done
    if find "$dir" -maxdepth 1 -type f -name 'payload_text*' -print -quit | grep -q .; then
        echo "tampered recovery left plaintext output" >&2
        return 1
    fi
    assert_no_stage_files "$dir"
}

# KDF4/KDF5 record the Argon2id cost parameters in the image. Out-of-range costs
# drive an allocation and a work loop that both run before a wrong PIN can be
# detected, so they must be refused outright -- and refused without the PIN file
# being consumed, like every other unusable-metadata rejection.
test_kdf_cost_bounds() {
    local dir="$WORK/kdf_costs"
    mkdir -p "$dir"
    cp "$DEFAULT_PIN_FILE" "$dir/pin.txt"
    python3 - "$DEFAULT_IMAGE" "$dir" <<'KDFPY'
import sys
from pathlib import Path

data = bytearray(Path(sys.argv[1]).read_bytes())
out = Path(sys.argv[2])
mntr = data.find(b"mntrRGB")
if mntr < 8:
    raise SystemExit("ICC signature not found")
kdf = mntr - 8 + 0x2FB
if bytes(data[kdf:kdf + 4]) != b"KDF5":
    raise SystemExit(f"fixture is not KDF5: {bytes(data[kdf:kdf + 4])!r}")

ops = kdf + 48
mem = kdf + 52
if int.from_bytes(data[ops:ops + 4], "big") != 2:
    raise SystemExit("unexpected recorded opslimit")
if int.from_bytes(data[mem:mem + 4], "big") != 64 * 1024 * 1024:
    raise SystemExit("unexpected recorded memlimit")

for name, (offset, value) in {
    "huge_mem.jpg": (mem, 0xFFFFFFFF),
    "zero_mem.jpg": (mem, 0),
    "huge_ops.jpg": (ops, 0xFFFFFFFF),
    "zero_ops.jpg": (ops, 0),
}.items():
    patched = bytearray(data)
    patched[offset:offset + 4] = value.to_bytes(4, "big")
    (out / name).write_bytes(patched)
KDFPY

    local image
    for image in huge_mem.jpg zero_mem.jpg huge_ops.jpg zero_ops.jpg; do
        if (cd "$dir" && "$OUT_BIN" "$image" pin.txt > "recover-$image.log" 2>&1); then
            echo "out-of-range KDF costs were accepted from $image" >&2
            return 1
        fi
        if ! grep -Fq 'unsupported key-derivation parameters' "$dir/recover-$image.log"; then
            echo "wrong rejection reason for $image:" >&2
            cat "$dir/recover-$image.log" >&2
            return 1
        fi
    done
    if find "$dir" -maxdepth 1 -type f -name 'payload_text*' -print -quit | grep -q .; then
        echo "rejected recovery left plaintext output" >&2
        return 1
    fi
    assert_no_stage_files "$dir"
}

test_wrong_pin_leaves_no_plaintext() {
    local dir="$WORK/wrong_pin"
    local actual_pin wrong_pin="$WRONG_PIN"
    mkdir -p "$dir"
    cp "$DEFAULT_IMAGE" "$dir/input.jpg"
    actual_pin="$(sed -n '1p' "$DEFAULT_PIN_FILE")"
    if [[ "$actual_pin" == "$wrong_pin" ]]; then wrong_pin="$WRONG_PIN_ALT"; fi
    printf '%s\n' "$wrong_pin" > "$dir/wrong-pin.txt"
    if (cd "$dir" && "$OUT_BIN" input.jpg wrong-pin.txt > recover.log 2>&1); then
        echo "jdv_out unexpectedly accepted a wrong PIN" >&2
        return 1
    fi
    if find "$dir" -maxdepth 1 -type f -name 'payload_text*' -print -quit | grep -q .; then
        echo "wrong-PIN recovery left plaintext output" >&2
        return 1
    fi
    assert_no_stage_files "$dir"
}

# A wrong PIN must be rejected from the first frame, read where the
# ciphertext sits, without copying it anywhere first. RLIMIT_FSIZE makes that
# filesystem-independent: recovery under an 8 MiB cap can only report the bad
# PIN if it never writes the 32 MiB ciphertext out.
test_wrong_pin_stages_no_ciphertext() {
    local dir="$WORK/wrong_pin_no_staging"
    local image pin wrong_pin="$WRONG_PIN"
    mkdir -p "$dir"
    head -c $((32 * 1024 * 1024)) /dev/urandom > "$dir/payload.bin"
    (cd "$dir" && "$IN_BIN" "$COVER" payload.bin > conceal.log 2>&1)
    image="$(extract_embedded_image "$dir/conceal.log")"
    pin="$(extract_pin "$dir/conceal.log")"
    [[ -n "$image" && -n "$pin" ]] || { echo "conceal of the large payload failed" >&2; return 1; }
    if [[ "$pin" == "$wrong_pin" ]]; then wrong_pin="$WRONG_PIN_ALT"; fi
    printf '%s\n' "$wrong_pin" > "$dir/wrong-pin.txt"
    rm -f "$dir/payload.bin"
    if (cd "$dir" && ulimit -f 8192 && "$OUT_BIN" "$image" wrong-pin.txt > recover.log 2>&1); then
        echo "jdv_out unexpectedly accepted a wrong PIN" >&2
        return 1
    fi
    if ! grep -Fq 'Invalid recovery KEY or file is corrupt.' "$dir/recover.log"; then
        echo "wrong PIN was not rejected before staging I/O:" >&2
        cat "$dir/recover.log" >&2
        return 1
    fi
    [[ ! -e "$dir/payload.bin" ]] || { echo "wrong PIN recovered a payload" >&2; return 1; }
    assert_no_stage_files "$dir"
}

test_oversized_pin_file_rejected() {
    local dir="$WORK/oversized_pin"
    mkdir -p "$dir"
    cp "$DEFAULT_IMAGE" "$dir/input.jpg"
    python3 - "$dir/oversized-pin.txt" <<'PY'
import sys
from pathlib import Path

Path(sys.argv[1]).write_bytes(b"1" * 65)
PY
    if (cd "$dir" && "$OUT_BIN" input.jpg oversized-pin.txt > recover.log 2>&1); then
        echo "jdv_out accepted a PIN file over 64 bytes" >&2
        return 1
    fi
    grep -Eiq 'PIN.*64-byte size limit|PIN.*size limit' "$dir/recover.log"
    if find "$dir" -maxdepth 1 -type f -name 'payload_text*' -print -quit | grep -q .; then
        echo "oversized-PIN recovery left plaintext output" >&2
        return 1
    fi
    assert_no_stage_files "$dir"
}

test_truncated_ciphertext() {
    local dir="$WORK/truncated"
    mkdir -p "$dir"
    cp "$DEFAULT_PIN_FILE" "$dir/pin.txt"
    python3 - "$DEFAULT_IMAGE" "$dir/input.jpg" <<'PY'
import sys
from pathlib import Path

data = Path(sys.argv[1]).read_bytes()
mntr = data.find(b"mntrRGB")
if mntr < 8:
    raise SystemExit("ICC signature not found")
base = mntr - 8
size = int.from_bytes(data[base + 0x2CA:base + 0x2CE], "big")
payload = base + 0x33B
if size < 2 or payload + size > len(data):
    raise SystemExit("unexpected embedded layout")
Path(sys.argv[2]).write_bytes(data[:payload + size - 1])
PY
    if (cd "$dir" && "$OUT_BIN" input.jpg pin.txt > recover.log 2>&1); then
        echo "jdv_out accepted truncated ciphertext" >&2
        return 1
    fi
    if find "$dir" -maxdepth 1 -type f -name 'payload_text*' -print -quit | grep -q .; then
        echo "truncated recovery left plaintext output" >&2
        return 1
    fi
    assert_no_stage_files "$dir"
}

test_nondefault_icc_offset_rejected() {
    local dir="$WORK/nondefault_icc_offset"
    mkdir -p "$dir"
    cp "$DEFAULT_PIN_FILE" "$dir/pin.txt"
    python3 - "$DEFAULT_IMAGE" "$dir/input.jpg" <<'PY'
import sys
from pathlib import Path

data = Path(sys.argv[1]).read_bytes()
if not data.startswith(b"\xff\xd8"):
    raise SystemExit("default fixture is not a JPEG")

# Insert a valid APP0 segment after SOI. The embedded profile remains intact,
# but is no longer at jdvrif's one supported ICC offset.
app0 = b"\xff\xe0\x00\x04AB"
Path(sys.argv[2]).write_bytes(data[:2] + app0 + data[2:])
PY
    if (cd "$dir" && "$OUT_BIN" input.jpg pin.txt > recover.log 2>&1); then
        echo "jdv_out accepted an embedded profile at a nondefault offset" >&2
        return 1
    fi
    # jdv_out verifies the ICC and jdvrif signatures at their two fixed offsets
    # rather than scanning for them, so a shifted profile is not recognised as a
    # jdvrif image at all.
    #
    # It then falls through to the Reddit carrier, whose coefficient positions
    # derive from the PIN -- so the refusal is the same one a wrong PIN or an
    # ordinary JPEG gets. That uniformity is deliberate: the tool must not leak
    # which of those three an image is.
    if ! grep -Fq 'Invalid KEY/PIN, or this is not a valid jdvrif "file-embedded" image' "$dir/recover.log"; then
        echo "nondefault ICC offset was not rejected uniformly" >&2
        cat "$dir/recover.log" >&2
        return 1
    fi
    if find "$dir" -maxdepth 1 -type f -name 'payload_text*' -print -quit | grep -q .; then
        echo "nondefault ICC recovery left plaintext output" >&2
        return 1
    fi
    assert_no_stage_files "$dir"
}

test_pin_delivery_failure_is_transactional() {
    local dir="$WORK/full_stdout"
    local found
    [[ -e /dev/full ]] || return 77
    mkdir -p "$dir"
    if (cd "$dir" && "$IN_BIN" "$COVER" "$PAYLOAD" > /dev/full 2> conceal.err); then
        echo "jdv_in succeeded although its PIN could not be delivered" >&2
        return 1
    fi
    found="$(find "$dir" -maxdepth 1 \
        \( -name 'jrif_*.jpg' -o -name '.jdvrif_*' -o -name '.*.jdvrif_tmp_*' \) \
        -print -quit)"
    if [[ -n "$found" ]]; then
        echo "jdv_in committed or leaked output after PIN delivery failure: $found" >&2
        return 1
    fi
}

# After the recovery PIN has been printed, the fsynced temp image is the only
# durable copy that PIN can open. A later commit failure (here: colliding the
# chosen output name) must leave that image in place and name it in the error.
test_image_committed_before_pin() {
    local dir="$WORK/commit_before_pin"
    mkdir -p "$dir"
    python3 - "$IN_BIN" "$COVER" "$PAYLOAD" "$dir" <<'PY'
import ctypes
import fcntl
import os
import re
import struct
import subprocess
import sys
import time
from pathlib import Path

*command, cover, payload, work = sys.argv[1:]
command = command[0].split("\x1f")
if os.uname().machine != "x86_64":
    sys.exit(77)  # the /proc/PID/syscall check below uses x86-64 numbering
work = Path(work)

libc = ctypes.CDLL("libc.so.6", use_errno=True)
IN_CREATE = 0x00000100
IN_MOVED_TO = 0x00000080
EVENT = struct.Struct("iIII")

fd = libc.inotify_init1(os.O_CLOEXEC | os.O_NONBLOCK)
if fd < 0:
    raise OSError(ctypes.get_errno(), "inotify_init1")
if libc.inotify_add_watch(fd, os.fsencode(work), IN_CREATE | IN_MOVED_TO) < 0:
    os.close(fd)
    raise OSError(ctypes.get_errno(), "inotify_add_watch")

def drain_names():
    names = []
    while True:
        try:
            chunk = os.read(fd, 65536)
        except BlockingIOError:
            return names
        pos = 0
        while pos + EVENT.size <= len(chunk):
            _, _, _, length = EVENT.unpack_from(chunk, pos)
            pos += EVENT.size
            names.append(chunk[pos:pos + length].split(b"\x00", 1)[0].decode())
            pos += length

# Pre-fill a minimal stdout pipe so the child blocks on its first real write
# to stdout. Redirected stdout is fully buffered and nothing is flushed before
# the PIN, so that write is the PIN delivery: while it is blocked there, the
# image must already be complete under its final name.
F_SETPIPE_SZ = 1031
read_end, write_end = os.pipe()
fcntl.fcntl(write_end, F_SETPIPE_SZ, 4096)
os.set_blocking(write_end, False)
filler = 0
try:
    while True:
        filler += os.write(write_end, b"\0" * 4096)
except BlockingIOError:
    pass
os.set_blocking(write_end, True)

proc = subprocess.Popen(command + [cover, payload], cwd=work,
                        stdout=write_end, stderr=subprocess.PIPE)
os.close(write_end)
committed_at_pin = None
stdout = b""
try:
    deadline = time.monotonic() + 120
    while committed_at_pin is None:
        if proc.poll() is not None:
            raise RuntimeError("conceal exited before writing to stdout")
        if time.monotonic() > deadline:
            raise RuntimeError("conceal never blocked on its stdout write")
        try:
            call = Path(f"/proc/{proc.pid}/syscall").read_text().split()
        except OSError:
            call = []
        # Blocked in write(2) (syscall 1 on x86-64) on fd 1.
        if len(call) > 1 and call[0] == "1" and int(call[1], 16) == 1:
            committed_at_pin = [p for p in work.glob("jrif_*.jpg") if p.stat().st_size > 0]
        else:
            time.sleep(0.01)
    while True:
        data = os.read(read_end, 65536)
        if not data:
            break
        stdout += data
    _, stderr = proc.communicate(timeout=60)
finally:
    if proc.poll() is None:
        proc.kill()
        proc.wait()
    os.close(read_end)
stdout = stdout[filler:]
created = drain_names()
os.close(fd)

log = (stdout + b"\n" + stderr).decode(errors="replace")
if proc.returncode != 0:
    raise RuntimeError(f"conceal failed:\n{log}")
if not committed_at_pin or len(committed_at_pin) != 1:
    raise RuntimeError(f"image was not committed before the PIN was shown: {committed_at_pin}\n{log}")
saved = re.search(r'Saved "file-embedded" JPG image: (\S+) ', log)
if saved is None or saved.group(1) != committed_at_pin[0].name:
    raise RuntimeError(f"reported output does not match the committed image:\n{log}")
# The only directory entries ever created: the final image, and (on a filesystem
# without O_TMPFILE) the momentary, still-empty name of a staging inode.
for name in created:
    if name == committed_at_pin[0].name or re.fullmatch(r"\.jdvrif_\w+_[0-9a-f]+\.tmp", name):
        continue
    raise RuntimeError(f"conceal exposed an unexpected directory entry: {name}")
PY
}

test_bluesky_final_output_size_limit() {
    local dir="$WORK/bluesky_final_size"
    local accepted_payload="$FIXTURES/payloads/bsingle.bin"
    local rejected_payload="$FIXTURES/payloads/bxmp.bin"
    local embedded accepted_size found

    if ! command -v ffmpeg >/dev/null 2>&1; then
        echo "ffmpeg is unavailable; near-limit Bluesky fixture not generated" >&2
        return 77
    fi

    mkdir -p "$dir/accepted" "$dir/rejected"
    ffmpeg -hide_banner -loglevel error -y \
        -f lavfi \
        -i 'nullsrc=size=1770x1770,noise=alls=100:allf=u:all_seed=12345' \
        -frames:v 1 -q:v 2 "$dir/cover.jpg"

    (
        cd "$dir/accepted"
        "$IN_BIN" -b "$dir/cover.jpg" "$accepted_payload" > conceal.log 2>&1
    )
    embedded="$(extract_embedded_image "$dir/accepted/conceal.log")"
    if [[ -z "$embedded" || ! -f "$dir/accepted/$embedded" ]]; then
        echo "near-limit Bluesky control did not produce an output image" >&2
        cat "$dir/accepted/conceal.log" >&2
        return 1
    fi
    accepted_size="$(stat -c '%s' "$dir/accepted/$embedded")"
    if [[ "$accepted_size" -gt 2000000 ]]; then
        echo "Bluesky conceal accepted a $accepted_size-byte output image" >&2
        return 1
    fi
    assert_no_stage_files "$dir/accepted"

    if (
        cd "$dir/rejected"
        "$IN_BIN" -b "$dir/cover.jpg" "$rejected_payload" > conceal.log 2>&1
    ); then
        echo "Bluesky conceal accepted a final output image over 2,000,000 bytes" >&2
        return 1
    fi
    grep -Fq \
        'File Size Error: Final output image exceeds the 2,000,000-byte limit for the Bluesky platform.' \
        "$dir/rejected/conceal.log"
    grep -Fq \
        '                 Use a smaller cover image or reduce the size of the payload (hidden data file).' \
        "$dir/rejected/conceal.log"
    if grep -Fq 'Recovery KEY:' "$dir/rejected/conceal.log"; then
        echo "Bluesky conceal disclosed a PIN for a rejected output image" >&2
        return 1
    fi
    found="$(find "$dir/rejected" -maxdepth 1 -type f -name 'jrif_*.jpg' -print -quit)"
    if [[ -n "$found" ]]; then
        echo "Bluesky conceal committed an oversized output image: $found" >&2
        return 1
    fi
    assert_no_stage_files "$dir/rejected"
}

test_oversized_jpeg_dimensions() {
    local dir="$WORK/huge_dimensions"
    local rc
    mkdir -p "$dir"
    python3 - "$COVER" "$dir/huge.jpg" <<'PY'
import sys
from pathlib import Path

data = bytearray(Path(sys.argv[1]).read_bytes())
pos = 2
sof = None
while pos + 4 <= len(data):
    if data[pos] != 0xFF:
        pos += 1
        continue
    while pos < len(data) and data[pos] == 0xFF:
        pos += 1
    marker = data[pos]
    pos += 1
    if marker in (0x01, 0xD8, 0xD9) or 0xD0 <= marker <= 0xD7:
        continue
    if marker == 0xDA:
        break
    length = int.from_bytes(data[pos:pos + 2], "big")
    if marker in {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                  0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}:
        sof = pos + 2
        break
    pos += length
if sof is None:
    raise SystemExit("SOF marker not found")
data[sof + 1:sof + 3] = (65000).to_bytes(2, "big")
data[sof + 3:sof + 5] = (65000).to_bytes(2, "big")
Path(sys.argv[2]).write_bytes(data)
PY
    local capped=1
    if binary_is_sanitized "$IN_BIN"; then
        capped=0
    fi

    if command -v timeout >/dev/null 2>&1; then
        set +e
        (
            cd "$dir"
            if [[ "$capped" -eq 1 ]]; then ulimit -v 524288; fi
            timeout 10 "$IN_BIN" huge.jpg "$PAYLOAD" > conceal.log 2>&1
        )
        rc=$?
        set -e
        if [[ "$rc" -eq 0 || "$rc" -eq 124 || "$rc" -eq 137 ]]; then
            echo "oversized-dimension rejection returned unsafe status $rc" >&2
            return 1
        fi
    else
        if (
            cd "$dir"
            if [[ "$capped" -eq 1 ]]; then ulimit -v 524288; fi
            "$IN_BIN" huge.jpg "$PAYLOAD" > conceal.log 2>&1
        ); then
            echo "oversized JPEG dimensions were accepted" >&2
            return 1
        fi
    fi
    grep -Eiq 'dimension|pixel|too large|maximum' "$dir/conceal.log"
    assert_no_stage_files "$dir"
}

test_default_dimension_limit() {
    local dir="$WORK/default_dimension_limit"
    mkdir -p "$dir"
    python3 - "$COVER" "$dir/over_width.jpg" <<'PY'
import sys
from pathlib import Path

data = bytearray(Path(sys.argv[1]).read_bytes())
pos = 2
sof = None
while pos + 4 <= len(data):
    if data[pos] != 0xFF:
        pos += 1
        continue
    while pos < len(data) and data[pos] == 0xFF:
        pos += 1
    marker = data[pos]
    pos += 1
    if marker in (0x01, 0xD8, 0xD9) or 0xD0 <= marker <= 0xD7:
        continue
    if marker == 0xDA:
        break
    length = int.from_bytes(data[pos:pos + 2], "big")
    if marker in {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                  0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}:
        sof = pos + 2
        break
    pos += length
if sof is None:
    raise SystemExit("SOF marker not found")
data[sof + 3:sof + 5] = (4097).to_bytes(2, "big")
Path(sys.argv[2]).write_bytes(data)
PY

    if (cd "$dir" && "$IN_BIN" over_width.jpg "$PAYLOAD" > conceal.log 2>&1); then
        echo "4097-pixel-wide default cover was unexpectedly accepted" >&2
        return 1
    fi
    grep -Fq 'exceed the safe cover-image limit (4096px per dimension and 16777216 total pixels)' "$dir/conceal.log"
    assert_no_stage_files "$dir"
}

test_cmyk_cover_rejected() {
    local dir="$WORK/cmyk"
    if ! python3 -c 'import PIL' >/dev/null 2>&1; then
        return 77
    fi
    mkdir -p "$dir"
    python3 - "$dir/cmyk.jpg" <<'PY'
import sys
from PIL import Image

Image.new("CMYK", (500, 500), (0, 255, 255, 0)).save(
    sys.argv[1], format="JPEG", quality=90
)
PY
    if (cd "$dir" && "$IN_BIN" cmyk.jpg "$PAYLOAD" > conceal.log 2>&1); then
        echo "CMYK cover was accepted" >&2
        return 1
    fi
    grep -Eiq 'CMYK|YCCK|color space|unsupported' "$dir/conceal.log"
}

test_post_transform_dimensions() {
    local dir="$WORK/trimmed_dimensions"
    local magick_bin
    magick_bin="$(command -v magick || command -v convert || true)"
    if [[ -z "$magick_bin" ]]; then
        return 77
    fi
    mkdir -p "$dir"
    "$magick_bin" -size 400x401 gradient:red-blue -colorspace sRGB \
        -sampling-factor 4:1:1 -quality 90 "$dir/base.jpg"
    python3 - "$dir/base.jpg" "$dir/oriented.jpg" <<'PY'
import struct
import sys
from pathlib import Path

data = Path(sys.argv[1]).read_bytes()
if not data.startswith(b"\xff\xd8"):
    raise SystemExit("not a JPEG")
tiff = (
    b"II\x2a\x00" + struct.pack("<I", 8) + struct.pack("<H", 1) +
    struct.pack("<HHI", 0x0112, 3, 1) + struct.pack("<H", 2) + b"\x00\x00" +
    struct.pack("<I", 0)
)
payload = b"Exif\x00\x00" + tiff
app1 = b"\xff\xe1" + struct.pack(">H", len(payload) + 2) + payload
Path(sys.argv[2]).write_bytes(data[:2] + app1 + data[2:])
PY
    if (cd "$dir" && "$IN_BIN" oriented.jpg "$PAYLOAD" > conceal.log 2>&1); then
        echo "cover trimmed below 400px was accepted" >&2
        return 1
    fi
    grep -Eiq 'dimension|too small|at least 400' "$dir/conceal.log"
    assert_no_stage_files "$dir"
}

test_referenced_nonzero_dqt_quality() {
    local dir="$WORK/nonzero_dqt"
    local embedded
    if ! python3 -c 'import PIL' >/dev/null 2>&1; then
        return 77
    fi
    mkdir -p "$dir"
    python3 - "$dir/dqt1.jpg" <<'PY'
import io
import sys
from pathlib import Path
from PIL import Image

buffer = io.BytesIO()
Image.new("L", (500, 500), 128).save(buffer, format="JPEG", quality=100)
data = bytearray(buffer.getvalue())
pos = 2
changed_dqt = False
changed_sof = False
while pos + 4 <= len(data):
    if data[pos] != 0xFF:
        pos += 1
        continue
    while pos < len(data) and data[pos] == 0xFF:
        pos += 1
    marker = data[pos]
    pos += 1
    if marker in (0x01, 0xD8, 0xD9) or 0xD0 <= marker <= 0xD7:
        continue
    if marker == 0xDA:
        break
    length = int.from_bytes(data[pos:pos + 2], "big")
    payload = pos + 2
    end = pos + length
    if marker == 0xDB:
        cursor = payload
        while cursor < end:
            header = data[cursor]
            table_size = 128 if header >> 4 else 64
            if (header & 0x0F) == 0:
                data[cursor] = (header & 0xF0) | 1
                changed_dqt = True
            cursor += 1 + table_size
    elif marker in {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                    0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}:
        components = data[payload + 5]
        for index in range(components):
            qsel = payload + 6 + index * 3 + 2
            if data[qsel] == 0:
                data[qsel] = 1
                changed_sof = True
    pos = end
if not (changed_dqt and changed_sof):
    raise SystemExit("failed to build nonzero-DQT fixture")
Path(sys.argv[1]).write_bytes(data)
PY
    if (cd "$dir" && "$IN_BIN" dqt1.jpg "$PAYLOAD" > conceal.log 2>&1); then
        echo "quality-100 cover using DQT table 1 was accepted" >&2
        return 1
    fi
    grep -Eiq 'quality.*exceeds|quality.*maximum' "$dir/conceal.log"
    assert_no_stage_files "$dir"

    mkdir -p "$dir/bluesky"
    if ! (
        cd "$dir/bluesky"
        "$IN_BIN" -b "$dir/dqt1.jpg" "$PAYLOAD" > conceal.log 2>&1
    ); then
        echo "quality-100 cover was rejected in Bluesky mode" >&2
        cat "$dir/bluesky/conceal.log" >&2
        return 1
    fi
    embedded="$(extract_embedded_image "$dir/bluesky/conceal.log")"
    if [[ -z "$embedded" || ! -f "$dir/bluesky/$embedded" ]]; then
        echo "Bluesky mode did not produce an output for the quality-100 cover" >&2
        cat "$dir/bluesky/conceal.log" >&2
        return 1
    fi
    assert_no_stage_files "$dir/bluesky"
}

# The compression stage holds the deflated payload, which is plaintext-
# equivalent. It must live on a link-free inode (StagingFile): never present as
# a directory entry, so it cannot be listed, backed up or sync-uploaded, and
# cannot outlive a SIGKILL. Detect it through /proc/<pid>/fd, where such an
# inode appears as "<dir>/... (deleted)", and assert it never appears by name.
staging_inode_open() {
    local pid="$1" dir="$2" fd target
    for fd in /proc/"$pid"/fd/*; do
        target="$(readlink "$fd" 2>/dev/null)" || continue
        case "$target" in
            "$dir"/*" (deleted)") return 0 ;;
        esac
    done
    return 1
}

test_signal_cleans_compression_stage() {
    local dir="$WORK/signal_cleanup"
    local pid status seen=0
    command -v truncate >/dev/null 2>&1 || return 77
    mkdir -p "$dir"
    truncate -s "$((512 * 1024 * 1024))" "$dir/source.bin"
    (
        cd "$dir"
        exec "$IN_BIN" "$COVER" source.bin > conceal.log 2>&1
    ) &
    pid=$!

    for ((attempt = 0; attempt < 1000; ++attempt)); do
        # A named staging file at any point is the failure this test exists for.
        if find "$dir" -maxdepth 1 -type f \
            \( -name '.jdvrif_*' -o -name '.*.jdvrif_tmp_*' \) -print -quit | grep -q .; then
            kill -TERM "$pid" 2>/dev/null || true
            wait "$pid" 2>/dev/null || true
            echo "compression stage appeared as a named file in the working directory" >&2
            return 1
        fi
        if staging_inode_open "$pid" "$dir"; then
            seen=1
            kill -TERM "$pid"
            break
        fi
        if ! kill -0 "$pid" 2>/dev/null; then break; fi
        sleep 0.01
    done
    if [[ "$seen" -eq 0 ]]; then
        if kill -0 "$pid" 2>/dev/null; then kill -TERM "$pid"; fi
        wait "$pid" 2>/dev/null || true
        echo "did not observe the anonymous compression staging inode before jdv_in exited" >&2
        return 1
    fi

    set +e
    wait "$pid"
    status=$?
    set -e
    if [[ "$status" -eq 0 ]]; then
        echo "signal-interrupted jdv_in returned success" >&2
        return 1
    fi
    assert_no_stage_files "$dir"
    if find "$dir" -maxdepth 1 -type f -name 'jrif_*.jpg' -print -quit | grep -q .; then
        echo "signal-interrupted jdv_in committed an output image" >&2
        return 1
    fi
}

test_dangling_symlink_collision() {
    local dir="$WORK/dangling_symlink"
    local recovered
    mkdir -p "$dir"
    cp "$DEFAULT_IMAGE" "$dir/input.jpg"
    cp "$DEFAULT_PIN_FILE" "$dir/pin.txt"
    ln -s missing-target "$dir/payload_text.txt"
    (cd "$dir" && "$OUT_BIN" input.jpg pin.txt > recover.log 2>&1)
    recovered="$(extract_recovered_file "$dir/recover.log")"
    [[ "$recovered" == "payload_text_1.txt" ]] || {
        echo "expected payload_text_1.txt, got ${recovered:-<none>}" >&2
        return 1
    }
    [[ -L "$dir/payload_text.txt" ]]
    [[ "$(readlink "$dir/payload_text.txt")" == "missing-target" ]]
    cmp -s "$dir/$recovered" "$PAYLOAD"
    assert_no_stage_files "$dir"
}

patch_declared_size() {
    python3 - "$1" "$2" "$3" <<'PY'
import sys
from pathlib import Path

data = bytearray(Path(sys.argv[1]).read_bytes())
mntr = data.find(b"mntrRGB")
if mntr < 8:
    raise SystemExit("ICC signature not found")
base = mntr - 8
data[base + 0x2CA:base + 0x2CE] = int(sys.argv[3]).to_bytes(4, "big")
Path(sys.argv[2]).write_bytes(data)
PY
}

assert_recovery_cap() {
    local source_image="$1"
    local source_pin="$2"
    local maximum="$3"
    local tag="$4"
    local dir="$WORK/$tag"
    mkdir -p "$dir/at_limit" "$dir/over_limit"
    cp "$source_pin" "$dir/pin.txt"
    patch_declared_size "$source_image" "$dir/at_limit/input.jpg" "$maximum"
    patch_declared_size "$source_image" "$dir/over_limit/input.jpg" "$((maximum + 1))"

    if (cd "$dir/at_limit" && "$OUT_BIN" input.jpg ../pin.txt > recover.log 2>&1); then
        echo "synthetic at-limit fixture unexpectedly recovered" >&2
        return 1
    fi
    if grep -q 'exceeds the maximum allowed' "$dir/at_limit/recover.log"; then
        echo "$tag rejected its documented wiggle-room boundary" >&2
        return 1
    fi
    if (cd "$dir/over_limit" && "$OUT_BIN" input.jpg ../pin.txt > recover.log 2>&1); then
        echo "$tag accepted a declaration over its recovery cap" >&2
        return 1
    fi
    grep -q 'exceeds the maximum allowed' "$dir/over_limit/recover.log"
    assert_no_stage_files "$dir/at_limit"
    assert_no_stage_files "$dir/over_limit"
}

test_default_recovery_wiggle_room() {
    assert_recovery_cap "$DEFAULT_IMAGE" "$DEFAULT_PIN_FILE" \
        "$((2 * 1024 * 1024 * 1024 + 50 * 1024 * 1024))" default_size_boundary
}

test_legacy_recovery_warning() {
    local dir="$WORK/legacy_warning"
    mkdir -p "$dir"
    python3 - "$OUT_BIN" "$FIXTURES" "$dir" "$DEFAULT_IMAGE" "$DEFAULT_PIN_FILE" <<'PY'
import csv
import subprocess
import sys
import zlib
from pathlib import Path

binary, fixtures, work, current_image, current_pin_file = sys.argv[1:]
fixtures, work = Path(fixtures), Path(work)
with (fixtures / "golden/manifest.tsv").open() as manifest:
    case = next(row for row in csv.DictReader(manifest, delimiter="\t")
                if row["case_id"] == "default_single")
legacy = bytearray((fixtures / case["golden_rel"]).read_bytes())
base = legacy.index(b"mntrRGB") - 8
assert legacy[base + 0x2FB:base + 0x2FF] == b"KDF2"
expected = (fixtures / case["payload_rel"].removeprefix("testdata/")).read_bytes()
warning = "Warning: Legacy KDF2 image: the compression flag is unauthenticated"

for name in ("legacy", "altered", "current"):
    directory = work / name
    directory.mkdir()
    data = bytearray(legacy)
    pin = (case["pin"] + "\n").encode()
    if name == "altered":
        data[base + 0x68] = 0x58
    elif name == "current":
        data = Path(current_image).read_bytes()
        pin = Path(current_pin_file).read_bytes()
    (directory / "input.jpg").write_bytes(data)
    (directory / "pin.txt").write_bytes(pin)
    (directory / "pin.txt").chmod(0o600)
    result = subprocess.run([binary, "input.jpg", "pin.txt"], cwd=directory,
                            text=True, capture_output=True, timeout=30)
    assert result.returncode == 0, result.stdout + result.stderr
    assert result.stderr.count(warning) == (0 if name == "current" else 1), result.stderr
    if name != "current":
        recovered = (directory / Path(case["payload_rel"]).name).read_bytes()
        if name == "altered":
            assert recovered != expected
            recovered = zlib.decompress(recovered)
        assert recovered == expected
PY
}

test_inflater_wipes_plaintext() {
    local dir="$WORK/inflate_wipe"
    mkdir -p "$dir"
    "${CXX:-g++}" -std=c++23 -O1 -fsized-deallocation -I"$ROOT" \
        "$TESTS/test_inflate_wipe.cpp" "$ROOT/file_utils.cpp" "$ROOT/signal_utils.cpp" \
        -Wl,--wrap=_ZdlPvm,--wrap=malloc,--wrap=free -lsodium -lz -o "$dir/test_inflate_wipe"
    (cd "$dir" && ./test_inflate_wipe)
}

test_base64_wrapper_strictness() {
    local dir="$WORK/base64"
    mkdir -p "$dir"
    "${CXX:-g++}" -std=c++23 -Wall -Wextra -I"$ROOT" \
        "$TESTS/test_base64.cpp" "$ROOT/base64.cpp" "$ROOT/binary_io.cpp" \
        "$ROOT/file_utils.cpp" "$ROOT/signal_utils.cpp" -lsodium -o "$dir/test_base64"
    "$dir/test_base64"
}

test_deflater_wipes_plaintext() {
    local dir="$WORK/deflate_wipe"
    mkdir -p "$dir"
    "${CXX:-g++}" -std=c++23 -O1 -I"$ROOT" \
        "$TESTS/test_deflate_wipe.cpp" "$ROOT/file_utils.cpp" "$ROOT/signal_utils.cpp" \
        -Wl,--wrap=malloc,--wrap=free -lsodium -lz -ldeflate -o "$dir/test_deflate_wipe"
    (cd "$dir" && ./test_deflate_wipe)
}

test_input_readers_leave_no_plaintext() {
    local dir="$WORK/input_wipe"
    mkdir -p "$dir"
    "${CXX:-g++}" -std=c++23 -O1 -I"$ROOT" \
        "$TESTS/test_plaintext_input_wipe.cpp" "$ROOT/file_utils.cpp" "$ROOT/signal_utils.cpp" \
        -lsodium -lz -ldeflate -o "$dir/test_plaintext_input_wipe"
    (cd "$dir" && ./test_plaintext_input_wipe)
}

test_copy_fallback_wipes_plaintext() {
    local dir="$WORK/copy_fallback_wipe"
    mkdir -p "$dir"
    "${CXX:-g++}" -std=c++23 -O1 -fsized-deallocation -I"$ROOT" \
        "$TESTS/test_copy_fallback_wipe.cpp" "$ROOT/file_utils.cpp" "$ROOT/signal_utils.cpp" \
        -Wl,--wrap=_ZdlPvm,--wrap=sendfile -lsodium -o "$dir/test_copy_fallback_wipe"
    (cd "$dir" && ./test_copy_fallback_wipe)
}

test_publish_fallback_is_atomic() {
    local dir="$WORK/publish_fallback"
    mkdir -p "$dir"
    "${CXX:-g++}" -std=c++23 -O1 -I"$ROOT" \
        "$TESTS/test_publish_fallback.cpp" "$ROOT/file_utils.cpp" "$ROOT/signal_utils.cpp" \
        -Wl,--wrap=linkat,--wrap=renameat2,--wrap=link -lsodium -o "$dir/test_publish_fallback"
    (cd "$dir" && ./test_publish_fallback)
}

# --- 128-bit recovery PINs in PIN files (jdvrif v10) ------------------------
# jdv_out reads the PIN from a file: surrounding " \t\r\n" is trimmed, group
# dashes are ignored, and a file of exactly 8 / 16 raw bytes is a big-endian
# legacy PIN / raw 128-bit secret.

# Stderr of a failed run, without the blank lines main() frames it with.
error_text() {
    sed '/^$/d' "$1"
}

assert_no_recovered_payload() {
    if find "$1" -maxdepth 1 -type f -name 'payload_text*' -print -quit | grep -q .; then
        echo "recovery left plaintext output in $1" >&2
        return 1
    fi
    assert_no_stage_files "$1"
}

# write_pin_file <mode> <printed PIN> <path>
write_pin_file() {
    python3 - "$1" "$2" "$3" <<'PY'
import sys
from pathlib import Path

mode, pin, path = sys.argv[1:]
alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
if mode == "display":
    data = (pin + "\n").encode()
elif mode == "crlf":
    data = (pin + "\r\n").encode()
elif mode == "bom":
    data = b"\xef\xbb\xbf" + pin.encode()
elif mode == "typo":
    swap = "A" if pin[-1] != "A" else "B"
    data = (pin[:-1] + swap + "\n").encode()
elif mode == "raw16":
    body = pin.replace("-", "")[:22]
    value = 0
    for ch in body:
        value = value * 58 + alphabet.index(ch)
    data = value.to_bytes(16, "big")
else:
    raise SystemExit(f"unknown PIN-file mode {mode}")
Path(path).write_bytes(data)
Path(path).chmod(0o600)
PY
}

# recover_pin_file_ok <mode>: recover the fresh default image, expect success.
recover_pin_file_ok() {
    local dir="$WORK/pinfile_$1" pin recovered
    mkdir -p "$dir"
    cp "$DEFAULT_IMAGE" "$dir/input.jpg"
    pin="$(sed -n '1p' "$DEFAULT_PIN_FILE")"
    write_pin_file "$1" "$pin" "$dir/pin.txt"
    (cd "$dir" && "$OUT_BIN" input.jpg pin.txt > recover.log 2>&1) || {
        cat "$dir/recover.log" >&2
        return 1
    }
    recovered="$(extract_recovered_file "$dir/recover.log")"
    [[ -n "$recovered" ]] || { cat "$dir/recover.log" >&2; return 1; }
    cmp "$PAYLOAD" "$dir/$recovered"
}

# reject_pin_file <mode> <expected stderr>
reject_pin_file() {
    local dir="$WORK/pinfile_$1" pin
    mkdir -p "$dir"
    cp "$DEFAULT_IMAGE" "$dir/input.jpg"
    pin="$(sed -n '1p' "$DEFAULT_PIN_FILE")"
    write_pin_file "$1" "$pin" "$dir/pin.txt"
    if (cd "$dir" && "$OUT_BIN" input.jpg pin.txt > recover.out 2> recover.err); then
        echo "jdv_out accepted a $1 PIN file" >&2
        return 1
    fi
    if [[ "$(error_text "$dir/recover.err")" != "$2" ]]; then
        echo "unexpected error for a $1 PIN file:" >&2
        cat "$dir/recover.err" >&2
        return 1
    fi
    assert_no_recovered_payload "$dir"
}

test_pinfile_printed_grouped() {
    local pin
    pin="$(sed -n '1p' "$DEFAULT_PIN_FILE")"
    [[ "$pin" =~ $PIN128_RE ]] || {
        echo "printed PIN is not six groups of four Base58 characters: $pin" >&2
        return 1
    }
}
test_pinfile_display() { recover_pin_file_ok display; }
test_pinfile_crlf() { recover_pin_file_ok crlf; }
test_pinfile_raw16() { recover_pin_file_ok raw16; }
test_pinfile_bom() { reject_pin_file bom "$PIN_FILE_ERROR"; }
test_pinfile_typo() { reject_pin_file typo "$PIN_CHECK_ERROR"; }

# recover_raw_pin_file <name> <python expr for bytes> <image>: write the PIN
# file from the expression, recover into $WORK/pinfile_<name>; the caller reads
# recover.out/.err. Returns jdv_out's status.
pin_file_raw_run() {
    local name="$1" expr="$2" image="$3" dir="$WORK/pinfile_$1"
    mkdir -p "$dir"
    cp "$image" "$dir/input.jpg"
    python3 -c "import sys; sys.stdout.buffer.write($expr)" > "$dir/pin.txt"
    chmod 600 "$dir/pin.txt"
    (cd "$dir" && "$OUT_BIN" input.jpg pin.txt > recover.out 2> recover.err)
}

# The 8-byte big-endian legacy PIN file of a v9.x image still recovers.
test_pinfile_raw8_legacy() {
    local dir="$WORK/pinfile_raw8_legacy" pin recovered
    pin="$(cat "$FIXTURES/legacy_v9_1/default.pin")"
    pin_file_raw_run raw8_legacy "int('$pin').to_bytes(8, 'big')" "$FIXTURES/legacy_v9_1/default.jpg" || {
        cat "$dir/recover.err" >&2
        return 1
    }
    recovered="$(extract_recovered_file "$dir/recover.out")"
    [[ -n "$recovered" ]] || { cat "$dir/recover.out" "$dir/recover.err" >&2; return 1; }
    cmp "$FIXTURES/legacy_v9_1/payload.bin" "$dir/$recovered"
}

# reject_raw_pin_file <name> <python bytes expr> <expected stderr>: the image
# is the fresh default one; the PIN file must be refused promptly (no Argon2id).
reject_raw_pin_file() {
    local dir="$WORK/pinfile_$1" start elapsed
    start=$SECONDS
    if pin_file_raw_run "$1" "$2" "$DEFAULT_IMAGE"; then
        echo "jdv_out accepted PIN file $1" >&2
        return 1
    fi
    elapsed=$((SECONDS - start))
    if [[ "$(error_text "$dir/recover.err")" != "$3" ]]; then
        echo "unexpected error for PIN file $1:" >&2
        cat "$dir/recover.err" >&2
        return 1
    fi
    if (( elapsed > 2 )); then
        echo "PIN file $1 took ${elapsed}s to reject; Argon2id must not run" >&2
        return 1
    fi
    assert_no_recovered_payload "$dir"
}
test_pinfile_raw16_zero() { reject_raw_pin_file raw16_zero "bytes(16)" "$PIN_FILE_ERROR"; }
test_pinfile_raw8_zero() { reject_raw_pin_file raw8_zero "bytes(8)" "$PIN_FILE_ERROR"; }
test_pinfile_text16_typo() { reject_raw_pin_file text16_typo "b'1575398581951O60'" "$PIN_FILE_ERROR"; }

# A bad PIN file is named for what the image needs: KEY for a v10 default
# image, PIN for a pre-v10 one, and KEY/PIN for a coefficient carrier, which
# cannot be identified until the file has been read.
test_pinfile_word_matches_image() {
    local spec name image word
    for spec in "v10_default|$DEFAULT_IMAGE|KEY" \
                "legacy_default|$FIXTURES/legacy_v9_1/default.jpg|PIN" \
                "carrier|$FIXTURES/legacy_v9_1/reddit.jpg|KEY/PIN"; do
        IFS='|' read -r name image word <<< "$spec"
        if pin_file_raw_run "word_$name" "b'not a pin'" "$image"; then
            echo "$name: jdv_out accepted a bad PIN file" >&2
            return 1
        fi
        [[ "$(error_text "$WORK/pinfile_word_$name/recover.err")" == "$word File Error: Invalid file contents." ]] || {
            echo "$name: expected a $word file error, got:" >&2
            cat "$WORK/pinfile_word_$name/recover.err" >&2
            return 1
        }
    done
}

# The pre-v10 carrier fixtures' shared runner lives with the main CLI's tests;
# skip when the web tree is used on its own.
test_pinfile_legacy() {
    local script="$ROOT/../tests/run_legacy_fixture_tests.sh"
    [[ -f "$script" ]] || return 77
    bash "$script" --web-out "$OUT_BIN" > "$WORK/legacy_fixtures.log" 2>&1 || {
        cat "$WORK/legacy_fixtures.log" >&2
        return 1
    }
    grep -Fxq 'legacy fixtures: 6 passed, 0 failed' "$WORK/legacy_fixtures.log"
}

# A numeric PIN on a KDF5 image, and a 128-bit PIN on a pre-v10 one, are told
# which kind of PIN the image needs, before any Argon2id run.
test_mismatch_legacy_on_v10() {
    local dir="$WORK/mismatch_legacy_on_v10"
    mkdir -p "$dir"
    cp "$DEFAULT_IMAGE" "$dir/input.jpg"
    printf '%s\n' 15753985819510608748 > "$dir/pin.txt"
    if (cd "$dir" && "$OUT_BIN" input.jpg pin.txt > recover.out 2> recover.err); then
        echo "a numeric PIN was accepted for a v10 image" >&2
        return 1
    fi
    [[ "$(error_text "$dir/recover.err")" == "$MISMATCH_NEEDS_PIN128" ]] || {
        cat "$dir/recover.err" >&2
        return 1
    }
    assert_no_recovered_payload "$dir"
}

test_mismatch_v10_on_legacy() {
    local dir="$WORK/mismatch_v10_on_legacy" case
    for case in default_single bluesky_single; do
        mkdir -p "$dir/$case"
        cp "$FIXTURES/golden/$case/embedded.jpg" "$dir/$case/input.jpg"
        printf '%s\n' "$WRONG_PIN" > "$dir/$case/pin.txt"
        if (cd "$dir/$case" && "$OUT_BIN" input.jpg pin.txt > recover.out 2> recover.err); then
            echo "a 128-bit PIN was accepted for the pre-v10 $case image" >&2
            return 1
        fi
        [[ "$(error_text "$dir/$case/recover.err")" == "$MISMATCH_NEEDS_LEGACY" ]] || {
            cat "$dir/$case/recover.err" >&2
            return 1
        }
        assert_no_recovered_payload "$dir/$case"
    done
}

# A numeric PIN selects only the pre-v10 carrier formats, so on a v10 carrier
# it can only give the ordinary carrier message.
mismatch_carrier() {
    local tag="$1" option="$2"
    local dir="$WORK/mismatch_carrier_$tag" image
    mkdir -p "$dir/recover"
    (cd "$dir" && "$IN_BIN" "$option" "$COVER" "$PAYLOAD" > conceal.log 2>&1)
    image="$(extract_embedded_image "$dir/conceal.log")"
    [[ -n "$image" && -f "$dir/$image" ]] || { cat "$dir/conceal.log" >&2; return 1; }
    cp "$dir/$image" "$dir/recover/embedded.jpg"
    printf '%s\n' 15753985819510608748 > "$dir/recover/pin.txt"
    if (cd "$dir/recover" && "$OUT_BIN" embedded.jpg pin.txt > recover.log 2>&1); then
        echo "a numeric PIN recovered a v10 $tag carrier" >&2
        return 1
    fi
    grep -Fq 'File Extraction Error: Invalid KEY/PIN, or this is not a valid jdvrif "file-embedded" image.' \
        "$dir/recover/recover.log"
    assert_no_recovered_payload "$dir/recover"
}
test_mismatch_carrier_reddit() { mismatch_carrier reddit -r; }
test_mismatch_carrier_twitter() { mismatch_carrier twitter -x; }

test_pin_codec_vectors() {
    local dir="$WORK/pin_codec"
    mkdir -p "$dir"
    "${CXX:-g++}" -std=c++23 -Wall -Wextra -I"$ROOT" \
        "$TESTS/test_pin_codec.cpp" "$ROOT/pin_codec.cpp" -lsodium -o "$dir/test_pin_codec"
    "$dir/test_pin_codec"
}

test_carrier_prf() {
    local dir="$WORK/carrier_prf"
    mkdir -p "$dir"
    "${CXX:-g++}" -std=c++23 -Wall -Wextra -Wconversion -I"$ROOT" \
        "$TESTS/test_carrier_prf.cpp" -lsodium -o "$dir/test_carrier_prf"
    "$dir/test_carrier_prf"
}

test_carrier_key128() {
    local dir="$WORK/carrier_key128"
    mkdir -p "$dir"
    "${CXX:-g++}" -std=c++23 -O2 -Wall -Wextra -I"$ROOT" \
        "$TESTS/test_carrier_key128.cpp" \
        "$ROOT/encryption_kdf.cpp" \
        "$ROOT/binary_io.cpp" \
        "$ROOT/file_utils.cpp" \
        "$ROOT/signal_utils.cpp" \
        -lsodium -o "$dir/test_carrier_key128"
    "$dir/test_carrier_key128"
}

test_reddit_carrier() {
    local dir="$WORK/reddit_carrier"
    mkdir -p "$dir"
    "${CXX:-g++}" -std=c++23 -O2 -DNDEBUG \
        -Wall -Wextra -Wpedantic -Wshadow -Wconversion \
        -I"$ROOT" \
        "$TESTS/test_reddit_carrier.cpp" \
        "$ROOT/reddit_steg.cpp" \
        "$ROOT/signal_utils.cpp" \
        "$ROOT/encryption_kdf.cpp" \
        "$ROOT/binary_io.cpp" \
        "$ROOT/file_utils.cpp" \
        -ljpeg -lsodium -o "$dir/test_reddit_carrier"
    "$dir/test_reddit_carrier" "$COVER" "$PAYLOAD" \
        "$FIXTURES/legacy_v9_1/reddit.jpg" "$FIXTURES/legacy_v9_1/reddit.pin"
}

test_jpeg_safety() {
    bash "$TESTS/run_jpeg_safety_tests.sh"
}

test_opened_read_limits() {
    bash "$TESTS/run_read_limit_tests.sh"
}

PASS=0
FAIL=0
SKIP=0
run_test() {
    local name="$1"
    shift
    local rc
    # The test body runs in a subshell that is NOT itself a condition, so its
    # errexit stays armed: a bare assertion (grep -q, cmp -s, [[ ... ]]) that
    # fails aborts the test instead of being silently ignored. `if (set -e;
    # "$@")` would put the function in a condition context, where bash disables
    # errexit for the whole call -- which made every such assertion a no-op.
    set +e
    ( set -euo pipefail; "$@" )
    rc=$?
    set -e
    if [[ "$rc" -eq 0 ]]; then
        echo "[PASS] $name"
        PASS=$((PASS + 1))
    else
        if [[ "$rc" -eq 77 ]]; then
            echo "[SKIP] $name"
            SKIP=$((SKIP + 1))
        else
            echo "[FAIL] $name" >&2
            FAIL=$((FAIL + 1))
        fi
    fi
}

run_test authenticated_compression_mode test_authenticated_compression_mode
run_test legacy_recovery_warning test_legacy_recovery_warning
run_test inflater_plaintext_wipe test_inflater_wipes_plaintext
run_test deflate_state_wipe test_deflater_wipes_plaintext
run_test input_readers_wipe test_input_readers_leave_no_plaintext
run_test base64_strictness test_base64_wrapper_strictness
run_test copy_fallback_wipe test_copy_fallback_wipes_plaintext
run_test publish_fallback_atomic test_publish_fallback_is_atomic
run_test jpeg_scan_limits_cancellation_cleanup test_jpeg_safety
run_test opened_read_limits_and_replacement test_opened_read_limits
run_test kdf_cost_bounds test_kdf_cost_bounds
run_test wrong_pin_no_plaintext test_wrong_pin_leaves_no_plaintext
run_test wrong_pin_no_ciphertext_staging test_wrong_pin_stages_no_ciphertext
run_test oversized_pin_file test_oversized_pin_file_rejected
run_test truncated_ciphertext test_truncated_ciphertext
run_test nondefault_icc_offset_rejected test_nondefault_icc_offset_rejected
run_test transactional_pin_delivery test_pin_delivery_failure_is_transactional
run_test "image is committed under its final name before the PIN is shown" test_image_committed_before_pin
run_test bluesky_final_output_size_limit test_bluesky_final_output_size_limit
run_test oversized_jpeg_dimensions test_oversized_jpeg_dimensions
run_test default_dimension_limit test_default_dimension_limit
run_test cmyk_cover_rejected test_cmyk_cover_rejected
run_test post_transform_dimensions test_post_transform_dimensions
run_test mode_specific_quality_limit test_referenced_nonzero_dqt_quality
run_test dangling_symlink_collision test_dangling_symlink_collision
run_test default_recovery_wiggle_room test_default_recovery_wiggle_room
run_test compression_stage_anonymous_sigterm test_signal_cleans_compression_stage
run_test pin_codec_vectors test_pin_codec_vectors
run_test carrier_prf test_carrier_prf
run_test carrier_key128 test_carrier_key128
run_test reddit_carrier_rqsteg3 test_reddit_carrier
run_test pinfile_printed_grouped test_pinfile_printed_grouped
run_test pinfile_display test_pinfile_display
run_test pinfile_crlf test_pinfile_crlf
run_test pinfile_raw16 test_pinfile_raw16
run_test pinfile_bom test_pinfile_bom
run_test pinfile_typo test_pinfile_typo
run_test pinfile_legacy test_pinfile_legacy
run_test pinfile_raw8_legacy test_pinfile_raw8_legacy
run_test pinfile_raw16_zero test_pinfile_raw16_zero
run_test pinfile_raw8_zero test_pinfile_raw8_zero
run_test pinfile_text16_typo test_pinfile_text16_typo
run_test pinfile_word_matches_image test_pinfile_word_matches_image
run_test mismatch_legacy_on_v10 test_mismatch_legacy_on_v10
run_test mismatch_v10_on_legacy test_mismatch_v10_on_legacy
run_test mismatch_carrier_reddit test_mismatch_carrier_reddit
run_test mismatch_carrier_twitter test_mismatch_carrier_twitter

echo
echo "Security smoke summary: PASS=$PASS FAIL=$FAIL SKIP=$SKIP"
echo "jdv_in:  $IN_BIN"
echo "jdv_out: $OUT_BIN"
[[ "$FAIL" -eq 0 ]]
