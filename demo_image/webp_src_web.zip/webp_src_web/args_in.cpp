#include "args_in.h"

#include <format>
#include <stdexcept>
#include <string_view>

void ProgramArgs::die(const std::string &usage) {
  throw std::runtime_error(usage);
}

namespace {
[[nodiscard]] std::string programName(int argc, char **argv) {
  if (argc >= 1 && argv != nullptr && argv[0] != nullptr) {
    return fs::path(argv[0]).filename().string();
  }
  return "wpdv_in";
}

[[nodiscard]] std::string buildUsage(std::string_view prog) {
  return std::format("Usage: {} [-b] <cover_image> <secret_file>", prog);
}

[[nodiscard]] const char *requireArg(int argc, char **argv, int index,
                                     const std::string &usage) {
  if (argv == nullptr || index < 0 || index >= argc || argv[index] == nullptr) {
    ProgramArgs::die(usage);
  }
  return argv[index];
}
} // namespace

ProgramArgs ProgramArgs::parse(int argc, char **argv) {
  const std::string usage = buildUsage(programName(argc, argv));

  ProgramArgs out{};
  int i = 1;

  if (i < argc && std::string_view(requireArg(argc, argv, i, usage)) == "-b") {
    out.option = Option::Bluesky;
    ++i;
  }

  if (i + 2 != argc ||
      std::string_view(requireArg(argc, argv, i, usage)).empty() ||
      std::string_view(requireArg(argc, argv, i + 1, usage)).empty()) {
    die(usage);
  }

  out.image_file_path = requireArg(argc, argv, i, usage);
  out.data_file_path = requireArg(argc, argv, i + 1, usage);
  return out;
}
