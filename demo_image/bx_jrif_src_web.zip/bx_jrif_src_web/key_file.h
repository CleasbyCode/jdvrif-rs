#pragma once

#include "common.h"

// Web variant only. jdv_out takes the recovery KEY from a file named on its
// command line rather than from the terminal: main registers the file's bytes
// here, and getRecoveryKey() (key_input.h) parses them, wiping them as it does. The
// buffer must outlive the recovery.
void setKeyFile(vBytes& key_file_bytes) noexcept;
