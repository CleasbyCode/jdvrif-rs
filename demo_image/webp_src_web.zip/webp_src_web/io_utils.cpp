#include "io_utils.h"
#include <algorithm>
#include <cctype>
#include <cerrno>
#include <cstring>
#include <fcntl.h>
#include <format>
#include <iostream>
#include <linux/fs.h>
#include <print>
#include <ranges>
#include <stdexcept>
#include <string>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <system_error>
#include <unistd.h>
#include <utility>
namespace {

struct ScopedFd {
  int fd{-1};

  explicit ScopedFd(int file_descriptor) noexcept : fd(file_descriptor) {}
  ~ScopedFd() { closeNoThrow(); }

  ScopedFd(const ScopedFd &) = delete;
  ScopedFd &operator=(const ScopedFd &) = delete;

  [[nodiscard]] int get() const noexcept { return fd; }
  void closeNoThrow() noexcept { closeFdNoThrow(fd); }
};

[[nodiscard]] bool isImageType(FileTypeCheck file_type) {
  return file_type == FileTypeCheck::cover_image ||
         file_type == FileTypeCheck::embedded_image;
}

[[nodiscard]] std::size_t safeFileSize(const fs::path &path) {
  std::error_code ec;
  const std::uintmax_t raw_file_size = fs::file_size(path, ec);
  if (ec) {
    throw std::runtime_error(std::format(
        "Error: Failed to get file size for \"{}\".", path.string()));
  }
  if (raw_file_size >
      static_cast<std::uintmax_t>(std::numeric_limits<std::size_t>::max())) {
    throw std::runtime_error("Error: File is too large for this build.");
  }
  return static_cast<std::size_t>(raw_file_size);
}

// Best-effort durability of the directory entry. Returns an empty string on
// success, or a reason if the directory could not be opened or synced.
[[nodiscard]] std::string trySyncParentDirectory(const fs::path &file_path) {
  fs::path dir = file_path.parent_path();
  if (dir.empty()) {
    dir = ".";
  }

  int opened_fd = -1;
  do {
    opened_fd = ::open(dir.c_str(), O_RDONLY | O_DIRECTORY | O_CLOEXEC);
  } while (opened_fd < 0 && errno == EINTR);
  ScopedFd dir_fd(opened_fd);
  if (dir_fd.get() < 0) {
    const std::error_code ec(errno, std::generic_category());
    return std::format("failed to open output directory for sync: {}",
                       ec.message());
  }
  int sync_rc = -1;
  do {
    sync_rc = ::fsync(dir_fd.get());
  } while (sync_rc != 0 && errno == EINTR);
  if (sync_rc != 0) {
    const std::error_code ec(errno, std::generic_category());
    return std::format("failed to sync output directory: {}", ec.message());
  }
  return {};
}

// Six-digit random name under `directory`. O_EXCL / RENAME_NOREPLACE is what
// makes the name safe; the randomness only keeps collisions rare.
[[nodiscard]] fs::path randomCandidatePath(const fs::path &directory,
                                           std::string_view prefix,
                                           std::string_view suffix) {
  const fs::path name = std::format(
      "{}{}{}", prefix, 100000 + randombytes_uniform(900000), suffix);
  return directory.empty() ? name : (directory / name);
}

enum class RenameNoReplaceResult : Byte { committed, exists };

[[nodiscard]] RenameNoReplaceResult
renameNoReplace(const fs::path &staged_path, const fs::path &output_path,
                std::string_view failure_error_prefix) {
  const long rename_rc =
      ::syscall(SYS_renameat2, AT_FDCWD, staged_path.c_str(), AT_FDCWD,
                output_path.c_str(), RENAME_NOREPLACE);
  if (rename_rc == 0) {
    // renameat2 is the commit. A later directory-sync failure cannot roll the
    // rename back; unlinking would destroy the only complete copy. Warn and
    // still report success so callers print the path/PIN.
    if (const std::string sync_error = trySyncParentDirectory(output_path);
        !sync_error.empty()) {
      std::println(std::cerr,
                   "Warning: Output file was committed, but {}.", sync_error);
    }
    return RenameNoReplaceResult::committed;
  }
  if (errno == EEXIST) {
    return RenameNoReplaceResult::exists;
  }
  if (errno == ENOSYS || errno == EINVAL) {
    throw std::runtime_error(
        std::format("{}renameat2(RENAME_NOREPLACE) is unavailable on this "
                    "kernel/filesystem",
                    failure_error_prefix));
  }
  const std::error_code ec(errno, std::generic_category());
  throw std::runtime_error(
      std::format("{}{}", failure_error_prefix, ec.message()));
}
} // namespace

namespace {
// Blacklist: path separators, the Windows-reserved set, control bytes and DEL.
// Everything else (spaces, '+', '#', non-ASCII bytes >= 0x80, ...) is allowed,
// matching the jdvrif family so the implementations accept/reject the same
// embedded filenames and stay mutually recoverable.
[[nodiscard]] bool isValidFilenameChar(unsigned char c) {
  switch (c) {
  case '/':
  case '\\':
  case ':':
  case '*':
  case '?':
  case '"':
  case '<':
  case '>':
  case '|':
    return false;
  default:
    return c >= 0x20 && c != 0x7F;
  }
}

} // namespace

bool hasValidFilename(const fs::path &p) {
  const std::string fn = p.filename().string();
  return !fn.empty() && std::ranges::all_of(fn, isValidFilenameChar);
}

const char *embeddedFilenameProblem(const fs::path &p) {
  const std::string fn = p.filename().string();
  if (fn.empty()) {
    return "the name is empty";
  }
  if (!std::ranges::all_of(fn, isValidFilenameChar)) {
    return "it contains one of / \\ : * ? \" < > | or a control character";
  }
  if (fn == "." || fn == "..") {
    return "\".\" and \"..\" are reserved names";
  }
  if (fn.front() == '.') {
    return "it begins with '.'";
  }
  if (fn.front() == '-') {
    return "it begins with '-'";
  }
  if (fn.back() == ' ') {
    return "it ends with a space";
  }
  if (fn.back() == '.') {
    return "it ends with '.'";
  }
  return nullptr;
}

bool hasSafeEmbeddedFilename(const fs::path &p) {
  return embeddedFilenameProblem(p) == nullptr;
}

bool hasFileExtension(const fs::path &p,
                      std::initializer_list<std::string_view> exts) {
  auto e = p.extension().string();
  std::ranges::transform(e, e.begin(), [](unsigned char c) {
    return static_cast<char>(std::tolower(c));
  });
  return std::ranges::any_of(exts,
                             [&e](std::string_view ext) { return e == ext; });
}

void appendBytes(vBytes &out, std::span<const Byte> bytes,
                 std::string_view message) {
  if (bytes.empty()) {
    return;
  }
  const std::size_t base = out.size();
  const std::size_t final_size = checkedAddSize(base, bytes.size(), message);
  out.resize(final_size);
  std::memcpy(out.data() + static_cast<std::ptrdiff_t>(base), bytes.data(),
              bytes.size());
}

std::size_t getFileSizeChecked(const fs::path &path, FileTypeCheck file_type) {
  if (!hasValidFilename(path)) {
    throw std::runtime_error(
        "Invalid Input Error: Unsupported characters in filename arguments.");
  }
  std::error_code ec;
  const auto status = fs::status(path, ec);
  if (ec || !fs::is_regular_file(status)) {
    throw std::runtime_error(std::format(
        "Error: File \"{}\" not found or not a regular file.", path.string()));
  }
  const std::size_t file_size = safeFileSize(path);
  if (!file_size) {
    throw std::runtime_error("Error: File is empty.");
  }
  if (isImageType(file_type)) {
    if (!hasFileExtension(path, {".webp"})) {
      throw std::runtime_error("File Type Error: Invalid image extension. Only "
                               "expecting \".webp\".");
    }
    if (file_type == FileTypeCheck::cover_image) {
      if (MIN_WEBP_FILE_SIZE > file_size) {
        throw std::runtime_error("File Error: Invalid image file size.");
      }
      if (file_size > MAX_COVER_IMAGE_FILE_SIZE) {
        throw std::runtime_error(
            "Image File Error: Cover image file exceeds maximum size limit.");
      }
    }
  } else if (file_type == FileTypeCheck::pin_file) {
    if (!hasFileExtension(path, {".txt"})) {
      throw std::runtime_error(
          "PIN File Type Error: Invalid extension. Only expecting \".txt\".");
    }
    if (file_size != sizeof(std::uint64_t)) {
      throw std::runtime_error("PIN File Error: Invalid file size.");
    }
  }
  if (file_size > MAX_PROGRAM_FILE_SIZE) {
    throw std::runtime_error("Error: File exceeds program size limit.");
  }
  return file_size;
}

vBytes readFile(const fs::path &path, FileTypeCheck file_type) {
  const std::size_t file_size = getFileSizeChecked(path, file_type);
  // Deliberately no O_NOFOLLOW: this path was named by the user on the command
  // line, so a symlink to their cover image or payload is the intended target,
  // exactly as getFileSizeChecked's fs::status already resolves it.  What the
  // open must not trust is that the resolved file is still the one that was
  // stat'd, and the fstat below re-establishes that on the fd itself.  Output
  // files, which this tool creates rather than resolves, do keep O_NOFOLLOW.
  ScopedFd fd(::open(path.c_str(), O_RDONLY | O_CLOEXEC));
  if (fd.get() < 0) {
    const std::error_code ec(errno, std::generic_category());
    throw std::runtime_error(std::format("Failed to open file: {} ({})",
                                         path.string(), ec.message()));
  }
  struct stat st{};
  if (::fstat(fd.get(), &st) != 0 || !S_ISREG(st.st_mode) ||
      static_cast<std::uintmax_t>(st.st_size) != file_size) {
    throw std::runtime_error(
        std::format("Failed to read file: {} (stat mismatch)", path.string()));
  }
  vBytes vec(file_size);
  // Wipe on every exit except a successful return so a failed payload read
  // does not leave plaintext residue on the heap.
  SensitiveBytesGuard wipe_guard(vec);

  std::size_t read_total = 0;
  while (read_total < file_size) {
    const std::size_t remaining = file_size - read_total;
    const std::size_t chunk = std::min<std::size_t>(
        remaining,
        static_cast<std::size_t>(std::numeric_limits<ssize_t>::max()));
    const ssize_t rc = ::read(fd.get(), vec.data() + read_total, chunk);
    if (rc < 0) {
      if (errno == EINTR) {
        continue;
      }
      const std::error_code ec(errno, std::generic_category());
      throw std::runtime_error(std::format("Failed to read file: {} ({})",
                                           path.string(), ec.message()));
    }
    if (rc == 0) {
      throw std::runtime_error("Failed to read full file: partial read");
    }
    read_total += static_cast<std::size_t>(rc);
  }
  Byte trailing{};
  while (true) {
    const ssize_t rc = ::read(fd.get(), &trailing, 1);
    if (rc < 0) {
      if (errno == EINTR) {
        continue;
      }
      const std::error_code ec(errno, std::generic_category());
      throw std::runtime_error(std::format("Failed to read file: {} ({})",
                                           path.string(), ec.message()));
    }
    if (rc != 0) {
      throw std::runtime_error(
          std::format("Failed to read file: {} (stat mismatch)", path.string()));
    }
    break;
  }
  fd.closeNoThrow();
  wipe_guard.release();
  return vec;
}

void closeFdNoThrow(int &fd) noexcept {
  if (fd < 0) {
    return;
  }
  ::close(fd);
  fd = -1;
}

void closeFdOrThrow(int &fd) {
  if (fd < 0) {
    return;
  }
  const int rc = ::close(fd);
  const int saved_errno = errno;
  fd = -1;
  if (rc == 0 || saved_errno == EINTR) {
    return;
  }
  const std::error_code ec(saved_errno, std::generic_category());
  throw std::runtime_error(std::format(
      "Write Error: Failed to finalize output file: {}", ec.message()));
}

void writeAllToFd(int fd, std::span<const Byte> data) {
  std::size_t written = 0;
  while (written < data.size()) {
    const std::size_t remaining = data.size() - written;
    const std::size_t chunk_size = std::min<std::size_t>(
        remaining,
        static_cast<std::size_t>(std::numeric_limits<ssize_t>::max()));
    const ssize_t rc = ::write(
        fd, data.data() + static_cast<std::ptrdiff_t>(written), chunk_size);
    if (rc < 0) {
      if (errno == EINTR) {
        continue;
      }
      const std::error_code ec(errno, std::generic_category());
      throw std::runtime_error(
          std::format("Write Error: Failed to write complete output file: {}",
                      ec.message()));
    }
    if (rc == 0) {
      throw std::runtime_error(
          "Write Error: Failed to write complete output file.");
    }
    written += static_cast<std::size_t>(rc);
  }
}

void syncFdOrThrow(int fd, std::string_view error_prefix) {
  int rc = -1;
  do {
    rc = ::fdatasync(fd);
  } while (rc != 0 && errno == EINTR);
  if (rc != 0) {
    const std::error_code ec(errno, std::generic_category());
    throw std::runtime_error(std::format("{}{}", error_prefix, ec.message()));
  }
}

UniqueFileHandle::UniqueFileHandle(fs::path path,
                                   int file_descriptor) noexcept
    : path_(std::move(path)), fd_(file_descriptor) {}

UniqueFileHandle::~UniqueFileHandle() { reset(); }

UniqueFileHandle::UniqueFileHandle(UniqueFileHandle &&other) noexcept
    : path_(std::move(other.path_)), fd_(other.fd_) {
  other.fd_ = -1;
  other.path_.clear();
}

UniqueFileHandle &
UniqueFileHandle::operator=(UniqueFileHandle &&other) noexcept {
  if (this != &other) {
    reset();
    path_ = std::move(other.path_);
    fd_ = other.fd_;
    other.fd_ = -1;
    other.path_.clear();
  }
  return *this;
}

void UniqueFileHandle::closeOrThrow() { closeFdOrThrow(fd_); }

void UniqueFileHandle::closeNoThrow() noexcept { closeFdNoThrow(fd_); }

void UniqueFileHandle::release() noexcept {
  closeNoThrow();
  path_.clear();
}

void UniqueFileHandle::reset() noexcept {
  closeNoThrow();
  if (!path_.empty()) {
    cleanupPathNoThrow(path_);
    path_.clear();
  }
}

UniqueFileHandle createUniqueFile(const fs::path &directory,
                                  std::string_view prefix,
                                  std::string_view suffix,
                                  std::size_t max_attempts,
                                  std::string_view create_error_prefix,
                                  std::string_view exhausted_error) {
  for (std::size_t i = 0; i < max_attempts; ++i) {
    const fs::path candidate = randomCandidatePath(directory, prefix, suffix);
    int flags = O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC;
#ifdef O_NOFOLLOW
    flags |= O_NOFOLLOW;
#endif
    const int fd = ::open(candidate.c_str(), flags, S_IRUSR | S_IWUSR);
    if (fd >= 0) {
      return UniqueFileHandle(candidate, fd);
    }
    if (errno == EEXIST) {
      continue;
    }
    const std::error_code ec(errno, std::generic_category());
    throw std::runtime_error(
        std::format("{}{}", create_error_prefix, ec.message()));
  }
  throw std::runtime_error(std::string(exhausted_error));
}

bool tryCommitPathAtomically(const fs::path &staged_path,
                             const fs::path &output_path,
                             std::string_view failure_error_prefix) {
  // Linux-only: renameat2(RENAME_NOREPLACE) never clobbers an existing target
  // and avoids the exists-then-rename TOCTOU window of portable fallbacks.
  return renameNoReplace(staged_path, output_path, failure_error_prefix) ==
         RenameNoReplaceResult::committed;
}

fs::path commitToUniquePathAtomically(
    const fs::path &staged_path, const fs::path &directory,
    std::string_view prefix, std::string_view suffix, std::size_t max_attempts,
    std::string_view failure_error_prefix, std::string_view exhausted_error) {
  for (std::size_t i = 0; i < max_attempts; ++i) {
    const fs::path candidate = randomCandidatePath(directory, prefix, suffix);
    if (renameNoReplace(staged_path, candidate, failure_error_prefix) ==
        RenameNoReplaceResult::committed) {
      return candidate;
    }
  }
  throw std::runtime_error(std::string(exhausted_error));
}

void cleanupPathNoThrow(const fs::path &path) noexcept {
  if (path.empty()) {
    return;
  }
  std::error_code ec;
  fs::remove(path, ec);
}
