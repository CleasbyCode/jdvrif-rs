#include "jpeg_utils.h"
#include "carrier_common.h"
#include "file_utils.h"
#include "signal_utils.h"

#include <turbojpeg.h>

#include <algorithm>
#include <bit>
#include <cstring>
#include <format>
#include <memory>
#include <numeric>
#include <optional>
#include <ranges>
#include <span>
#include <stdexcept>

void TjBufferDeleter::operator()(unsigned char* buffer) const noexcept {
    if (buffer) tjFree(buffer);
}

namespace {
struct TJHandle {
    TJHandle() = default;

    ~TJHandle() {
        reset();
    }

    TJHandle(const TJHandle&) = delete;
    TJHandle& operator=(const TJHandle&) = delete;

    TJHandle(TJHandle&& other) noexcept : handle_(other.handle_) {
        other.handle_ = nullptr;
    }

    TJHandle& operator=(TJHandle&& other) noexcept {
        if (this != &other) {
            reset();
            handle_ = other.handle_;
            other.handle_ = nullptr;
        }
        return *this;
    }

    [[nodiscard]] static TJHandle makeTransformer() {
        TJHandle h;
        h.handle_ = tjInitTransform();
        return h;
    }

    void reset() {
        if (handle_) {
            tjDestroy(handle_);
            handle_ = nullptr;
        }
    }

    [[nodiscard]] tjhandle get() const { return handle_; }
    explicit operator bool() const { return handle_ != nullptr; }

private:
    tjhandle handle_ = nullptr;
};

constexpr std::size_t
    EXIF_SEARCH_LIMIT        = 4096,
    EXIF_HEADER_SIZE         = 6,
    TIFF_HEADER_SIZE         = 8,
    IFD_ENTRY_SIZE           = 12,
    DQT_SEARCH_LIMIT         = 32768,
    DQT_8BIT_TABLE_SIZE      = 64,
    DQT_16BIT_TABLE_SIZE     = 128;

constexpr int MIN_IMAGE_DIMENSION = 400;

constexpr uint16_t TAG_ORIENTATION = 0x0112;

constexpr auto EXIF_SIG = std::to_array<Byte>({'E', 'x', 'i', 'f', '\0', '\0'});

[[nodiscard]] constexpr bool markerHasNoLength(Byte marker) noexcept {
    return marker == 0x01 || marker == 0xD8 || marker == 0xD9 || (marker >= 0xD0 && marker <= 0xD7);
}

[[nodiscard]] constexpr bool isSofMarker(Byte marker) noexcept {
    // SOF0..SOF15 minus DHT(0xC4), JPG(0xC8), DAC(0xCC)
    return marker >= 0xC0 && marker <= 0xCF
        && marker != 0xC4 && marker != 0xC8 && marker != 0xCC;
}

[[nodiscard]] std::optional<std::size_t> jpegSegmentEndFromLengthOffset(std::span<const Byte> jpg, std::size_t length_offset) {
    if (!spanHasRange(jpg, length_offset, 2)) return std::nullopt;

    const std::size_t segment_length =
        (static_cast<std::size_t>(jpg[length_offset]) << 8) |
        static_cast<std::size_t>(jpg[length_offset + 1]);
    if (segment_length < 2 || !spanHasRange(jpg, length_offset, segment_length)) return std::nullopt;
    return length_offset + segment_length;
}

struct TiffReader {
    std::span<const Byte> tiff{};
    bool is_little_endian{false};

    // TIFF fields are stored in the byte order the header declares, so swap only
    // when that disagrees with the host.
    template<typename T>
    [[nodiscard]] std::optional<T> read(std::size_t offset) const {
        if (!spanHasRange(tiff, offset, sizeof(T))) return std::nullopt;
        T value;
        std::memcpy(&value, tiff.data() + offset, sizeof(value));
        const bool needs_swap = is_little_endian != (std::endian::native == std::endian::little);
        return needs_swap ? std::byteswap(value) : value;
    }

    [[nodiscard]] std::optional<uint16_t> read16(std::size_t offset) const { return read<uint16_t>(offset); }
    [[nodiscard]] std::optional<uint32_t> read32(std::size_t offset) const { return read<uint32_t>(offset); }
};

[[nodiscard]] std::optional<TiffReader> makeTiffReader(std::span<const Byte> tiff) {
    if (tiff.size() < TIFF_HEADER_SIZE) return std::nullopt;

    bool is_le;
    if (tiff[0] == 'I' && tiff[1] == 'I') is_le = true;
    else if (tiff[0] == 'M' && tiff[1] == 'M') is_le = false;
    else return std::nullopt;
    return TiffReader{tiff, is_le};
}

[[nodiscard]] std::optional<uint16_t> exifOrientationFromTiff(std::span<const Byte> tiff) {
    const auto reader_opt = makeTiffReader(tiff);
    if (!reader_opt) return std::nullopt;
    const TiffReader reader = *reader_opt;

    const auto magic = reader.read16(2);
    if (!magic || *magic != 0x002A) return std::nullopt;

    const auto ifd_offset_opt = reader.read32(4);
    if (!ifd_offset_opt || !spanHasRange(tiff, *ifd_offset_opt, 2)) return std::nullopt;

    const std::size_t ifd_offset = *ifd_offset_opt;
    const auto entry_count_opt = reader.read16(ifd_offset);
    if (!entry_count_opt) return std::nullopt;

    std::size_t entry_pos = ifd_offset + 2;
    for (uint16_t i = 0; i < *entry_count_opt; ++i) {
        if (!spanHasRange(tiff, entry_pos, IFD_ENTRY_SIZE)) return std::nullopt;

        const auto tag_id = reader.read16(entry_pos);
        if (!tag_id) return std::nullopt;

        if (*tag_id == TAG_ORIENTATION) return reader.read16(entry_pos + 8);
        entry_pos += IFD_ENTRY_SIZE;
    }
    return std::nullopt;
}

// Single-pass prescan of the *input* JPEG: extract SOF dimensions and EXIF
// orientation in one marker walk. Replaces tjDecompressHeader3 plus the
// separate exifPayload/exifOrientation passes (each of which previously
// re-walked the same bytes).
struct JpegPrescan {
    int                     width      = 0;
    int                     height     = 0;
    int                     components = 0;
    std::optional<uint16_t> orientation;
};

[[nodiscard]] std::optional<JpegPrescan> jpegPrescan(std::span<const Byte> jpg) {
    if (jpg.size() < 4 || jpg[0] != 0xFF || jpg[1] != 0xD8) return std::nullopt;

    JpegPrescan out;
    std::size_t pos = 2;
    const std::size_t exif_limit = std::min(jpg.size(), EXIF_SEARCH_LIMIT);

    while (pos + 4 <= jpg.size()) {
        while (pos < jpg.size() && jpg[pos] == 0xFF) ++pos;
        if (pos >= jpg.size()) break;

        const Byte marker = jpg[pos++];
        if (marker == 0x00 || markerHasNoLength(marker)) continue;
        if (marker == 0xDA) break;  // SOS: scan data follows, stop walking.

        const auto end_opt = jpegSegmentEndFromLengthOffset(jpg, pos);
        if (!end_opt) return std::nullopt;
        const std::size_t payload_off  = pos + 2;
        const std::size_t payload_size = *end_opt - payload_off;

        if (isSofMarker(marker) && payload_size >= 6 && out.width == 0) {
            const int components = static_cast<int>(jpg[payload_off + 5]);
            const std::size_t component_bytes = static_cast<std::size_t>(components) * 3;
            if (components == 0 || component_bytes > payload_size - 6) return std::nullopt;
            out.height = (static_cast<int>(jpg[payload_off + 1]) << 8) | jpg[payload_off + 2];
            out.width  = (static_cast<int>(jpg[payload_off + 3]) << 8) | jpg[payload_off + 4];
            out.components = components;
        } else if (marker == 0xE1 && pos <= exif_limit &&
                   payload_size >= EXIF_HEADER_SIZE &&
                   std::ranges::equal(jpg.subspan(payload_off, EXIF_HEADER_SIZE), EXIF_SIG)) {
            out.orientation = exifOrientationFromTiff(
                jpg.subspan(payload_off + EXIF_HEADER_SIZE,
                            payload_size - EXIF_HEADER_SIZE));
        }

        if (out.width != 0 && out.orientation.has_value()) break;

        pos = *end_opt;
    }
    return out;
}

// Single-pass scan of the *transformed* JPEG: locate the first DQT marker
// (used as the trim offset), read the transformed dimensions, and estimate
// quality from the quantization table actually selected by the first SOF
// component. JPEG quantization table IDs are not required to start at zero.
struct TransformedJpegInfo {
    std::size_t offset  = 0;
    int         width   = 0;
    int         height  = 0;
    std::optional<int> quality;
};

[[nodiscard]] TransformedJpegInfo inspectTransformedJpeg(std::span<const Byte> jpg) {
    TransformedJpegInfo out;
    if (jpg.size() < 4 || jpg[0] != 0xFF || jpg[1] != 0xD8) return out;

    std::array<std::optional<int>, 4> table_qualities{};
    std::optional<Byte> primary_table_id;

    std::size_t pos = 2;
    while (pos + 2 <= jpg.size()) {
        while (pos < jpg.size() && jpg[pos] == 0xFF) ++pos;
        if (pos >= jpg.size()) break;

        const Byte marker = jpg[pos++];
        const std::size_t marker_offset = pos - 2;
        if (marker == 0x00 || markerHasNoLength(marker)) continue;
        if (marker == 0xDA) break;

        const auto end_opt = jpegSegmentEndFromLengthOffset(jpg, pos);
        if (!end_opt) return {};
        const std::size_t payload_off  = pos + 2;
        const std::size_t payload_size = *end_opt - payload_off;

        if (marker == 0xDB) {
            if (out.offset == 0 &&
                marker_offset <= DQT_SEARCH_LIMIT - 2) {
                out.offset = marker_offset;
            }

            std::size_t tp = payload_off;
            while (tp < *end_opt) {
                const Byte header    = jpg[tp++];
                const Byte precision = (header >> 4) & 0x0F;
                const Byte table_id  = header & 0x0F;
                if (precision > 1 || table_id >= table_qualities.size()) return {};

                const std::size_t table_size = (precision == 0)
                    ? DQT_8BIT_TABLE_SIZE : DQT_16BIT_TABLE_SIZE;
                if (!spanHasRange(jpg, tp, table_size) || tp + table_size > *end_opt) return {};

                int sum = 0;
                if (precision == 0) {
                    // C++23: std::ranges::fold_left lowers cleanly to vpsadbw under
                    // AVX2; the explicit invariant lets GCC drop bounds checks.
                    const bool table_in_range =
                        jpg.size() >= DQT_8BIT_TABLE_SIZE &&
                        tp <= jpg.size() - DQT_8BIT_TABLE_SIZE;
                    // Guaranteed by the spanHasRange/end_opt check above; [[assume]] would be UB without it.
                    [[assume(table_in_range)]];
                    sum = std::ranges::fold_left(
                        jpg.subspan(tp, DQT_8BIT_TABLE_SIZE),
                        0,
                        [](int acc, Byte b) { return acc + static_cast<int>(b); });
                } else {
                    const bool table_in_range =
                        jpg.size() >= DQT_16BIT_TABLE_SIZE &&
                        tp <= jpg.size() - DQT_16BIT_TABLE_SIZE;
                    // Guaranteed by the spanHasRange/end_opt check above; [[assume]] would be UB without it.
                    [[assume(table_in_range)]];
                    for (std::size_t i = 0; i < 64; ++i) {
                        sum += (static_cast<int>(jpg[tp + i * 2]) << 8) |
                               jpg[tp + i * 2 + 1];
                    }
                }
                // Same estimator the X-Twitter carrier uses, so the two can never
                // disagree about whether a table is above Q97.
                table_qualities[table_id] =
                    carrier_common::estimateQualityFromLumaSum(static_cast<std::uint64_t>(sum));
                tp += table_size;
            }
        } else if (isSofMarker(marker)) {
            if (payload_size < 9) return {};
            const std::size_t components = jpg[payload_off + 5];
            if (components == 0 || components > (payload_size - 6) / 3) return {};

            out.height = (static_cast<int>(jpg[payload_off + 1]) << 8) |
                         jpg[payload_off + 2];
            out.width  = (static_cast<int>(jpg[payload_off + 3]) << 8) |
                         jpg[payload_off + 4];
            primary_table_id = jpg[payload_off + 8];
        }

        pos = *end_opt;
    }

    if (primary_table_id && *primary_table_id < table_qualities.size()) {
        out.quality = table_qualities[*primary_table_id];
    }
    return out;
}

[[nodiscard]] int getTransformOp(uint16_t orientation) {
    switch (orientation) {
        case 2: return TJXOP_HFLIP;
        case 3: return TJXOP_ROT180;
        case 4: return TJXOP_VFLIP;
        case 5: return TJXOP_TRANSPOSE;
        case 6: return TJXOP_ROT90;
        case 7: return TJXOP_TRANSVERSE;
        case 8: return TJXOP_ROT270;
        default: return TJXOP_NONE;
    }
}

} // namespace

OptimizedCover optimizeImage(
    std::span<const Byte> input,
    bool isProgressive,
    bool enforceQualityLimit,
    CoverImageLimits limits) {
    throwIfSignalCancellationRequested();
    throwIf(input.empty(), "JPG image is empty!");

    // Single header pass replaces tjDecompressHeader3 + exifOrientation,
    // each of which previously walked the input independently.
    const auto prescan = jpegPrescan(input);
    throwIf(!prescan || prescan->width == 0 || prescan->height == 0, "Image Error: Failed to parse JPEG header.");

    if (prescan->width < MIN_IMAGE_DIMENSION || prescan->height < MIN_IMAGE_DIMENSION) {
        throw std::runtime_error(std::format(
            "Image Error: Dimensions {}x{} are too small.\n"
            "For platform compatibility, cover image must be "
            "at least {}px for both width and height.",
            prescan->width, prescan->height, MIN_IMAGE_DIMENSION));
    }

    const std::uint64_t pixel_count =
        static_cast<std::uint64_t>(prescan->width) *
        static_cast<std::uint64_t>(prescan->height);
    if (static_cast<std::uint64_t>(prescan->width) > limits.max_dimension ||
        static_cast<std::uint64_t>(prescan->height) > limits.max_dimension ||
        pixel_count > limits.max_pixels) {
        throw std::runtime_error(std::format(
            "Image Error: Dimensions {}x{} exceed the safe cover-image limit "
            "({}px per dimension and {} total pixels).",
            prescan->width, prescan->height,
            limits.max_dimension, limits.max_pixels));
    }

    if (prescan->components != 1 && prescan->components != 3) {
        throw std::runtime_error(std::format(
            "Image Error: Unsupported JPEG color space ({} components). "
            "CMYK/YCCK cover images must be converted to RGB before use.",
            prescan->components));
    }

    auto transformer = TJHandle::makeTransformer();
    throwIf(!transformer, "tjInitTransform() failed");

    const int xop = prescan->orientation
        ? getTransformOp(*prescan->orientation)
        : static_cast<int>(TJXOP_NONE);

    tjtransform xform{};
    xform.op      = xop;
    xform.options = TJXOPT_COPYNONE | TJXOPT_TRIM;
    if (isProgressive) xform.options |= TJXOPT_PROGRESSIVE;

    unsigned char* raw_dst = nullptr;
    unsigned long dst_size = 0;

    // TurboJPEG owns its libjpeg progress monitor internally. Its scan limit
    // bounds malicious progressive inputs during this opaque transform call;
    // the raw-libjpeg carrier paths install their own cancellation monitors.
    const int transform_rc = tjTransform(
        transformer.get(),
        input.data(),
        static_cast<unsigned long>(input.size()),
        1,
        &raw_dst,
        &dst_size,
        &xform,
        TJFLAG_LIMITSCANS);
    // Adopt the buffer before checking the result: a failed transform can still
    // have allocated one, and this frees it on every exit path from here on.
    std::unique_ptr<unsigned char, TjBufferDeleter> dst_buf(raw_dst);

    if (transform_rc != 0) {
        throw std::runtime_error(std::format("tjTransform: {}", tjGetErrorStr2(transformer.get())));
    }
    throwIfSignalCancellationRequested();

    // Single tail pass replaces estimateImageQuality plus two caller-side
    // searchSig passes for DQT1_SIG / DQT2_SIG.
    constexpr int MAX_ALLOWED_QUALITY = 97;
    const std::span<const Byte> result(
        reinterpret_cast<const Byte*>(dst_buf.get()), static_cast<std::size_t>(dst_size));
    const TransformedJpegInfo transformed = inspectTransformedJpeg(result);

    throwIf(
        transformed.width == 0 || transformed.height == 0,
        "Image Error: Failed to parse transformed JPEG header.");
    if (transformed.width < MIN_IMAGE_DIMENSION ||
        transformed.height < MIN_IMAGE_DIMENSION) {
        throw std::runtime_error(std::format(
            "Image Error: Lossless orientation/MCU trimming reduced dimensions "
            "to {}x{}. Cover image must remain at least {}px for both width and height.",
            transformed.width, transformed.height, MIN_IMAGE_DIMENSION));
    }

    throwIf(
        !transformed.quality,
        "Image File Error: Quantization table referenced by JPEG components "
        "was not found (corrupt or unsupported JPG).");
    if (enforceQualityLimit && *transformed.quality > MAX_ALLOWED_QUALITY) {
        throw std::runtime_error(std::format(
            "Image Error: Estimated quality {} exceeds maximum ({}).\n"
            "For platform compatibility, cover image quality "
            "must be {} or lower.",
            *transformed.quality, MAX_ALLOWED_QUALITY, MAX_ALLOWED_QUALITY));
    }
    throwIf(
        transformed.offset == 0 || transformed.offset >= dst_size,
        "Image File Error: No DQT segment found (corrupt or unsupported JPG).");

    // Hand over the turbojpeg buffer itself; the leading markers before the
    // first DQT are skipped by the offset rather than copied away.
    return OptimizedCover(
        std::move(dst_buf),
        transformed.offset,
        static_cast<std::size_t>(dst_size) - transformed.offset);
}
