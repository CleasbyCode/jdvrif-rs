// JPG Data Vehicle (jdv_in) Created by Nicholas Cleasby (@CleasbyCode) 10/04/2023

#include "common.h"
#include "conceal.h"
#include "file_utils.h"
#include "program_args_in.h"
#include "signal_utils.h"

#include <iostream>
#include <print>
#include <stdexcept>

namespace {
[[nodiscard]] int run(int argc, char** argv) {
    throwIf(sodium_init() < 0, "Libsodium initialization failed!");
    auto args = ProgramArgs::parse(argc, argv);

    if (args.mode == Mode::capsize) {
        const FileTypeCheck cover_check = args.option == Option::Reddit
            ? FileTypeCheck::reddit_cover_image
            : FileTypeCheck::twitter_cover_image;
        vBytes jpg_vec = readFile(args.image_file_path, cover_check);
        if (args.option == Option::Reddit) {
            displayRedditCapacity(jpg_vec);
        } else {
            displayTwitterCapacity(jpg_vec);
        }
        return 0;
    }

    const FileTypeCheck cover_check = args.option == Option::Reddit
        ? FileTypeCheck::reddit_cover_image
        : args.option == Option::Twitter
            ? FileTypeCheck::twitter_cover_image
            : FileTypeCheck::cover_image;
    vBytes jpg_vec = readFile(args.image_file_path, cover_check);
    concealData(jpg_vec, args.option, args.data_file_path);
    return 0;
}
} // namespace

int main(int argc, char** argv) {
    try {
        installProcessSignalHandlers();
        return run(argc, argv);
    } catch (const SignalCancellation& interruption) {
        reraiseSignalAfterCleanup(interruption.signalNumber());
    } catch (const std::exception& e) {
        std::println(std::cerr, "\n{}\n", e.what());
        return 1;
    } catch (...) {
        std::println(std::cerr, "\nUnknown fatal error.\n");
        return 1;
    }
}
