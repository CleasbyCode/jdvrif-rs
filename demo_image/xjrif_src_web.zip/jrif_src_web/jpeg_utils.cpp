#include "jpeg_utils.h"
#include "binary_io.h"
#include "file_utils.h"

#include <algorithm>
#include <bit>
#include <cstring>
#include <format>
#include <stdexcept>

namespace {
constexpr std::size_t
    EXIF_SEARCH_LIMIT        = 4096,
    EXIF_HEADER_SIZE         = 6,
    TIFF_HEADER_SIZE         = 8,
    IFD_ENTRY_SIZE           = 12,
    DQT_SEARCH_LIMIT         = 32768,
    DQT_8BIT_TABLE_SIZE      = 64,
    DQT_16BIT_TABLE_SIZE     = 128,
    DEFAULT_QUALITY_ESTIMATE = 80;

constexpr uint16_t TAG_ORIENTATION = 0x0112;

constexpr auto APP1_SIG = std::to_array<Byte>({0xFF, 0xE1});
constexpr auto EXIF_SIG = std::to_array<Byte>({'E', 'x', 'i', 'f', '\0', '\0'});
constexpr auto DQT_SIG  = std::to_array<Byte>({0xFF, 0xDB});

[[nodiscard]] bool markerHasNoLength(Byte marker) {
    return marker == 0x01 || marker == 0xD8 || marker == 0xD9 || (marker >= 0xD0 && marker <= 0xD7);
}

[[nodiscard]] std::optional<std::size_t> jpegSegmentEndFromLengthOffset(std::span<const Byte> jpg, std::size_t length_offset) {
    if (!spanHasRange(jpg, length_offset, 2)) return std::nullopt;

    const std::size_t segment_length =
        (static_cast<std::size_t>(jpg[length_offset]) << 8) |
        static_cast<std::size_t>(jpg[length_offset + 1]);
    if (segment_length < 2 || !spanHasRange(jpg, length_offset, segment_length)) {
        return std::nullopt;
    }
    return length_offset + segment_length;
}

constexpr std::array<int, 101> STD_LUMINANCE_SUMS = {
    0,
    16320, 16315, 15946, 15277, 14655, 14073, 13623, 13230, 12859, 12560,
    12240, 11861, 11456, 11081, 10714, 10360, 10027, 9679,  9368,  9056,
    8680,  8331,  7995,  7668,  7376,  7084,  6823,  6562,  6345,  6125,
    5939,  5756,  5571,  5421,  5240,  5086,  4976,  4829,  4719,  4616,
    4463,  4393,  4280,  4166,  4092,  3980,  3909,  3835,  3755,  3688,
    3621,  3541,  3467,  3396,  3323,  3247,  3170,  3096,  3021,  2952,
    2874,  2804,  2727,  2657,  2583,  2509,  2437,  2362,  2290,  2211,
    2136,  2068,  1996,  1915,  1858,  1773,  1692,  1620,  1552,  1477,
    1398,  1326,  1251,  1179,  1109,  1031,  961,   884,   814,   736,
    667,   592,   518,   441,   369,   292,   221,   151,   86,    64
};

[[nodiscard]] std::optional<std::span<const Byte>> exifPayload(std::span<const Byte> jpg) {
    const std::size_t scan_limit = std::min(jpg.size(), EXIF_SEARCH_LIMIT);
    if (scan_limit < 4) return std::nullopt;

    std::size_t pos = 0;
    if (scan_limit >= 2 && jpg[0] == 0xFF && jpg[1] == 0xD8) pos = 2;

    while (pos + 4 <= jpg.size() && pos < scan_limit) {
        while (pos < scan_limit && jpg[pos] != 0xFF) ++pos;
        if (pos + 2 > scan_limit) break;

        while (pos < scan_limit && jpg[pos] == 0xFF) ++pos;
        if (pos >= scan_limit) break;

        const Byte marker = jpg[pos++];
        if (marker == 0x00 || markerHasNoLength(marker)) continue;
        if (marker == 0xDA) break;

        const auto segment_end_opt = jpegSegmentEndFromLengthOffset(jpg, pos);
        if (!segment_end_opt) return std::nullopt;

        const std::size_t payload_offset = pos + 2;
        const std::size_t payload_size = *segment_end_opt - payload_offset;

        if (marker == APP1_SIG[1] &&
            payload_size >= EXIF_HEADER_SIZE &&
            std::ranges::equal(jpg.subspan(payload_offset, EXIF_HEADER_SIZE), EXIF_SIG)) {
            return jpg.subspan(payload_offset, payload_size);
        }

        pos = *segment_end_opt;
    }
    return std::nullopt;
}

struct TiffReader {
    std::span<const Byte> tiff{};
    bool is_little_endian{false};

    [[nodiscard]] std::optional<uint16_t> read16(std::size_t offset) const {
        if (!spanHasRange(tiff, offset, 2)) return std::nullopt;
        uint16_t value;
        std::memcpy(&value, tiff.data() + offset, sizeof(value));
        const bool needs_swap = is_little_endian != (std::endian::native == std::endian::little);
        return needs_swap ? std::byteswap(value) : value;
    }

    [[nodiscard]] std::optional<uint32_t> read32(std::size_t offset) const {
        if (!spanHasRange(tiff, offset, 4)) return std::nullopt;
        uint32_t value;
        std::memcpy(&value, tiff.data() + offset, sizeof(value));
        const bool needs_swap = is_little_endian != (std::endian::native == std::endian::little);
        return needs_swap ? std::byteswap(value) : value;
    }
};

[[nodiscard]] std::optional<TiffReader> makeTiffReader(std::span<const Byte> tiff) {
    if (tiff.size() < TIFF_HEADER_SIZE) return std::nullopt;

    bool is_le;
    if (tiff[0] == 'I' && tiff[1] == 'I') is_le = true;
    else if (tiff[0] == 'M' && tiff[1] == 'M') is_le = false;
    else return std::nullopt;
    return TiffReader{tiff, is_le};
}

[[nodiscard]] std::optional<uint16_t> exifOrientationFromTiff(std::span<const Byte> tiff) {
    const auto reader_opt = makeTiffReader(tiff);
    if (!reader_opt) return std::nullopt;
    const TiffReader reader = *reader_opt;

    const auto magic = reader.read16(2);
    if (!magic || *magic != 0x002A) return std::nullopt;

    const auto ifd_offset_opt = reader.read32(4);
    if (!ifd_offset_opt || !spanHasRange(tiff, *ifd_offset_opt, 2)) return std::nullopt;

    const std::size_t ifd_offset = *ifd_offset_opt;
    const auto entry_count_opt = reader.read16(ifd_offset);
    if (!entry_count_opt) return std::nullopt;

    std::size_t entry_pos = ifd_offset + 2;
    for (uint16_t i = 0; i < *entry_count_opt; ++i) {
        if (!spanHasRange(tiff, entry_pos, IFD_ENTRY_SIZE)) return std::nullopt;

        const auto tag_id = reader.read16(entry_pos);
        if (!tag_id) return std::nullopt;

        if (*tag_id == TAG_ORIENTATION) {
            return reader.read16(entry_pos + 8);
        }
        entry_pos += IFD_ENTRY_SIZE;
    }
    return std::nullopt;
}

[[nodiscard]] int qualityFromLuminanceSum(int sum) {
    if (sum <= 64) return 100;
    if (sum >= 16320) return 1;

    for (std::size_t q = 1; q < STD_LUMINANCE_SUMS.size(); ++q) {
        if (sum >= STD_LUMINANCE_SUMS[q]) {
            if (q > 1) {
                const int diff_current = sum - STD_LUMINANCE_SUMS[q];
                const int diff_prev = STD_LUMINANCE_SUMS[q - 1] - sum;
                if (diff_prev < diff_current) return static_cast<int>(q - 1);
            }
            return static_cast<int>(q);
        }
    }
    return 100;
}
} // namespace

std::optional<uint16_t> exifOrientation(std::span<const Byte> jpg) {
    const auto payload_opt = exifPayload(jpg);
    if (!payload_opt) return std::nullopt;
    const std::span<const Byte> payload = *payload_opt;
    if (payload.size() < EXIF_HEADER_SIZE ||
        !std::ranges::equal(payload.first(EXIF_HEADER_SIZE), EXIF_SIG)) {
        return std::nullopt;
    }
    return exifOrientationFromTiff(payload.subspan(EXIF_HEADER_SIZE));
}

int getTransformOp(uint16_t orientation) {
    switch (orientation) {
        case 2: return TJXOP_HFLIP;
        case 3: return TJXOP_ROT180;
        case 4: return TJXOP_VFLIP;
        case 5: return TJXOP_TRANSPOSE;
        case 6: return TJXOP_ROT90;
        case 7: return TJXOP_TRANSVERSE;
        case 8: return TJXOP_ROT270;
        default: return TJXOP_NONE;
    }
}

int estimateImageQuality(std::span<const Byte> jpg) {
    const auto dqt_pos_opt = searchSig(jpg, DQT_SIG, DQT_SEARCH_LIMIT);
    if (!dqt_pos_opt) return DEFAULT_QUALITY_ESTIMATE;

    std::size_t pos = *dqt_pos_opt;
    if (!spanHasRange(jpg, pos, 4)) return DEFAULT_QUALITY_ESTIMATE;

    const auto end_opt = jpegSegmentEndFromLengthOffset(jpg, pos + 2);
    if (!end_opt) return DEFAULT_QUALITY_ESTIMATE;
    const std::size_t end = *end_opt;
    pos += 4;

    while (pos < end) {
        const Byte header = jpg[pos++];
        const Byte precision = (header >> 4) & 0x0F;
        const Byte table_id = header & 0x0F;

        if (precision > 1) break;

        const std::size_t table_size = (precision == 0) ? DQT_8BIT_TABLE_SIZE : DQT_16BIT_TABLE_SIZE;
        if (pos + table_size > end) break;

        if (table_id == 0) {
            int sum = 0;
            for (std::size_t i = 0; i < 64; ++i) {
                sum += (precision == 0)
                    ? jpg[pos + i]
                    : (static_cast<int>(jpg[pos + i * 2]) << 8) | jpg[pos + i * 2 + 1];
            }
            return qualityFromLuminanceSum(sum);
        }
        pos += table_size;
    }
    return DEFAULT_QUALITY_ESTIMATE;
}

void optimizeImage(vBytes& jpg_vec, bool isProgressive) {
    if (jpg_vec.empty()) {
        throw std::runtime_error("JPG image is empty!");
    }

    auto transformer = TJHandle::makeTransformer();
    if (!transformer) {
        throw std::runtime_error("tjInitTransform() failed");
    }

    int width = 0;
    int height = 0;
    int jpegSubsamp = 0;
    int jpegColorspace = 0;
    if (tjDecompressHeader3(
            transformer.get(),
            jpg_vec.data(),
            static_cast<unsigned long>(jpg_vec.size()),
            &width,
            &height,
            &jpegSubsamp,
            &jpegColorspace) != 0) {
        throw std::runtime_error(std::format("Image Error: {}", tjGetErrorStr2(transformer.get())));
    }

    constexpr int MIN_DIMENSION = 400;
    if (width < MIN_DIMENSION || height < MIN_DIMENSION) {
        throw std::runtime_error(std::format(
            "Image Error: Dimensions {}x{} are too small.\n"
            "For platform compatibility, cover image must be "
            "at least {}px for both width and height.",
            width, height, MIN_DIMENSION));
    }

    const int xop = [&] {
        if (auto ori = exifOrientation(jpg_vec)) return getTransformOp(*ori);
        return static_cast<int>(TJXOP_NONE);
    }();

    tjtransform xform{};
    xform.op      = xop;
    xform.options = TJXOPT_COPYNONE | TJXOPT_TRIM;
    if (isProgressive) xform.options |= TJXOPT_PROGRESSIVE;

    TJBuffer dst_buf;
    unsigned long dst_size = 0;

    if (tjTransform(
            transformer.get(),
            jpg_vec.data(),
            static_cast<unsigned long>(jpg_vec.size()),
            1,
            &dst_buf.data,
            &dst_size,
            &xform,
            0) != 0) {
        throw std::runtime_error(std::format("tjTransform: {}", tjGetErrorStr2(transformer.get())));
    }

    constexpr int MAX_ALLOWED_QUALITY = 97;
    const std::span<const Byte> result(dst_buf.data, dst_size);
    const int estimated_quality = estimateImageQuality(result);

    if (estimated_quality > MAX_ALLOWED_QUALITY) {
        throw std::runtime_error(std::format(
            "Image Error: Estimated quality {} exceeds maximum ({}).\n"
            "For platform compatibility, cover image quality "
            "must be {} or lower.",
            estimated_quality, MAX_ALLOWED_QUALITY, MAX_ALLOWED_QUALITY));
    }
    jpg_vec.assign(dst_buf.data, dst_buf.data + dst_size);
}
