#include "args_out.h"

#include <format>
#include <stdexcept>
#include <string_view>

namespace {

[[nodiscard]] std::string_view argAt(int argc, char** argv, int i) {
	if (i < 0 || i >= argc) {
		return {};
	}
	const char* const s = argv[i];
	return s ? std::string_view{s} : std::string_view{};
}

[[nodiscard]] std::string programName(int argc, char** argv) {
	if (argc >= 1 && argv[0] != nullptr) {
		return fs::path(argv[0]).filename().string();
	}
	return "pdv_out";
}

[[nodiscard]] std::string buildUsage(std::string_view prog) {
	return std::format("Usage: {} <cover_image> <pin_file>", prog);
}

[[noreturn]] void dieUsage(const std::string& usage) {
	throw std::runtime_error(usage);
}

} // namespace

ProgramArgs ProgramArgs::parse(int argc, char** argv) {
	const std::string usage = buildUsage(programName(argc, argv));
	if (argc != 3 || argAt(argc, argv, 1).empty() || argAt(argc, argv, 2).empty()) {
		dieUsage(usage);
	}

	ProgramArgs out{};
	out.image_file_path = fs::path(argAt(argc, argv, 1));
	out.pin_file_path = fs::path(argAt(argc, argv, 2));
	return out;
}
