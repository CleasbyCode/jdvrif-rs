#pragma once

#include "common.h"

#include <cstring>
#include <initializer_list>
#include <limits>
#include <span>
#include <stdexcept>
#include <string_view>
#include <utility>

enum class FileTypeCheck : Byte {
	cover_image        = 1,
	embedded_image     = 2,
	data_file          = 3,
	// Web variant only: pdv_out takes the recovery KEY/PIN as a small text file
	// rather than reading it from a terminal, so there is no interactive entry.
	pin_file           = 4,
	reddit_cover_image = 5
};

class OpenInputFile {
public:
	OpenInputFile() = default;
	OpenInputFile(const OpenInputFile&) = delete;
	OpenInputFile& operator=(const OpenInputFile&) = delete;
	OpenInputFile(OpenInputFile&& other) noexcept;
	OpenInputFile& operator=(OpenInputFile&& other) noexcept;
	~OpenInputFile();

	[[nodiscard]] int fd() const noexcept { return fd_; }
	[[nodiscard]] std::size_t size() const noexcept { return size_; }

private:
	friend OpenInputFile openInputFile(const fs::path&, FileTypeCheck);
	explicit OpenInputFile(int fd, std::size_t size) noexcept : fd_(fd), size_(size) {}

	int fd_{-1};
	std::size_t size_{};
};

// Largest cover image conceal mode will accept, in bytes. Reported by --info and
// named in the rejection message so the rule is discoverable before it bites.
//
// The default and Mastodon modes share the first budget: their payload rides in
// a PNG chunk appended to the cover, so cover size is spent directly against the
// platform output limits. The Reddit carrier instead rewrites the pixels of a
// cover it re-encodes from scratch, and capacity scales with dimensions, so it
// takes a larger cover -- but one still below REDDIT_UPLOAD_SIZE_LIMIT, which is
// what the finished image must satisfy.
inline constexpr std::size_t MAX_COVER_IMAGE_SIZE = 4uz * 1024 * 1024;
inline constexpr std::size_t MAX_REDDIT_COVER_IMAGE_SIZE = 16uz * 1024 * 1024;

// Reddit's own upload ceiling. Applies to the payload input and to the finished
// "file-embedded" image, neither of which is bounded by the cover limit above.
inline constexpr std::size_t REDDIT_UPLOAD_SIZE_LIMIT = 20uz * 1024 * 1024;

[[nodiscard]] bool hasValidFilename(const fs::path& p);
// hasValidFilename plus the reserved-name rules used for embedded/recovered
// filenames: rejects ".", "..", a leading '.' or '-', a trailing space or '.',
// and the Unicode C1 control / bidirectional-formatting code points that
// neutralizeUnsafeCodePoints() replaces.
[[nodiscard]] bool hasSafeEmbeddedFilename(const fs::path& p);
// The specific reason `p` is unusable as an embedded filename, or an empty view
// if it is fine. Callers that report the failure to the user should use this
// rather than restating a partial version of the rules.
[[nodiscard]] std::string_view embeddedFilenameProblem(const fs::path& p);

// Replace each UTF-8 encoded C1 control (U+0080-U+009F) and bidirectional
// formatting character (U+061C, U+200E/F, U+202A-U+202E, U+2066-U+2069) with
// '_'. A terminal may act on a C1 control such as CSI, and a bidi override can
// disguise a filename's extension. Conceal rejects such names outright; recover
// neutralizes them instead, so a payload made by an older or foreign release
// stays recoverable. Bytes that are not valid UTF-8 pass through unchanged.
[[nodiscard]] std::string neutralizeUnsafeCodePoints(std::string_view name);

// `name` made safe to print on a terminal: valid, printable UTF-8 is kept, and
// every other byte (invalid UTF-8, control and bidi code points) is shown as
// \xNN. For display only -- never use the result as a path.
[[nodiscard]] std::string printableFilename(std::string_view name);
[[nodiscard]] bool hasFileExtension(const fs::path& p, std::initializer_list<std::string_view> exts);
[[nodiscard]] OpenInputFile openInputFile(const fs::path& path, FileTypeCheck file_type = FileTypeCheck::data_file);
[[nodiscard]] vBytes readFile(const fs::path& path, FileTypeCheck file_type = FileTypeCheck::data_file);

// Centralized span-range check. Accepts std::span<Byte>, std::span<const Byte>, and vBytes
// (all implicitly convert to std::span<const Byte>).
[[nodiscard]] inline bool spanHasRange(std::span<const Byte> data, std::size_t index, std::size_t length) {
	return index <= data.size() && length <= (data.size() - index);
}

// Bounds-checked byte comparison at an offset: false rather than UB when the
// range does not fit.
[[nodiscard]] inline bool bytesEqualAt(std::span<const Byte> data, std::size_t index, std::span<const Byte> expected) {
	return spanHasRange(data, index, expected.size()) &&
		std::memcmp(data.data() + index, expected.data(), expected.size()) == 0;
}

inline void requireSpanRange(std::span<const Byte> data, std::size_t index, std::size_t length, std::string_view message) {
	if (!spanHasRange(data, index, length)) {
		throw std::runtime_error(std::string(message));
	}
}

[[nodiscard]] inline std::size_t checkedAddSize(std::size_t lhs, std::size_t rhs, std::string_view message) {
	if (lhs > std::numeric_limits<std::size_t>::max() - rhs) {
		throw std::runtime_error(std::string(message));
	}
	return lhs + rhs;
}

[[nodiscard]] inline std::size_t checkedMulSize(std::size_t lhs, std::size_t rhs, std::string_view message) {
	if (lhs != 0 && rhs > std::numeric_limits<std::size_t>::max() / lhs) {
		throw std::runtime_error(std::string(message));
	}
	return lhs * rhs;
}

// Append `bytes` to `out`, growing it with an overflow-checked resize. `message`
// is the error thrown if the combined size would overflow std::size_t.
void appendBytes(vBytes& out, std::span<const Byte> bytes, std::string_view message);

// A byte buffer for secret data that scrubs itself when destroyed -- including
// during stack unwinding -- so exception safety comes with the buffer rather
// than with a separate ScopedWipe each caller has to remember to install.
//
// append() grows the buffer by hand: the contents are copied to the new
// allocation and the old one is scrubbed before it is freed, so no reallocation
// leaves a stale copy on the heap. Moving transfers the storage and leaves the
// source empty; there is deliberately no copy.
class SecureBytes {
public:
	SecureBytes() = default;
	explicit SecureBytes(std::size_t size) : bytes_(size) {}
	SecureBytes(SecureBytes&& other) noexcept : bytes_(std::exchange(other.bytes_, {})) {}
	SecureBytes& operator=(SecureBytes&& other) noexcept {
		if (this != &other) {
			wipe();
			bytes_ = std::exchange(other.bytes_, {});
		}
		return *this;
	}
	SecureBytes(const SecureBytes&) = delete;
	SecureBytes& operator=(const SecureBytes&) = delete;
	~SecureBytes() { wipe(); }

	void reserve(std::size_t capacity) {
		if (capacity > bytes_.capacity()) regrow(capacity);
	}
	void append(std::span<const Byte> bytes, std::string_view message);

	[[nodiscard]] Byte* data() noexcept { return bytes_.data(); }
	[[nodiscard]] const Byte* data() const noexcept { return bytes_.data(); }
	[[nodiscard]] std::size_t size() const noexcept { return bytes_.size(); }
	[[nodiscard]] bool empty() const noexcept { return bytes_.empty(); }
	[[nodiscard]] std::span<Byte> span() noexcept { return bytes_; }
	[[nodiscard]] std::span<const Byte> span() const noexcept { return bytes_; }

private:
	void regrow(std::size_t capacity);
	void wipe() noexcept {
		if (!bytes_.empty()) sodium_memzero(bytes_.data(), bytes_.size());
	}

	vBytes bytes_;
};

// A new output file in the current directory that has no name until publish().
//
// Where the filesystem supports O_TMPFILE the file is unnamed: if the process is
// interrupted or killed at any point before publish() -- Ctrl-C mid-write
// included, which no catch block can see -- the kernel discards it, so a
// partially written recovered secret or a PIN-less image is never left behind.
// Otherwise it is staged under a hidden ".pdvrdt_tmp_NNNNNN" name, removed on
// every path that unwinds. That is the tradeoff on such filesystems: Ctrl-C
// (no handler, so nothing unwinds), SIGKILL, a crash or power loss mid-write
// can leave the hidden 0600 file behind -- holding the image, or for recovery
// the decrypted plaintext. It never appears under the final name.
//
// publish() links or renames it to `name` and never replaces an existing entry,
// returning false if `name` is taken so the caller can try another.
class OutputFile {
public:
	[[nodiscard]] static OutputFile createInCurrentDirectory();

	OutputFile(OutputFile&& other) noexcept;
	OutputFile& operator=(OutputFile&&) = delete;
	OutputFile(const OutputFile&) = delete;
	OutputFile& operator=(const OutputFile&) = delete;
	~OutputFile();

	[[nodiscard]] int fd() const noexcept { return fd_; }
	[[nodiscard]] bool publish(const fs::path& name);
	// Close, reporting any deferred write error. Call after publish(): once the
	// file is published, removing it on failure is the caller's job.
	void close();

private:
	OutputFile(int fd, fs::path staged_path) noexcept : fd_(fd), staged_path_(std::move(staged_path)) {}

	int fd_{-1};
	fs::path staged_path_{};  // empty for an unnamed O_TMPFILE file
	bool published_{false};
};

void closeFdNoThrow(int& fd) noexcept;
void closeFdOrThrow(int& fd);

// Flush `fd`'s contents to stable storage. Callers report success to the user
// only after this returns, so a write error deferred by the page cache (ENOSPC,
// EIO on a failing disk) surfaces as a failure rather than as a "Complete!" for
// a file that never landed.
void fsyncFdOrThrow(int fd);

// Flush the directory entry for `path`, so the name itself survives a crash and
// not just the bytes behind it. Best-effort and non-throwing: a directory that
// cannot be opened for reading (write+execute but not read) is a permissions
// quirk, not a sign that the data is at risk, and must not fail an operation
// that has otherwise fully succeeded.
void fsyncParentDirectoryNoThrow(const fs::path& path) noexcept;
void writeAllToFd(int fd, std::span<const Byte> data);
void cleanupPathNoThrow(const fs::path& path) noexcept;
