#include "reddit_steg.h"

#include "encryption_internal.h"
#include "file_utils.h"
#include "signal_utils.h"

#include <algorithm>
#include <array>
#include <csetjmp>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <memory>
#include <numeric>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>

extern "C" {
#include <jpeglib.h>
}

namespace {

constexpr auto RQSTEG_MAGIC = std::to_array<Byte>({
    'R', 'Q', 'S', 'T', 'E', 'G', '1', 0
});
constexpr auto REDDIT_ENVELOPE_MAGIC = std::to_array<Byte>({
    'J', 'D', 'V', 'R', 'I', 'F', 'R', '1'
});

constexpr Byte
    RQSTEG_VERSION          = 1,
    HEADER_COPIES           = 17,
    PAYLOAD_COPIES          = 3,
    ENVELOPE_FLAG_COMPRESSED = 1;

constexpr int
    QIM_STEP           = 8,
    CARRIER_QUALITY    = 75,
    MIN_IMAGE_DIMENSION = 400,
    MAX_IMAGE_DIMENSION = 16'384;

constexpr std::uint64_t
    FIXED_SEED       = 0x7265646469747137ULL,
    HEADER_DOMAIN    = 0x4845414445527631ULL,
    PAYLOAD_DOMAIN   = 0x5041594c4f414431ULL,
    MAX_IMAGE_PIXELS = 40'000'000;

constexpr std::size_t
    RQSTEG_HEADER_SIZE      = 24,
    RQSTEG_HEADER_BITS      = RQSTEG_HEADER_SIZE * 8,
    ENVELOPE_PREFIX_BYTES   = 16,
    REDDIT_ENVELOPE_HEADER_BYTES =
        ENVELOPE_PREFIX_BYTES + KDF_METADATA_REGION_BYTES;

// JPEG zig-zag position -> natural 8x8 coefficient-array position.
constexpr std::array<Byte, 64> ZIGZAG_TO_NATURAL{
     0,  1,  8, 16,  9,  2,  3, 10,
    17, 24, 32, 25, 18, 11,  4,  5,
    12, 19, 26, 33, 40, 48, 41, 34,
    27, 20, 13,  6,  7, 14, 21, 28,
    35, 42, 49, 56, 57, 50, 43, 36,
    29, 22, 15, 23, 30, 37, 44, 51,
    58, 59, 52, 45, 38, 31, 39, 46,
    53, 60, 61, 54, 47, 55, 62, 63
};

constexpr std::array<Byte, 1> HEADER_FREQUENCIES{
    ZIGZAG_TO_NATURAL[4]
};

// Ten disjoint low/mid-frequency luminance AC lattices carry the payload.
constexpr std::array<Byte, 10> PAYLOAD_FREQUENCIES{
    ZIGZAG_TO_NATURAL[5],  ZIGZAG_TO_NATURAL[6],
    ZIGZAG_TO_NATURAL[7],  ZIGZAG_TO_NATURAL[8],
    ZIGZAG_TO_NATURAL[9],  ZIGZAG_TO_NATURAL[10],
    ZIGZAG_TO_NATURAL[11], ZIGZAG_TO_NATURAL[12],
    ZIGZAG_TO_NATURAL[13], ZIGZAG_TO_NATURAL[14]
};

constexpr std::array<unsigned int, 64> STD_LUMA_Q50{
    16,11,10,16,24,40,51,61,
    12,12,14,19,26,58,60,55,
    14,13,16,24,40,57,69,56,
    14,17,22,29,51,87,80,62,
    18,22,37,56,68,109,103,77,
    24,35,55,64,81,104,113,92,
    49,64,78,87,103,121,120,101,
    72,92,95,98,112,100,103,99
};

constexpr std::array<unsigned int, 64> STD_CHROMA_Q50{
    17,18,24,47,99,99,99,99,
    18,21,26,66,99,99,99,99,
    24,26,56,99,99,99,99,99,
    47,66,99,99,99,99,99,99,
    99,99,99,99,99,99,99,99,
    99,99,99,99,99,99,99,99,
    99,99,99,99,99,99,99,99,
    99,99,99,99,99,99,99,99
};

struct JpegErrorManager {
    jpeg_error_mgr pub{};
    std::jmp_buf jump{};
    std::array<char, JMSG_LENGTH_MAX> message{};
};

extern "C" void jpegErrorExit(j_common_ptr cinfo) {
    auto* error = reinterpret_cast<JpegErrorManager*>(cinfo->err);
    (*cinfo->err->format_message)(cinfo, error->message.data());
    std::longjmp(error->jump, 1);
}

struct CodecState {
    jpeg_decompress_struct source{};
    jpeg_compress_struct destination{};
    unsigned char* output_buffer{nullptr};
    unsigned long output_size{0};
    bool source_created{false};
    bool destination_created{false};
};

struct ImageInfo {
    std::uint32_t width{0};
    std::uint32_t height{0};
    std::uint32_t y_blocks_wide{0};
    std::uint32_t y_blocks_high{0};
    int components{0};
    bool progressive{false};
    bool is_420{false};
    bool is_q75{false};

    [[nodiscard]] std::uint64_t yBlockCount() const noexcept {
        return static_cast<std::uint64_t>(y_blocks_wide) * y_blocks_high;
    }
};

struct Carrier {
    std::uint64_t block_index{0};
    std::uint64_t bit_index{0};
    Byte coefficient_index{0};
    bool whitening_bit{false};
};

struct CarrierHeader {
    std::uint32_t payload_size{0};
    std::uint32_t payload_crc{0};
};

struct DecodedSymbol {
    bool bit{false};
    int confidence{0};
};

constexpr const char* REDDIT_CORRUPT_ERROR =
    "File Extraction Error: Reddit embedded data is corrupt!";

[[noreturn]] void fail(const std::string& message) {
    throw std::runtime_error(message);
}

void cleanupCodec(CodecState& state) noexcept {
    if (state.destination_created) {
        jpeg_destroy_compress(&state.destination);
        state.destination_created = false;
    }
    if (state.source_created) {
        jpeg_destroy_decompress(&state.source);
        state.source_created = false;
    }
    std::free(state.output_buffer);
    state.output_buffer = nullptr;
    state.output_size = 0;
}

void requireMemorySourceSize(std::size_t size) {
    if (size == 0 || size > static_cast<std::size_t>(std::numeric_limits<unsigned long>::max())) {
        fail("Image Error: JPEG input is empty or too large for the decoder.");
    }
}

[[nodiscard]] vBytes copyCodecOutput(const CodecState& state) {
    if (state.output_buffer == nullptr || state.output_size == 0) {
        fail("Image Error: JPEG encoder produced no output.");
    }
    const std::size_t size = static_cast<std::size_t>(state.output_size);
    vBytes output(size);
    std::memcpy(output.data(), state.output_buffer, size);
    return output;
}

[[nodiscard]] std::uint32_t crc32(std::span<const Byte> data) {
    std::uint32_t crc = 0xffffffffU;
    for (const Byte byte : data) {
        crc ^= byte;
        for (int bit = 0; bit < 8; ++bit) {
            const std::uint32_t mask = 0U - (crc & 1U);
            crc = (crc >> 1U) ^ (0xedb88320U & mask);
        }
    }
    return ~crc;
}

void appendU32(vBytes& output, std::uint32_t value) {
    for (unsigned int shift = 0; shift < 32; shift += 8) {
        output.push_back(static_cast<Byte>((value >> shift) & 0xffU));
    }
}

[[nodiscard]] std::uint32_t readU32(
    std::span<const Byte> input,
    std::size_t offset) {

    if (!spanHasRange(input, offset, 4)) fail(REDDIT_CORRUPT_ERROR);
    std::uint32_t value = 0;
    for (unsigned int byte = 0; byte < 4; ++byte) {
        value |= static_cast<std::uint32_t>(input[offset + byte])
            << (byte * 8U);
    }
    return value;
}

[[nodiscard]] vBytes makeCarrierHeader(
    std::uint32_t payload_size,
    std::uint32_t payload_crc) {

    vBytes header;
    header.reserve(RQSTEG_HEADER_SIZE);
    header.insert(header.end(), RQSTEG_MAGIC.begin(), RQSTEG_MAGIC.end());
    header.push_back(RQSTEG_VERSION);
    header.push_back(static_cast<Byte>(QIM_STEP));
    header.push_back(PAYLOAD_COPIES);
    header.push_back(0); // flags
    appendU32(header, payload_size);
    appendU32(header, payload_crc);
    appendU32(header, crc32(header));
    if (header.size() != RQSTEG_HEADER_SIZE) {
        fail("Internal Error: Reddit carrier header has an invalid size.");
    }
    return header;
}

[[nodiscard]] std::optional<CarrierHeader> parseCarrierHeader(
    std::span<const Byte> header) {

    if (header.size() != RQSTEG_HEADER_SIZE) {
        fail(REDDIT_CORRUPT_ERROR);
    }
    if (!std::equal(RQSTEG_MAGIC.begin(), RQSTEG_MAGIC.end(), header.begin())) {
        return std::nullopt;
    }

    const std::uint32_t expected_header_crc = readU32(header, 20);
    if (crc32(header.first(20)) != expected_header_crc) {
        fail("File Extraction Error: Reddit carrier header failed its integrity check.");
    }
    if (header[8] != RQSTEG_VERSION ||
        header[9] != static_cast<Byte>(QIM_STEP) ||
        header[10] != PAYLOAD_COPIES ||
        header[11] != 0) {
        fail("File Extraction Error: Unsupported Reddit carrier format.");
    }

    return CarrierHeader{
        .payload_size = readU32(header, 12),
        .payload_crc = readU32(header, 16),
    };
}

[[nodiscard]] bool getBit(std::span<const Byte> bytes, std::uint64_t bit_index) {
    const std::size_t byte_index = static_cast<std::size_t>(bit_index / 8U);
    const unsigned int shift = static_cast<unsigned int>(bit_index % 8U);
    return ((bytes[byte_index] >> shift) & 1U) != 0U;
}

void setBit(vBytes& bytes, std::uint64_t bit_index, bool value) {
    const std::size_t byte_index = static_cast<std::size_t>(bit_index / 8U);
    const unsigned int shift = static_cast<unsigned int>(bit_index % 8U);
    const Byte mask = static_cast<Byte>(1U << shift);
    if (value) {
        bytes[byte_index] |= mask;
    } else {
        bytes[byte_index] &= static_cast<Byte>(~mask);
    }
}

[[nodiscard]] std::uint64_t mix64(std::uint64_t value) noexcept {
    value += 0x9e3779b97f4a7c15ULL;
    value = (value ^ (value >> 30U)) * 0xbf58476d1ce4e5b9ULL;
    value = (value ^ (value >> 27U)) * 0x94d049bb133111ebULL;
    return value ^ (value >> 31U);
}

struct AffinePermutation {
    std::uint64_t count{0};
    std::uint64_t multiplier{0};
    std::uint64_t offset{0};

    [[nodiscard]] std::uint64_t operator()(std::uint64_t index) const noexcept {
        return ((multiplier * index) + offset) % count;
    }
};

[[nodiscard]] AffinePermutation makePermutation(
    std::uint64_t count,
    std::uint64_t seed,
    std::uint64_t domain) {

    if (count == 0) {
        fail("Image Error: Carrier image has no usable coefficient positions.");
    }
    std::uint64_t multiplier = mix64(seed ^ domain ^ count) % count;
    if (multiplier == 0) multiplier = 1;
    while (std::gcd(multiplier, count) != 1U) {
        multiplier = (multiplier + 1U) % count;
        if (multiplier == 0) multiplier = 1;
    }
    return AffinePermutation{
        .count = count,
        .multiplier = multiplier,
        .offset = mix64(seed + domain) % count,
    };
}

template<std::size_t FrequencyCount>
[[nodiscard]] std::vector<Carrier> makeCarriers(
    std::uint64_t block_count,
    const std::array<Byte, FrequencyCount>& frequencies,
    std::uint64_t bit_count,
    Byte copies,
    std::uint64_t seed,
    std::uint64_t domain) {

    const std::uint64_t copy_count = copies;
    if (bit_count != 0 && copy_count > std::numeric_limits<std::uint64_t>::max() / bit_count) {
        fail("Internal Error: Reddit carrier-count overflow.");
    }
    const std::uint64_t slots = bit_count * copy_count;
    if (block_count > std::numeric_limits<std::uint64_t>::max() / FrequencyCount) {
        fail("Internal Error: Reddit coefficient-count overflow.");
    }
    const std::uint64_t candidate_count =
        block_count * static_cast<std::uint64_t>(FrequencyCount);
    if (slots > candidate_count) {
        fail("Data File Size Error: Encrypted payload exceeds this cover image's C3 coefficient capacity.");
    }
    if (slots > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max())) {
        fail("Internal Error: Reddit carrier allocation exceeds addressable memory.");
    }

    const AffinePermutation permutation = makePermutation(candidate_count, seed, domain);
    std::vector<Carrier> carriers;
    carriers.reserve(static_cast<std::size_t>(slots));
    for (std::uint64_t bit = 0; bit < bit_count; ++bit) {
        for (std::uint64_t copy = 0; copy < copy_count; ++copy) {
            const std::uint64_t candidate = permutation(bit * copy_count + copy);
            const std::uint64_t block = candidate / FrequencyCount;
            const std::size_t frequency =
                static_cast<std::size_t>(candidate % FrequencyCount);
            carriers.push_back(Carrier{
                .block_index = block,
                .bit_index = bit,
                .coefficient_index = frequencies[frequency],
                .whitening_bit = (mix64(seed ^ domain ^ candidate) & 1U) != 0U,
            });
        }
    }
    return carriers;
}

[[nodiscard]] int floorDivide(int numerator, int denominator) noexcept {
    int quotient = numerator / denominator;
    const int remainder = numerator % denominator;
    if (remainder != 0 && ((remainder < 0) != (denominator < 0))) {
        --quotient;
    }
    return quotient;
}

[[nodiscard]] JCOEF qimEncode(JCOEF coefficient, bool bit) noexcept {
    const int value = coefficient;
    const int target = bit ? (3 * QIM_STEP) / 4 : QIM_STEP / 4;
    const int quotient = floorDivide(value - target, QIM_STEP);
    const int lower = target + quotient * QIM_STEP;
    const int upper = lower + QIM_STEP;
    const int lower_distance = std::abs(value - lower);
    const int upper_distance = std::abs(value - upper);

    int chosen = lower;
    if (upper_distance < lower_distance) {
        chosen = upper;
    } else if (upper_distance == lower_distance) {
        if (value > 0 && upper > 0) {
            chosen = upper;
        } else if (value < 0 && lower < 0) {
            chosen = lower;
        } else if (std::abs(upper) < std::abs(lower)) {
            chosen = upper;
        }
    }

    chosen = std::clamp(
        chosen,
        static_cast<int>(std::numeric_limits<JCOEF>::min()),
        static_cast<int>(std::numeric_limits<JCOEF>::max()));
    return static_cast<JCOEF>(chosen);
}

[[nodiscard]] int positiveModulo(int value, int modulus) noexcept {
    const int remainder = value % modulus;
    return remainder < 0 ? remainder + modulus : remainder;
}

[[nodiscard]] int circularDistance(int lhs, int rhs, int modulus) noexcept {
    const int direct = std::abs(lhs - rhs);
    return std::min(direct, modulus - direct);
}

[[nodiscard]] DecodedSymbol qimDecode(JCOEF coefficient) noexcept {
    const int residue = positiveModulo(coefficient, QIM_STEP);
    const int target_zero = QIM_STEP / 4;
    const int target_one = (3 * QIM_STEP) / 4;
    const int zero_distance =
        circularDistance(residue, target_zero, QIM_STEP);
    const int one_distance =
        circularDistance(residue, target_one, QIM_STEP);
    return DecodedSymbol{
        .bit = one_distance < zero_distance,
        .confidence = std::abs(one_distance - zero_distance) + 1,
    };
}

[[nodiscard]] std::array<unsigned int, 64> scaledQuantTable(
    const std::array<unsigned int, 64>& base,
    int quality) {

    const int scale = quality < 50 ? 5000 / quality : 200 - quality * 2;
    std::array<unsigned int, 64> result{};
    for (std::size_t i = 0; i < base.size(); ++i) {
        const int value = std::clamp(
            (static_cast<int>(base[i]) * scale + 50) / 100,
            1,
            255);
        result[i] = static_cast<unsigned int>(value);
    }
    return result;
}

void installExactQuantTable(
    jpeg_compress_struct& destination,
    int table_index,
    const std::array<unsigned int, 64>& values) {

    if (table_index < 0 || table_index >= NUM_QUANT_TBLS) {
        fail("Internal Error: Reddit quantization-table index is invalid.");
    }

    JQUANT_TBL*& table =
        destination.quant_tbl_ptrs[table_index];
    if (table == nullptr) {
        table = jpeg_alloc_quant_table(
            reinterpret_cast<j_common_ptr>(&destination));
    }
    for (std::size_t i = 0; i < values.size(); ++i) {
        table->quantval[i] = static_cast<UINT16>(values[i]);
    }
    table->sent_table = FALSE;
}

void installStandardQ75QuantTables(
    jpeg_compress_struct& destination) {

    installExactQuantTable(
        destination,
        0,
        scaledQuantTable(STD_LUMA_Q50, CARRIER_QUALITY));
    installExactQuantTable(
        destination,
        1,
        scaledQuantTable(STD_CHROMA_Q50, CARRIER_QUALITY));

    // Do not inherit component/table choices from an implementation-specific
    // jpeg_set_defaults(). The carrier format requires Y=0, Cb=1, Cr=1.
    destination.comp_info[0].quant_tbl_no = 0;
    destination.comp_info[1].quant_tbl_no = 1;
    destination.comp_info[2].quant_tbl_no = 1;
}

[[nodiscard]] bool quantTableMatches(
    const JQUANT_TBL* table,
    const std::array<unsigned int, 64>& expected) {

    if (table == nullptr) return false;
    for (std::size_t i = 0; i < expected.size(); ++i) {
        if (table->quantval[i] != expected[i]) return false;
    }
    return true;
}

[[nodiscard]] ImageInfo imageInfoFromHeader(const jpeg_decompress_struct& source) {
    const bool has_three_components = source.num_components == 3;
    const bool is_420 = has_three_components &&
        source.comp_info[0].h_samp_factor == 2 &&
        source.comp_info[0].v_samp_factor == 2 &&
        source.comp_info[1].h_samp_factor == 1 &&
        source.comp_info[1].v_samp_factor == 1 &&
        source.comp_info[2].h_samp_factor == 1 &&
        source.comp_info[2].v_samp_factor == 1;
    const auto expected_luma = scaledQuantTable(STD_LUMA_Q50, CARRIER_QUALITY);
    const auto expected_chroma = scaledQuantTable(STD_CHROMA_Q50, CARRIER_QUALITY);
    const bool is_q75 = has_three_components &&
        quantTableMatches(source.quant_tbl_ptrs[0], expected_luma) &&
        quantTableMatches(source.quant_tbl_ptrs[1], expected_chroma);

    return ImageInfo{
        .width = static_cast<std::uint32_t>(source.image_width),
        .height = static_cast<std::uint32_t>(source.image_height),
        .y_blocks_wide = has_three_components
            ? static_cast<std::uint32_t>(source.comp_info[0].width_in_blocks) : 0,
        .y_blocks_high = has_three_components
            ? static_cast<std::uint32_t>(source.comp_info[0].height_in_blocks) : 0,
        .components = source.num_components,
        .progressive = source.progressive_mode != 0,
        .is_420 = is_420,
        .is_q75 = is_q75,
    };
}

void validateCoverInput(const jpeg_decompress_struct& source) {
    const std::uint64_t width = source.image_width;
    const std::uint64_t height = source.image_height;
    if (source.num_components != 1 && source.num_components != 3) {
        fail("Image Error: Unsupported JPEG color space. CMYK/YCCK cover images must be converted to RGB before use.");
    }
    if (width < MIN_IMAGE_DIMENSION || height < MIN_IMAGE_DIMENSION) {
        fail("Image Error: For platform compatibility, cover image dimensions must be at least 400x400 pixels.");
    }
    if (width > MAX_IMAGE_DIMENSION ||
        height > MAX_IMAGE_DIMENSION ||
        width * height > MAX_IMAGE_PIXELS) {
        fail("Image Error: Cover image dimensions exceed jdvrif's safe image limit.");
    }
}

[[nodiscard]] bool isCompatibleCarrier(const ImageInfo& info) noexcept {
    const std::uint64_t pixel_count =
        static_cast<std::uint64_t>(info.width) * info.height;
    return info.components == 3 &&
        !info.progressive &&
        info.is_420 &&
        info.is_q75 &&
        info.width >= MIN_IMAGE_DIMENSION &&
        info.height >= MIN_IMAGE_DIMENSION &&
        info.width <= MAX_IMAGE_DIMENSION &&
        info.height <= MAX_IMAGE_DIMENSION &&
        pixel_count <= MAX_IMAGE_PIXELS &&
        info.yBlockCount() >=
            static_cast<std::uint64_t>(RQSTEG_HEADER_BITS) * HEADER_COPIES;
}

void validateCarrier(const ImageInfo& info) {
    if (info.components != 3) {
        fail("Internal Error: Reddit carrier is not a three-component colour JPEG.");
    }
    if (info.progressive) {
        fail("Internal Error: Reddit carrier is not a baseline JPEG.");
    }
    if (!info.is_420) {
        fail("Internal Error: Reddit carrier does not use YCbCr 4:2:0 subsampling.");
    }
    if (!info.is_q75) {
        fail("Internal Error: Reddit carrier does not use the standard quality-75 quantization tables.");
    }
    if (info.yBlockCount() <
        static_cast<std::uint64_t>(RQSTEG_HEADER_BITS) * HEADER_COPIES) {
        fail("Image Error: Cover image is too small for the robust Reddit carrier header.");
    }
}

[[nodiscard]] ImageInfo inspectJpeg(std::span<const Byte> input) {
    requireMemorySourceSize(input.size());
    auto state = std::make_unique<CodecState>();
    auto error = std::make_unique<JpegErrorManager>();
    ImageInfo info{};

    jpeg_std_error(&error->pub);
    error->pub.error_exit = jpegErrorExit;
    if (setjmp(error->jump) != 0) {
        const std::string message = error->message.data();
        cleanupCodec(*state);
        fail("JPEG error: " + message);
    }

    state->source.err = &error->pub;
    jpeg_create_decompress(&state->source);
    state->source_created = true;
    jpeg_mem_src(
        &state->source,
        input.data(),
        static_cast<unsigned long>(input.size()));
    jpeg_read_header(&state->source, TRUE);
    info = imageInfoFromHeader(state->source);
    cleanupCodec(*state);
    return info;
}

[[nodiscard]] vBytes transcodeCarrier(std::span<const Byte> input) {
    requireMemorySourceSize(input.size());
    auto state = std::make_unique<CodecState>();
    auto error = std::make_unique<JpegErrorManager>();
    std::vector<JSAMPLE> row;
    vBytes output;

    jpeg_std_error(&error->pub);
    error->pub.error_exit = jpegErrorExit;
    if (setjmp(error->jump) != 0) {
        const std::string message = error->message.data();
        cleanupCodec(*state);
        fail("JPEG error while preparing Reddit cover: " + message);
    }

    try {
        state->source.err = &error->pub;
        jpeg_create_decompress(&state->source);
        state->source_created = true;
        jpeg_mem_src(
            &state->source,
            input.data(),
            static_cast<unsigned long>(input.size()));
        jpeg_read_header(&state->source, TRUE);
        validateCoverInput(state->source);
        state->source.out_color_space = JCS_RGB;
        jpeg_start_decompress(&state->source);

        state->destination.err = &error->pub;
        jpeg_create_compress(&state->destination);
        state->destination_created = true;
        jpeg_mem_dest(
            &state->destination,
            &state->output_buffer,
            &state->output_size);
        state->destination.image_width = state->source.output_width;
        state->destination.image_height = state->source.output_height;
        state->destination.input_components = 3;
        state->destination.in_color_space = JCS_RGB;
        jpeg_set_defaults(&state->destination);
        // "Quality 75" is not a portable table specification: compatible
        // libjpeg implementations may map it to different defaults. Install
        // the exact IJG Q75 tables required by the Reddit carrier instead.
        installStandardQ75QuantTables(state->destination);
        state->destination.comp_info[0].h_samp_factor = 2;
        state->destination.comp_info[0].v_samp_factor = 2;
        state->destination.comp_info[1].h_samp_factor = 1;
        state->destination.comp_info[1].v_samp_factor = 1;
        state->destination.comp_info[2].h_samp_factor = 1;
        state->destination.comp_info[2].v_samp_factor = 1;
        state->destination.optimize_coding = FALSE;
        state->destination.write_JFIF_header = FALSE;
        state->destination.write_Adobe_marker = FALSE;
        jpeg_start_compress(&state->destination, TRUE);

        const std::uint64_t row_size =
            static_cast<std::uint64_t>(state->source.output_width) * 3U;
        if (row_size > std::numeric_limits<std::size_t>::max()) {
            fail("Image Error: Decoded JPEG row is too large.");
        }
        row.resize(static_cast<std::size_t>(row_size));
        while (state->source.output_scanline < state->source.output_height) {
            throwIfSignalCancellationRequested();
            JSAMPROW scanline = row.data();
            jpeg_read_scanlines(&state->source, &scanline, 1);
            jpeg_write_scanlines(&state->destination, &scanline, 1);
        }

        jpeg_finish_compress(&state->destination);
        jpeg_finish_decompress(&state->source);
        output = copyCodecOutput(*state);
        cleanupCodec(*state);
        return output;
    } catch (...) {
        cleanupCodec(*state);
        throw;
    }
}

void sortCarriers(std::vector<Carrier>& carriers) {
    std::sort(carriers.begin(), carriers.end(), [](const Carrier& lhs, const Carrier& rhs) {
        if (lhs.block_index != rhs.block_index) {
            return lhs.block_index < rhs.block_index;
        }
        return lhs.coefficient_index < rhs.coefficient_index;
    });
}

void applyCarriers(
    jpeg_decompress_struct& source,
    jvirt_barray_ptr* coefficient_arrays,
    std::span<const Carrier> carriers,
    std::span<const Byte> bits) {

    const jpeg_component_info& y = source.comp_info[0];
    std::size_t carrier_index = 0;
    for (JDIMENSION row = 0;
         row < y.height_in_blocks && carrier_index < carriers.size();
         ++row) {

        throwIfSignalCancellationRequested();
        JBLOCKARRAY block_row = (*source.mem->access_virt_barray)(
            reinterpret_cast<j_common_ptr>(&source),
            coefficient_arrays[0],
            row,
            1,
            TRUE);
        while (carrier_index < carriers.size()) {
            const Carrier& carrier = carriers[carrier_index];
            const std::uint64_t carrier_row =
                carrier.block_index / y.width_in_blocks;
            if (carrier_row != row) break;

            const JDIMENSION column = static_cast<JDIMENSION>(
                carrier.block_index % y.width_in_blocks);
            const bool logical_bit = getBit(bits, carrier.bit_index);
            const bool encoded_bit = logical_bit ^ carrier.whitening_bit;
            JCOEF& coefficient =
                block_row[0][column][carrier.coefficient_index];
            coefficient = qimEncode(coefficient, encoded_bit);
            ++carrier_index;
        }
    }
    if (carrier_index != carriers.size()) {
        fail("Internal Error: Reddit carrier index exceeded image bounds.");
    }
}

[[nodiscard]] vBytes readCarriers(
    jpeg_decompress_struct& source,
    jvirt_barray_ptr* coefficient_arrays,
    std::span<const Carrier> carriers,
    std::uint64_t bit_count) {

    if (bit_count > static_cast<std::uint64_t>(
            std::numeric_limits<std::size_t>::max())) {
        fail(REDDIT_CORRUPT_ERROR);
    }
    std::vector<int> scores(static_cast<std::size_t>(bit_count), 0);
    const jpeg_component_info& y = source.comp_info[0];

    std::size_t carrier_index = 0;
    for (JDIMENSION row = 0;
         row < y.height_in_blocks && carrier_index < carriers.size();
         ++row) {

        throwIfSignalCancellationRequested();
        JBLOCKARRAY block_row = (*source.mem->access_virt_barray)(
            reinterpret_cast<j_common_ptr>(&source),
            coefficient_arrays[0],
            row,
            1,
            FALSE);
        while (carrier_index < carriers.size()) {
            const Carrier& carrier = carriers[carrier_index];
            const std::uint64_t carrier_row =
                carrier.block_index / y.width_in_blocks;
            if (carrier_row != row) break;

            const JDIMENSION column = static_cast<JDIMENSION>(
                carrier.block_index % y.width_in_blocks);
            DecodedSymbol symbol = qimDecode(
                block_row[0][column][carrier.coefficient_index]);
            symbol.bit = symbol.bit ^ carrier.whitening_bit;
            const std::size_t bit =
                static_cast<std::size_t>(carrier.bit_index);
            scores[bit] += symbol.bit
                ? symbol.confidence
                : -symbol.confidence;
            ++carrier_index;
        }
    }
    if (carrier_index != carriers.size()) {
        fail(REDDIT_CORRUPT_ERROR);
    }

    vBytes decoded(static_cast<std::size_t>((bit_count + 7U) / 8U), 0);
    for (std::uint64_t bit = 0; bit < bit_count; ++bit) {
        setBit(
            decoded,
            bit,
            scores[static_cast<std::size_t>(bit)] >= 0);
    }
    return decoded;
}

[[nodiscard]] vBytes embedCarrier(
    std::span<const Byte> input,
    std::span<const Byte> header,
    std::span<const Byte> payload) {

    requireMemorySourceSize(input.size());
    auto state = std::make_unique<CodecState>();
    auto error = std::make_unique<JpegErrorManager>();
    std::vector<Carrier> header_carriers;
    std::vector<Carrier> payload_carriers;
    vBytes output;

    jpeg_std_error(&error->pub);
    error->pub.error_exit = jpegErrorExit;
    if (setjmp(error->jump) != 0) {
        const std::string message = error->message.data();
        cleanupCodec(*state);
        fail("JPEG error while embedding Reddit payload: " + message);
    }

    try {
        state->source.err = &error->pub;
        jpeg_create_decompress(&state->source);
        state->source_created = true;
        jpeg_mem_src(
            &state->source,
            input.data(),
            static_cast<unsigned long>(input.size()));
        jpeg_read_header(&state->source, TRUE);
        const ImageInfo info = imageInfoFromHeader(state->source);
        validateCarrier(info);
        jvirt_barray_ptr* arrays = jpeg_read_coefficients(&state->source);

        header_carriers = makeCarriers(
            info.yBlockCount(),
            HEADER_FREQUENCIES,
            RQSTEG_HEADER_BITS,
            HEADER_COPIES,
            FIXED_SEED,
            HEADER_DOMAIN);
        const std::uint64_t payload_bits =
            static_cast<std::uint64_t>(payload.size()) * 8U;
        payload_carriers = makeCarriers(
            info.yBlockCount(),
            PAYLOAD_FREQUENCIES,
            payload_bits,
            PAYLOAD_COPIES,
            FIXED_SEED,
            PAYLOAD_DOMAIN);
        sortCarriers(header_carriers);
        sortCarriers(payload_carriers);
        applyCarriers(state->source, arrays, header_carriers, header);
        applyCarriers(state->source, arrays, payload_carriers, payload);

        state->destination.err = &error->pub;
        jpeg_create_compress(&state->destination);
        state->destination_created = true;
        jpeg_mem_dest(
            &state->destination,
            &state->output_buffer,
            &state->output_size);
        jpeg_copy_critical_parameters(&state->source, &state->destination);
        state->destination.write_JFIF_header = FALSE;
        state->destination.write_Adobe_marker = FALSE;
        state->destination.optimize_coding = FALSE;
        jpeg_write_coefficients(&state->destination, arrays);
        jpeg_finish_compress(&state->destination);
        jpeg_finish_decompress(&state->source);
        output = copyCodecOutput(*state);
        cleanupCodec(*state);
        return output;
    } catch (...) {
        cleanupCodec(*state);
        throw;
    }
}

[[nodiscard]] std::size_t carrierCapacity(std::uint64_t block_count) {
    if (block_count >
        std::numeric_limits<std::uint64_t>::max() / PAYLOAD_FREQUENCIES.size()) {
        fail("Internal Error: Reddit payload capacity overflow.");
    }
    const std::uint64_t capacity =
        (block_count * PAYLOAD_FREQUENCIES.size()) / PAYLOAD_COPIES / 8U;
    if (capacity > std::numeric_limits<std::size_t>::max()) {
        fail("Internal Error: Reddit payload capacity exceeds addressable memory.");
    }
    return static_cast<std::size_t>(capacity);
}

[[nodiscard]] std::optional<vBytes> extractCarrierPayload(
    std::span<const Byte> input) {

    if (input.size() < 2 || input[0] != 0xFF || input[1] != 0xD8) {
        return std::nullopt;
    }
    requireMemorySourceSize(input.size());

    auto state = std::make_unique<CodecState>();
    auto error = std::make_unique<JpegErrorManager>();
    std::vector<Carrier> header_carriers;
    std::vector<Carrier> payload_carriers;
    vBytes header_bytes;
    vBytes payload_bytes;
    std::optional<CarrierHeader> header;

    jpeg_std_error(&error->pub);
    error->pub.error_exit = jpegErrorExit;
    if (setjmp(error->jump) != 0) {
        const std::string message = error->message.data();
        cleanupCodec(*state);
        fail("JPEG error while extracting Reddit payload: " + message);
    }

    try {
        state->source.err = &error->pub;
        jpeg_create_decompress(&state->source);
        state->source_created = true;
        jpeg_mem_src(
            &state->source,
            input.data(),
            static_cast<unsigned long>(input.size()));
        jpeg_read_header(&state->source, TRUE);
        const ImageInfo info = imageInfoFromHeader(state->source);
        if (!isCompatibleCarrier(info)) {
            cleanupCodec(*state);
            return std::nullopt;
        }

        jvirt_barray_ptr* arrays = jpeg_read_coefficients(&state->source);
        header_carriers = makeCarriers(
            info.yBlockCount(),
            HEADER_FREQUENCIES,
            RQSTEG_HEADER_BITS,
            HEADER_COPIES,
            FIXED_SEED,
            HEADER_DOMAIN);
        sortCarriers(header_carriers);
        header_bytes = readCarriers(
            state->source,
            arrays,
            header_carriers,
            RQSTEG_HEADER_BITS);
        header = parseCarrierHeader(header_bytes);
        if (!header) {
            jpeg_finish_decompress(&state->source);
            cleanupCodec(*state);
            return std::nullopt;
        }

        if (header->payload_size > carrierCapacity(info.yBlockCount())) {
            fail("File Extraction Error: Reddit carrier declares a payload larger than its coefficient capacity.");
        }
        const std::uint64_t payload_bits =
            static_cast<std::uint64_t>(header->payload_size) * 8U;
        payload_carriers = makeCarriers(
            info.yBlockCount(),
            PAYLOAD_FREQUENCIES,
            payload_bits,
            PAYLOAD_COPIES,
            FIXED_SEED,
            PAYLOAD_DOMAIN);
        sortCarriers(payload_carriers);
        payload_bytes = readCarriers(
            state->source,
            arrays,
            payload_carriers,
            payload_bits);
        if (crc32(payload_bytes) != header->payload_crc) {
            fail("File Extraction Error: Reddit carrier payload failed its integrity check.");
        }

        jpeg_finish_decompress(&state->source);
        cleanupCodec(*state);
        return payload_bytes;
    } catch (...) {
        cleanupCodec(*state);
        throw;
    }
}

} // namespace

RedditPreparedCover prepareRedditCover(std::span<const Byte> input_jpeg) {
    vBytes prepared = transcodeCarrier(input_jpeg);
    const ImageInfo info = inspectJpeg(prepared);
    validateCarrier(info);
    return RedditPreparedCover{
        .jpeg = std::move(prepared),
        .width = info.width,
        .height = info.height,
        .luminance_blocks = info.yBlockCount(),
        .payload_capacity = carrierCapacity(info.yBlockCount()),
    };
}

std::size_t redditEnvelopeSize(std::size_t encrypted_size) {
    return checkedAdd(
        REDDIT_ENVELOPE_HEADER_BYTES,
        encrypted_size,
        "File Size Error: Reddit encrypted-envelope size overflow.");
}

vBytes makeRedditEnvelope(
    std::span<const Byte> kdf_metadata,
    std::span<const Byte> encrypted_data,
    bool is_compressed) {

    if (kdf_metadata.size() != KDF_METADATA_REGION_BYTES) {
        fail("Internal Error: Reddit KDF metadata has an invalid size.");
    }
    if (encrypted_data.size() > std::numeric_limits<std::uint32_t>::max()) {
        fail("File Size Error: Reddit encrypted payload exceeds its format limit.");
    }

    vBytes envelope;
    envelope.reserve(redditEnvelopeSize(encrypted_data.size()));
    envelope.insert(
        envelope.end(),
        REDDIT_ENVELOPE_MAGIC.begin(),
        REDDIT_ENVELOPE_MAGIC.end());
    envelope.push_back(is_compressed ? ENVELOPE_FLAG_COMPRESSED : 0);
    envelope.insert(envelope.end(), 3, 0); // reserved
    appendU32(envelope, static_cast<std::uint32_t>(encrypted_data.size()));
    envelope.insert(envelope.end(), kdf_metadata.begin(), kdf_metadata.end());
    envelope.insert(envelope.end(), encrypted_data.begin(), encrypted_data.end());
    if (envelope.size() != redditEnvelopeSize(encrypted_data.size())) {
        fail("Internal Error: Reddit encrypted envelope has an invalid size.");
    }
    return envelope;
}

vBytes embedRedditPayload(
    const RedditPreparedCover& cover,
    std::span<const Byte> payload) {

    if (payload.size() > cover.payload_capacity) {
        fail("Data File Size Error: Encrypted Reddit payload exceeds the cover image's theoretical C3 capacity.");
    }
    if (payload.size() > std::numeric_limits<std::uint32_t>::max()) {
        fail("Data File Size Error: Encrypted Reddit payload exceeds its format limit.");
    }

    const vBytes header = makeCarrierHeader(
        static_cast<std::uint32_t>(payload.size()),
        crc32(payload));
    return embedCarrier(cover.jpeg, header, payload);
}

std::optional<RedditEncryptedEnvelope> extractRedditEnvelope(
    std::span<const Byte> input_jpeg) {

    std::optional<vBytes> carrier_payload =
        extractCarrierPayload(input_jpeg);
    if (!carrier_payload) return std::nullopt;

    const std::span<const Byte> payload(*carrier_payload);
    if (payload.size() < REDDIT_ENVELOPE_MAGIC.size() ||
        !std::equal(
            REDDIT_ENVELOPE_MAGIC.begin(),
            REDDIT_ENVELOPE_MAGIC.end(),
            payload.begin())) {
        return std::nullopt;
    }
    if (payload.size() < REDDIT_ENVELOPE_HEADER_BYTES) {
        fail(REDDIT_CORRUPT_ERROR);
    }

    const Byte flags = payload[8];
    if ((flags & static_cast<Byte>(~ENVELOPE_FLAG_COMPRESSED)) != 0 ||
        payload[9] != 0 ||
        payload[10] != 0 ||
        payload[11] != 0) {
        fail("File Extraction Error: Reddit envelope contains unsupported flags.");
    }

    const std::size_t encrypted_size = readU32(payload, 12);
    const std::size_t expected_size = checkedAdd(
        REDDIT_ENVELOPE_HEADER_BYTES,
        encrypted_size,
        REDDIT_CORRUPT_ERROR);
    if (payload.size() != expected_size) {
        fail(REDDIT_CORRUPT_ERROR);
    }

    RedditEncryptedEnvelope envelope;
    envelope.kdf_metadata.assign(
        payload.begin() + static_cast<std::ptrdiff_t>(ENVELOPE_PREFIX_BYTES),
        payload.begin() + static_cast<std::ptrdiff_t>(
            REDDIT_ENVELOPE_HEADER_BYTES));
    envelope.encrypted_data.assign(
        payload.begin() + static_cast<std::ptrdiff_t>(
            REDDIT_ENVELOPE_HEADER_BYTES),
        payload.end());
    envelope.is_compressed =
        (flags & ENVELOPE_FLAG_COMPRESSED) != 0;
    return envelope;
}
