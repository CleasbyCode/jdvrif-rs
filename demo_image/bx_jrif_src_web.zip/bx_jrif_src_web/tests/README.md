# Split-interface regression tests

The fixtures and tests in this directory are self-contained. They verify both
web-variant executables rather than relying on the combined main-project CLI:

- `run_golden_tests.sh` recovers the five KDF5 golden fixtures with KEY files.
  `fixtures/golden` is a byte copy of the main project's `tests/golden`.
- `run_roundtrip_tests.sh` creates and recovers fresh KDF5 default, Bluesky,
  and Reddit images, including the ICC, Photoshop, XMP, and metadata-free C3
  DCT-carrier paths.
- `run_twitter_tests.sh` verifies source-derived quantization in the progressive
  JFIF J-UNIWARD/STC carrier, both `jdv_in capsize` platform routes, exact
  split-binary recovery with a KEY file, wrong-KEY rejection, and X-Twitter's
  5 MiB and 4096x4096 input limits.
  The carrier unit test also checks full-capacity recovery after embedding
  reduces the nonzero coefficient count, and rejects oversized declared payloads.
- `run_security_smoke.sh` covers authenticated compression semantics, wrong and
  oversized KEY files, truncated ciphertext, fixed ICC layout enforcement,
  transactional KEY delivery, the image being committed before the KEY is
  shown, the final Bluesky output limit, mode-specific JPEG quality, the
  default 4096x4096 ceiling, and transformation limits, signal cleanup,
  process hardening, dangling symlink collisions, escaped diagnostics, and the
  default recovery-cap wiggle room. Optional fixture generators are skipped
  when Pillow, FFmpeg, or ImageMagick is unavailable.
  It also runs the shared JPEG scan-limit, cancellation, codec-cleanup, and
  plaintext-wiping regressions, plus web-specific opened-file bounds and
  replacement tests. The web variant reads the KEY from a file, so the
  interactive terminal KEY tests of the combined CLI do not apply. Instead it
  checks the KEY file forms (grouped text `XXXX-XXXX-XXXX-XXXX-XXXX-XXXX`,
  ungrouped 24-character text, either with LF or CRLF line endings, and raw 16
  bytes), that a UTF-8 BOM, a check-character typo, a pre-v10 numeric PIN and
  its raw 8-byte form are all refused, and the shared KEY codec / carrier PRF /
  carrier key / Reddit carrier unit tests.

Only jdvrif v10 images (KDF5, RQSTEG3, JXSTEG4) are supported, as in the main
project. Images made before v10 need the legacy jdvrif release.

Run the complete suite with:

```sh
bash tests/run_tests.sh
```

To test binaries built elsewhere:

```sh
bash tests/run_tests.sh --no-build \
  --in-bin /path/to/jdv_in \
  --out-bin /path/to/jdv_out
```

The same paths can be supplied through `JDV_IN_BIN` and `JDV_OUT_BIN`.
