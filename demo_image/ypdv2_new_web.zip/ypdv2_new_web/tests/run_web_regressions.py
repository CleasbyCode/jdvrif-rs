#!/usr/bin/env python3
"""Exercise the web binaries against shared CLI fixtures and optional interop.

The KEY file is a .txt file of at most 64 bytes holding the recovery KEY as
printed, or exactly 16 raw bytes. The numeric PINs of images made before
pdvrdt 6.0 are refused, and so are those images. Tests use isolated temporary
directories and never write outputs beside the sources.
"""

import argparse
import csv
import os
import re
import stat
import struct
import subprocess
import tempfile
import zlib
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
MODES = (("default", ()), ("mastodon", ("-m",)), ("reddit", ("-r",)))
SYMLINK_FIXTURES = ("key_default_text", "key_mastodon_text", "reddit_v4_even_domain", "key_default_bin")
BASE58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
# A well-formed KEY belonging to none of the fixtures.
OTHER_KEY = "112d-rXXU-ifSr-RnXL-GbXg-8Eyf"
EXPECTED_GOLDEN = {
    "key_default_text", "key_default_bin", "key_default_stored",
    "key_mastodon_text", "key_mastodon_bin", "reddit_v4_even_domain",
    "reddit_v4_odd_domain", "pre_v6_default_text", "pre_v6_mastodon_text",
}
UNSUPPORTED = "Images made before pdvrdt 6.0 need the legacy pdvrdt release."
SANITIZER_MARKERS = (
    "AddressSanitizer", "LeakSanitizer", "UndefinedBehaviorSanitizer",
    "runtime error:",
)


def snapshot(path):
    info = path.lstat()
    metadata = (info.st_dev, info.st_ino, info.st_mode)
    if stat.S_ISLNK(info.st_mode):
        return metadata, os.readlink(path)
    if stat.S_ISDIR(info.st_mode):
        return metadata, {p.name: snapshot(p) for p in path.iterdir()}
    if stat.S_ISREG(info.st_mode):
        return metadata, path.read_bytes()
    raise AssertionError(f"unexpected file type: {path}")


def checked_run(command, work, *, succeeds=True, stdin=b"", web=True):
    before = {p.name: snapshot(p) for p in work.iterdir()}
    result = subprocess.run(
        [str(arg) for arg in command], cwd=work, input=stdin,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=45,
    )
    log = result.stdout.decode("utf-8", errors="replace")
    if any(marker in log for marker in SANITIZER_MARKERS):
        raise AssertionError(f"sanitizer diagnostic:\n{log}")
    if web and re.search(r"(?:^|\n)\s*KEY: ", log):
        raise AssertionError(f"web binary prompted for terminal input:\n{log}")
    for name, original in before.items():
        if snapshot(work / name) != original:
            raise AssertionError(f"existing input or output changed: {name}")
    created = {p.name for p in work.iterdir()} - before.keys()
    if (result.returncode == 0) != succeeds:
        raise AssertionError(f"unexpected exit {result.returncode}:\n{log}")
    if not succeeds and created:
        raise AssertionError(f"failed command left output: {created}")
    return log, created


def is_pre_v6(row):
    return row["kind"].startswith("pre_v6_")


def key_bytes(key):
    """The 16 raw bytes of a printed KEY (its 22-character Base58 body)."""
    value = 0
    for char in key.replace("-", "")[:22]:
        value = value * 58 + BASE58.index(char)
    return value.to_bytes(16, "big")


def recovered_file(work, created, payload, name):
    if created != {name}:
        raise AssertionError(f"expected only {name}, got {created}")
    output = work / name
    mode = output.lstat().st_mode
    if not stat.S_ISREG(mode) or stat.S_IMODE(mode) != 0o600:
        raise AssertionError("recovered output must be a regular file with mode 600")
    if output.read_bytes() != payload.read_bytes():
        raise AssertionError("recovered bytes differ from original payload")


class Suite:
    def __init__(self, args, base):
        self.args, self.base = args, base
        self.passed = self.failed = 0

    def case(self, name, function, *arguments):
        work = self.base / name
        work.mkdir()
        try:
            function(work, *arguments)
        except (AssertionError, OSError, ValueError, subprocess.TimeoutExpired) as error:
            self.failed += 1
            print(f"[FAIL] {name}: {error}", flush=True)
        else:
            self.passed += 1
            print(f"[PASS] {name}", flush=True)

    def hardening(self, work, binary, style):
        # The shared checks in src/tests: core dumps off, memory unreadable to
        # other processes, refusal warning, escaped program name.
        result = subprocess.run(
            ["python3", self.args.fixtures / "run_process_hardening_tests.py",
             "--bin", binary, "--style", style],
            cwd=work, capture_output=True, text=True, timeout=300)
        if result.returncode != 0:
            raise AssertionError(result.stdout + result.stderr)

    def recover(self, work, image, key, payload, *, name=None, cli=False, key_data=None):
        if cli:
            command = (self.args.cli_bin, "recover", image)
            log, created = checked_run(command, work, stdin=f"{key}\n".encode(), web=False)
        else:
            key_file = work / "key.txt"
            key_file.write_bytes(key_data if key_data is not None else f"{key}\n".encode())
            log, created = checked_run((self.args.out_bin, image, key_file), work)
        name = name or payload.name
        recovered_file(work, created, payload, name)
        if f"Writing output file...\n ✓ {name} (" not in log:
            raise AssertionError(f"recovery filename was not reported:\n{log}")

    def refused(self, work, row):
        """A pre-6.0 image is refused before its KEY file is even parsed."""
        key_file = work / "key.txt"
        key_file.write_bytes(f"{OTHER_KEY}\n".encode())
        image = self.args.fixtures / row["golden_rel"]
        log, _ = checked_run((self.args.out_bin, image, key_file), work, succeeds=False)
        if UNSUPPORTED not in log:
            raise AssertionError(f"expected {UNSUPPORTED!r}:\n{log}")

    def golden(self, work, row, key_data=None):
        self.recover(work, self.args.fixtures / row["golden_rel"], row["key"],
                     self.args.fixtures / row["payload_rel"], key_data=key_data)

    def conceal(self, work, cover, payload, options, *, cli=False):
        command = [self.args.cli_bin, "conceal"] if cli else [self.args.in_bin]
        log, created = checked_run(command + list(options) + [cover, payload], work, web=not cli)
        image_match = re.search(r'Saved "file-embedded" PNG image: (.+?) \(\d+ bytes\)', log)
        key_match = re.search(
            r"Recovery KEY: \[\*\*\*((?:[1-9A-HJ-NP-Za-km-z]{4}-){5}[1-9A-HJ-NP-Za-km-z]{4})\*\*\*\]", log)
        if not image_match or not key_match:
            raise AssertionError(f"missing saved filename or KEY:\n{log}")
        image = work / image_match.group(1)
        if created != {image.name} or not image.is_file():
            raise AssertionError(f"unexpected conceal output: {created}")
        return image, key_match.group(1)

    def roundtrip(self, work, options):
        cover = self.args.fixtures / "testdata/covers/cover.png"
        payload = self.args.fixtures / "testdata/payloads/payload_text.txt"
        embed = work / "web_embed"
        embed.mkdir()
        image, key = self.conceal(embed, cover, payload, options)
        web_recover = work / "web_recover"
        web_recover.mkdir()
        self.recover(web_recover, image, key, payload)
        if self.args.cli_bin:
            cli_recover = work / "cli_recover"
            cli_recover.mkdir()
            self.recover(cli_recover, image, key, payload, cli=True)
            cli_embed = work / "cli_embed"
            cli_embed.mkdir()
            image, key = self.conceal(cli_embed, cover, payload, options, cli=True)
            web_interop = work / "web_interop"
            web_interop.mkdir()
            self.recover(web_interop, image, key, payload)

    def invalid_key(self, work, row, data, expected_error):
        key_file = work / "key.txt"
        key_file.write_bytes(data)
        image = self.args.fixtures / row["golden_rel"]
        log, _ = checked_run((self.args.out_bin, image, key_file), work, succeeds=False)
        if expected_error not in log:
            raise AssertionError(f"expected {expected_error!r}:\n{log}")

    def symlink(self, work, row, scenario):
        payload = self.args.fixtures / row["payload_rel"]
        base = work / payload.name
        first = work / f"{base.stem}_1{base.suffix}"
        if scenario == "dangling_suffix":
            base.write_bytes(b"preserve this existing file\x00\xff")
            first.symlink_to("absent-target")
            name = f"{base.stem}_2{base.suffix}"
        else:
            base.symlink_to(base.name if scenario == "loop" else "absent-target")
            name = first.name
        self.recover(work, self.args.fixtures / row["golden_rel"], row["key"], payload, name=name)

    def malformed(self, work, image, options, error):
        payload = self.args.fixtures / "testdata/payloads/payload_text.txt"
        arguments = ("capsize", image) if options is None else (*options, image, payload)
        log, _ = checked_run((self.args.in_bin, *arguments), work, succeeds=False)
        if error not in log:
            raise AssertionError(f"expected {error!r}:\n{log}")


def png_chunk(kind, body):
    return struct.pack(">I", len(body)) + kind + body + struct.pack(">I", zlib.crc32(kind + body))


def malformed_images(base):
    def png(path, color, pixels, palette=None):
        ihdr = struct.pack(">IIBBBBB", 1, 1, 8, color, 0, 0, 0)
        data = b"\x89PNG\r\n\x1a\n" + png_chunk(b"IHDR", ihdr)
        if palette is not None:
            data += png_chunk(b"PLTE", palette)
        path.write_bytes(data + png_chunk(b"IDAT", zlib.compress(pixels)) + png_chunk(b"IEND", b""))

    palette = base / "bad_palette.png"
    png(palette, 3, b"\x00\x00", bytes(4))
    oversized = base / "oversized_scanline.png"
    png(oversized, 6, bytes(4 * 1024 * 1024))
    return (("palette", palette, "invalid PLTE size"),
            ("scanline_bound", oversized, "109"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--in-bin", type=Path, default=ROOT / "pdv_in")
    parser.add_argument("--out-bin", type=Path, default=ROOT / "pdv_out")
    parser.add_argument("--cli-bin", type=Path, help="also check both CLI interoperability directions")
    parser.add_argument("--fixtures", type=Path, default=ROOT.parent / "src/tests")
    args = parser.parse_args()
    for attr in ("in_bin", "out_bin", "cli_bin"):
        binary = getattr(args, attr)
        if binary is not None:
            binary = binary.resolve()
            if not binary.is_file() or not os.access(binary, os.X_OK):
                parser.error(f"binary missing or not executable: {binary}")
            setattr(args, attr, binary)
    args.fixtures = args.fixtures.resolve()
    try:
        with (args.fixtures / "golden/manifest.tsv").open(newline="") as manifest:
            rows = list(csv.DictReader(manifest, delimiter="\t"))
        fixtures = {row["case_id"]: row for row in rows}
        if len(fixtures) != len(rows) or set(fixtures) != EXPECTED_GOLDEN:
            parser.error(f"golden manifest must contain each of the {len(EXPECTED_GOLDEN)} expected cases exactly once")
        for row in rows:
            for column in ("payload_rel", "golden_rel"):
                if not (args.fixtures / row[column]).is_file():
                    parser.error(f"fixture missing: {row[column]}")
    except (OSError, KeyError) as error:
        parser.error(f"cannot load golden fixtures: {error}")

    with tempfile.TemporaryDirectory(prefix="pdvrdt-web-tests-") as temporary:
        base = Path(temporary)
        suite = Suite(args, base)
        for row in rows:
            if is_pre_v6(row):
                suite.case("golden_" + row["case_id"], suite.refused, row)
            else:
                suite.case("golden_" + row["case_id"], suite.golden, row)
        for mode, options in MODES:
            suite.case("roundtrip_" + mode, suite.roundtrip, options)
        for row in rows:
            if not is_pre_v6(row):
                # The raw form: exactly the 16 KEY bytes.
                suite.case("golden_raw_" + row["case_id"], suite.golden, row, key_bytes(row["key"]))
        for case_id in SYMLINK_FIXTURES:
            row = fixtures[case_id]
            key = row["key"]
            invalid = "KEY File Error: Invalid file contents."
            wrong = ("Invalid recovery KEY, or this is not a pdvrdt image" if row["kind"] == "reddit"
                     else "Invalid recovery KEY or file is corrupt")
            typo = key[:-1] + ("Q" if key[-1] != "Q" else "R")
            cases = [
                ("empty", b"", "Error"),
                ("oversized", b"1" * 65, "KEY File Error: File exceeds the 64-byte size limit."),
                ("letters", b"not a key\n", invalid),
                ("short", key[:-1].encode(), invalid),
                ("typo", typo.encode(), "KEY Entry Error: That KEY has a typo"),
                ("other_key", OTHER_KEY.encode(), wrong),
                # The numeric PIN of a pre-6.0 image, as text and as the raw
                # 8 big-endian bytes earlier web pages wrote: neither is a KEY.
                ("numeric_pin", b"10479510958359240708\n", invalid),
                ("raw8_pin", (10479510958359240708).to_bytes(8, "big"), invalid),
            ]
            for label, data, error in cases:
                suite.case(f"key_{case_id}_{label}", suite.invalid_key, row, data, error)
            for scenario in ("dangling_base", "dangling_suffix", "loop"):
                suite.case(f"symlink_{case_id}_{scenario}", suite.symlink, row, scenario)
        for label, image, error in malformed_images(base):
            for mode, options in (*MODES, ("capsize", None)):
                suite.case(f"malformed_{label}_{mode}", suite.malformed, image, options, error)
        suite.case("hardening_pdv_in", suite.hardening, args.in_bin, "web-in")
        suite.case("hardening_pdv_out", suite.hardening, args.out_bin, "web-out")
        print(f"Web regression checks: {suite.passed} passed, {suite.failed} failed.")
        if not args.cli_bin:
            print("CLI interoperability skipped (pass --cli-bin to enable).")
        return bool(suite.failed)


if __name__ == "__main__":
    raise SystemExit(main())
