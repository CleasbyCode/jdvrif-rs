#include "recover.h"
#include "recover_internal.h"
#include "embedded_layout.h"
#include "file_utils.h"
#include "encryption.h"
#include "recover_modes.h"
#include "reddit_steg.h"
#include "twitter_steg.h"

#include <algorithm>
#include <array>
#include <fstream>
#include <optional>
#include <span>
#include <stdexcept>

namespace {
// jdvrif always writes the ICC template at file offset 0, so the profile and
// jdvrif signatures can only ever sit at two fixed absolute offsets -- which is
// exactly what recoverFromIccPath re-checks before it will use the layout.
// Verifying them in place costs one short read; scanning for them costs a pass
// over an input that may be gigabytes and can never accept a hit anywhere else.
[[nodiscard]] bool hasEmbeddedIccProfile(const fs::path& image_file_path, std::size_t image_file_size) {
    constexpr std::size_t PREFIX_BYTES =
        DEFAULT_JDVRIF_SIGNATURE_INDEX_ABS + JDVRIF_SIGNATURE.size();
    static_assert(DEFAULT_ICC_SIGNATURE_INDEX_ABS + ICC_PROFILE_SIGNATURE.size() <= PREFIX_BYTES);

    if (image_file_size < PREFIX_BYTES) return false;

    std::array<Byte, PREFIX_BYTES> prefix{};
    std::ifstream input = openBinaryInputOrThrow(image_file_path, "Read Error: Failed to open image file.");
    readExactAt(input, 0, std::span<Byte>(prefix));

    return std::equal(
               ICC_PROFILE_SIGNATURE.begin(), ICC_PROFILE_SIGNATURE.end(),
               prefix.begin() + static_cast<std::ptrdiff_t>(DEFAULT_ICC_SIGNATURE_INDEX_ABS)) &&
           std::equal(
               JDVRIF_SIGNATURE.begin(), JDVRIF_SIGNATURE.end(),
               prefix.begin() + static_cast<std::ptrdiff_t>(DEFAULT_JDVRIF_SIGNATURE_INDEX_ABS));
}

[[nodiscard]] std::optional<std::size_t> findBlueskyHeaderSignature(
    const fs::path& image_file_path,
    std::size_t image_file_size) {

    const std::size_t header_search_limit = std::min(
        image_file_size,
        BLUESKY_CIPHER_LAYOUT.encrypted_payload_start_index);
    return findSignatureInFile(image_file_path, JDVRIF_SIGNATURE, header_search_limit, 0);
}
} // namespace

void recoverData(const fs::path& image_file_path, vBytes& pin_vec) {
    const std::size_t image_file_size = validateFileForRead(image_file_path, FileTypeCheck::embedded_image);
    if (hasEmbeddedIccProfile(image_file_path, image_file_size)) {
        recoverFromIccPath(image_file_path, image_file_size, DEFAULT_ICC_SIGNATURE_INDEX_ABS, pin_vec);
        return;
    }

    if (auto jdvrif_sig_opt = findBlueskyHeaderSignature(image_file_path, image_file_size)) {
        recoverFromBlueskyPath(image_file_path, image_file_size, *jdvrif_sig_opt, pin_vec);
        return;
    }

    // Reddit and X-Twitter strip APP metadata, so their jdvrif identities live
    // in keyed DCT-carried headers plus inner JDVRIFR1/JDVRIFX2 encrypted
    // envelopes. Keep this last so metadata formats retain their established
    // priority, and bound the whole-image read to Reddit's larger upload limit.
    //
    // This format cannot follow the "validate declared size, then key, then
    // extract" ordering the ICC and Bluesky paths use: the carrier's coefficient
    // positions derive from the recovery PIN, so nothing can be located without
    // it. A wrong PIN and an image with no carrier therefore share one message.
    // That hides where a payload is, not whether one exists -- see
    // reddit_steg.cpp on what statistical steganalysis can still see.
    //
    // The current carrier key is Argon2id-derived, so testing a PIN guess
    // against the carrier costs as much as testing it against the envelope.
    // Images written by v9.0 are still read with the cheap legacy key.
    //
    // Deriving the keys first also means a hostile image cannot make this
    // process decode a carrier under anything but the supplied PIN. The work is
    // still bounded once it starts: each codec caps dimensions/coefficient
    // counts, each carrier caps its declared payload against coefficient
    // capacity, and the platform upload limits cap the read below. Keep those
    // caps in mind before raising any of them.
    if (image_file_size <= REDDIT_UPLOAD_SIZE_LIMIT) {
        CarrierKeys carrier_keys = deriveCarrierKeysFromPinFile(pin_vec);
        WipePodGuard<CarrierKeys> carrier_keys_wipe{carrier_keys};
        const vBytes image = readFile(
            image_file_path,
            FileTypeCheck::embedded_image,
            REDDIT_UPLOAD_SIZE_LIMIT);

        if (image.size() <= TWITTER_UPLOAD_SIZE_LIMIT) {
            if (auto envelope = extractTwitterEnvelope(image, carrier_keys)) {
                recoverFromTwitterPath(std::move(*envelope), pin_vec);
                return;
            }
        }
        if (auto envelope = extractRedditEnvelope(image, carrier_keys)) {
            recoverFromRedditPath(std::move(*envelope), pin_vec);
            return;
        }
        throw std::runtime_error(
            "File Extraction Error: Invalid PIN, or this is not a valid jdvrif \"file-embedded\" image.");
    }

    throw std::runtime_error("Image File Error: Signature check failure. This is not a valid jdvrif \"file-embedded\" image.");
}
