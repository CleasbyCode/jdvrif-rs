#!/usr/bin/env python3
"""Exercise the web binaries against shared CLI fixtures and optional interop.

The PIN file interface is exactly eight big-endian bytes in a .txt file. Tests
use isolated temporary directories and never write outputs beside the sources.
"""

import argparse
import csv
import os
import re
import stat
import struct
import subprocess
import tempfile
import zlib
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
MODES = (("default", ()), ("mastodon", ("-m",)), ("reddit", ("-r",)))
SYMLINK_FIXTURES = ("default_text", "mastodon_text", "reddit_v2_even_domain")
EXPECTED_GOLDEN = {
    "default_text", "default_bin", "default_stored", "mastodon_text",
    "mastodon_bin", "reddit_even_domain", "reddit_odd_domain",
    "legacy_padded_text", "legacy_padded_bin", "reddit_v2_even_domain",
    "reddit_v2_odd_domain",
}
SANITIZER_MARKERS = (
    "AddressSanitizer", "LeakSanitizer", "UndefinedBehaviorSanitizer",
    "runtime error:",
)


def snapshot(path):
    info = path.lstat()
    metadata = (info.st_dev, info.st_ino, info.st_mode)
    if stat.S_ISLNK(info.st_mode):
        return metadata, os.readlink(path)
    if stat.S_ISDIR(info.st_mode):
        return metadata, {p.name: snapshot(p) for p in path.iterdir()}
    if stat.S_ISREG(info.st_mode):
        return metadata, path.read_bytes()
    raise AssertionError(f"unexpected file type: {path}")


def checked_run(command, work, *, succeeds=True, stdin=b"", web=True):
    before = {p.name: snapshot(p) for p in work.iterdir()}
    result = subprocess.run(
        [str(arg) for arg in command], cwd=work, input=stdin,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=45,
    )
    log = result.stdout.decode("utf-8", errors="replace")
    if any(marker in log for marker in SANITIZER_MARKERS):
        raise AssertionError(f"sanitizer diagnostic:\n{log}")
    if web and re.search(r"(?:^|\n)\s*PIN: ", log):
        raise AssertionError(f"web binary prompted for terminal input:\n{log}")
    for name, original in before.items():
        if snapshot(work / name) != original:
            raise AssertionError(f"existing input or output changed: {name}")
    created = {p.name for p in work.iterdir()} - before.keys()
    if (result.returncode == 0) != succeeds:
        raise AssertionError(f"unexpected exit {result.returncode}:\n{log}")
    if not succeeds and created:
        raise AssertionError(f"failed command left output: {created}")
    return log, created


def recovered_file(work, created, payload, name):
    if created != {name}:
        raise AssertionError(f"expected only {name}, got {created}")
    output = work / name
    mode = output.lstat().st_mode
    if not stat.S_ISREG(mode) or stat.S_IMODE(mode) != 0o600:
        raise AssertionError("recovered output must be a regular file with mode 600")
    if output.read_bytes() != payload.read_bytes():
        raise AssertionError("recovered bytes differ from original payload")


class Suite:
    def __init__(self, args, base):
        self.args, self.base = args, base
        self.passed = self.failed = 0

    def case(self, name, function, *arguments):
        work = self.base / name
        work.mkdir()
        try:
            function(work, *arguments)
        except (AssertionError, OSError, ValueError, subprocess.TimeoutExpired) as error:
            self.failed += 1
            print(f"[FAIL] {name}: {error}", flush=True)
        else:
            self.passed += 1
            print(f"[PASS] {name}", flush=True)

    def recover(self, work, image, pin, payload, *, name=None, cli=False):
        if cli:
            command = (self.args.cli_bin, "recover", image)
            log, created = checked_run(command, work, stdin=f"{pin}\n".encode(), web=False)
        else:
            pin_file = work / "pin.txt"
            pin_file.write_bytes(int(pin).to_bytes(8, "big"))
            log, created = checked_run((self.args.out_bin, image, pin_file), work)
        name = name or payload.name
        recovered_file(work, created, payload, name)
        if f"Extracted hidden file: {name} (" not in log:
            raise AssertionError(f"recovery filename was not reported:\n{log}")

    def golden(self, work, row):
        self.recover(work, self.args.fixtures / row["golden_rel"], row["pin"],
                     self.args.fixtures / row["payload_rel"])

    def conceal(self, work, cover, payload, options, *, cli=False):
        command = [self.args.cli_bin, "conceal"] if cli else [self.args.in_bin]
        log, created = checked_run(command + list(options) + [cover, payload], work, web=not cli)
        image_match = re.search(r'Saved "file-embedded" PNG image: (.+?) \(\d+ bytes\)', log)
        pin_match = re.search(r"Recovery PIN: \[\*\*\*(\d+)\*\*\*\]", log)
        if not image_match or not pin_match:
            raise AssertionError(f"missing saved filename or PIN:\n{log}")
        image = work / image_match.group(1)
        if created != {image.name} or not image.is_file():
            raise AssertionError(f"unexpected conceal output: {created}")
        return image, pin_match.group(1)

    def roundtrip(self, work, options):
        cover = self.args.fixtures / "testdata/covers/cover.png"
        payload = self.args.fixtures / "testdata/payloads/payload_text.txt"
        embed = work / "web_embed"
        embed.mkdir()
        image, pin = self.conceal(embed, cover, payload, options)
        web_recover = work / "web_recover"
        web_recover.mkdir()
        self.recover(web_recover, image, pin, payload)
        if self.args.cli_bin:
            cli_recover = work / "cli_recover"
            cli_recover.mkdir()
            self.recover(cli_recover, image, pin, payload, cli=True)
            cli_embed = work / "cli_embed"
            cli_embed.mkdir()
            image, pin = self.conceal(cli_embed, cover, payload, options, cli=True)
            web_interop = work / "web_interop"
            web_interop.mkdir()
            self.recover(web_interop, image, pin, payload)

    def invalid_pin(self, work, row, data, expected_error):
        pin_file = work / "pin.txt"
        pin_file.write_bytes(data)
        image = self.args.fixtures / row["golden_rel"]
        log, _ = checked_run((self.args.out_bin, image, pin_file), work, succeeds=False)
        if expected_error not in log:
            raise AssertionError(f"expected {expected_error!r}:\n{log}")

    def symlink(self, work, row, scenario):
        payload = self.args.fixtures / row["payload_rel"]
        base = work / payload.name
        first = work / f"{base.stem}_1{base.suffix}"
        if scenario == "dangling_suffix":
            base.write_bytes(b"preserve this existing file\x00\xff")
            first.symlink_to("absent-target")
            name = f"{base.stem}_2{base.suffix}"
        else:
            base.symlink_to(base.name if scenario == "loop" else "absent-target")
            name = first.name
        self.recover(work, self.args.fixtures / row["golden_rel"], row["pin"], payload, name=name)

    def malformed(self, work, image, options, error):
        payload = self.args.fixtures / "testdata/payloads/payload_text.txt"
        arguments = ("capsize", image) if options is None else (*options, image, payload)
        log, _ = checked_run((self.args.in_bin, *arguments), work, succeeds=False)
        if error not in log:
            raise AssertionError(f"expected {error!r}:\n{log}")


def png_chunk(kind, body):
    return struct.pack(">I", len(body)) + kind + body + struct.pack(">I", zlib.crc32(kind + body))


def malformed_images(base):
    def png(path, color, pixels, palette=None):
        ihdr = struct.pack(">IIBBBBB", 1, 1, 8, color, 0, 0, 0)
        data = b"\x89PNG\r\n\x1a\n" + png_chunk(b"IHDR", ihdr)
        if palette is not None:
            data += png_chunk(b"PLTE", palette)
        path.write_bytes(data + png_chunk(b"IDAT", zlib.compress(pixels)) + png_chunk(b"IEND", b""))

    palette = base / "bad_palette.png"
    png(palette, 3, b"\x00\x00", bytes(4))
    oversized = base / "oversized_scanline.png"
    png(oversized, 6, bytes(4 * 1024 * 1024))
    return (("palette", palette, "invalid PLTE size"),
            ("scanline_bound", oversized, "109"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--in-bin", type=Path, default=ROOT / "pdv_in")
    parser.add_argument("--out-bin", type=Path, default=ROOT / "pdv_out")
    parser.add_argument("--cli-bin", type=Path, help="also check both CLI interoperability directions")
    parser.add_argument("--fixtures", type=Path, default=ROOT.parent / "src/tests")
    args = parser.parse_args()
    for attr in ("in_bin", "out_bin", "cli_bin"):
        binary = getattr(args, attr)
        if binary is not None:
            binary = binary.resolve()
            if not binary.is_file() or not os.access(binary, os.X_OK):
                parser.error(f"binary missing or not executable: {binary}")
            setattr(args, attr, binary)
    args.fixtures = args.fixtures.resolve()
    try:
        with (args.fixtures / "golden/manifest.tsv").open(newline="") as manifest:
            rows = list(csv.DictReader(manifest, delimiter="\t"))
        fixtures = {row["case_id"]: row for row in rows}
        if len(fixtures) != len(rows) or set(fixtures) != EXPECTED_GOLDEN:
            parser.error("golden manifest must contain each of the 11 expected cases exactly once")
        for row in rows:
            for key in ("payload_rel", "golden_rel"):
                if not (args.fixtures / row[key]).is_file():
                    parser.error(f"fixture missing: {row[key]}")
    except (OSError, KeyError) as error:
        parser.error(f"cannot load golden fixtures: {error}")

    with tempfile.TemporaryDirectory(prefix="pdvrdt-web-tests-") as temporary:
        base = Path(temporary)
        suite = Suite(args, base)
        for row in rows:
            suite.case("golden_" + row["case_id"], suite.golden, row)
        for mode, options in MODES:
            suite.case("roundtrip_" + mode, suite.roundtrip, options)
        for case_id in SYMLINK_FIXTURES:
            row = fixtures[case_id]
            pin = int(row["pin"])
            valid = pin.to_bytes(8, "big")
            for label, data in (("short", valid[:7]), ("long", valid + b"\0"),
                                ("decimal", str(pin).encode())):
                suite.case(f"pin_{case_id}_{label}", suite.invalid_pin, row, data,
                           "PIN File Error: Invalid file size")
            suite.case(f"pin_{case_id}_wrong", suite.invalid_pin, row,
                       (pin ^ 1).to_bytes(8, "big"), "Invalid PIN")
            for scenario in ("dangling_base", "dangling_suffix", "loop"):
                suite.case(f"symlink_{case_id}_{scenario}", suite.symlink, row, scenario)
        for label, image, error in malformed_images(base):
            for mode, options in (*MODES, ("capsize", None)):
                suite.case(f"malformed_{label}_{mode}", suite.malformed, image, options, error)
        print(f"Web regression checks: {suite.passed} passed, {suite.failed} failed.")
        if not args.cli_bin:
            print("CLI interoperability skipped (pass --cli-bin to enable).")
        return bool(suite.failed)


if __name__ == "__main__":
    raise SystemExit(main())
