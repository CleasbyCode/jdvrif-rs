#!/usr/bin/env bash
set -euo pipefail

CXX="${CXX:-g++}"

# libwebp must come from pkg-config. There is deliberately no fallback path:
# guessing a location (especially a predictable, world-writable one under
# /tmp) would let another local user plant headers or a library into the build.
if ! command -v pkg-config >/dev/null 2>&1; then
  echo "Missing required build tool: pkg-config" >&2
  exit 1
fi
if ! pkg-config --exists libwebp; then
  echo "Build error: pkg-config could not find libwebp." >&2
  echo "Install the libwebp development package or set PKG_CONFIG_PATH to its .pc file." >&2
  exit 1
fi
WEBP_CFLAGS_STR="$(pkg-config --cflags libwebp)"
WEBP_LIBDIR_STR="$(pkg-config --libs-only-L libwebp)"

WEBP_CFLAGS=()
WEBP_LDFLAGS=()
if [[ -n "$WEBP_CFLAGS_STR" ]]; then
  read -r -a WEBP_CFLAGS <<< "$WEBP_CFLAGS_STR"
fi
if [[ -n "$WEBP_LIBDIR_STR" ]]; then
  read -r -a WEBP_LDFLAGS <<< "$WEBP_LIBDIR_STR"
fi

CXXFLAGS=(
  -std=c++23
  -Wall -Wextra -Wpedantic -Wshadow -Wconversion -Wformat -Wformat-security
  # -march=native tunes and emits instructions for THIS machine's CPU (e.g. AVX2,
  # SSSE3). The resulting binary is NOT redistributable: running it on an
  # older/different CPU can fail with "Illegal instruction" (SIGILL). wpdv_in is
  # meant to be built from source on the machine that runs it. If you must ship a
  # portable binary, replace this with a baseline arch (e.g. -march=x86-64-v2) or
  # use -mtune=native for portable codegen; the base64 SIMD tier in base64.cpp is
  # selected at compile time from these flags, so a baseline arch simply falls
  # back to the SSSE3 or scalar kernel.
  -march=native
  -D_FORTIFY_SOURCE=3 -D_GLIBCXX_ASSERTIONS
  -O3 -pipe
  -fstack-protector-strong -fstack-clash-protection -fcf-protection=full -fPIE
  -s -flto=auto -DNDEBUG
)
if [[ ${#WEBP_CFLAGS[@]} -gt 0 ]]; then
  CXXFLAGS+=( "${WEBP_CFLAGS[@]}" )
fi

LDFLAGS=(
  -pie -Wl,-z,relro,-z,now,-z,noexecstack,-z,separate-code
)
if [[ ${#WEBP_LDFLAGS[@]} -gt 0 ]]; then
  LDFLAGS+=( "${WEBP_LDFLAGS[@]}" )
fi

SOURCES=(
  args_in.cpp
  main_wpdv_in.cpp
  conceal.cpp
  compression.cpp
  encryption.cpp
  image.cpp
  io_utils.cpp
  base64.cpp
)

LIBS=( -lsodium -lz -ldeflate -lwebp )

echo "Compiling wpdv_in..."
"$CXX" "${CXXFLAGS[@]}" "${SOURCES[@]}" "${LDFLAGS[@]}" "${LIBS[@]}" -o wpdv_in
echo "Compilation successful. Executable 'wpdv_in' created."
