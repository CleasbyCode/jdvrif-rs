#include "args_in.h"

#include <format>
#include <stdexcept>
#include <string_view>

namespace {

[[nodiscard]] std::string_view argAt(int argc, char** argv, int i) {
	if (i < 0 || i >= argc) {
		return {};
	}
	const char* const s = argv[i];
	return s ? std::string_view{s} : std::string_view{};
}

[[nodiscard]] std::string programName(int argc, char** argv) {
	if (argc >= 1 && argv[0] != nullptr) {
		return fs::path(argv[0]).filename().string();
	}
	return "pdv_in";
}

[[nodiscard]] std::string buildUsage(std::string_view prog) {
	return std::format("Usage: {} [-m|-r] <cover_image> <secret_file>", prog);
}

[[noreturn]] void dieUsage(const std::string& usage) {
	throw std::runtime_error(usage);
}

} // namespace

ProgramArgs ProgramArgs::parse(int argc, char** argv) {
	const std::string usage = buildUsage(programName(argc, argv));
	ProgramArgs out{};
	int i = 1;

	const std::string_view platform_option = argAt(argc, argv, i);
	if (platform_option == "-m" || platform_option == "-r") {
		out.option = (platform_option == "-m") ? Option::Mastodon : Option::Reddit;
		++i;
	}

	if (argc != i + 2 || argAt(argc, argv, i).empty() || argAt(argc, argv, i + 1).empty()) {
		dieUsage(usage);
	}

	out.image_file_path = argAt(argc, argv, i);
	out.data_file_path = argAt(argc, argv, i + 1);
	return out;
}
