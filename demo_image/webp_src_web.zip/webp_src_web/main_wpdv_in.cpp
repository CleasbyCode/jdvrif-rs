// WEBP Data Vehicle (wpdv_in) Created by Nicholas Cleasby (@CleasbyCode) 13/11/2024

#include "args_in.h"
#include "conceal.h"
#include "io_utils.h"

#include <iostream>
#include <print>
#include <stdexcept>

int main(int argc, char** argv) {
	try {
		if (sodium_init() < 0) {
			throw std::runtime_error("Libsodium initialization failed!");
		}

		auto args = ProgramArgs::parse(argc, argv);

		vBytes image_vec = readFile(args.image_file_path, FileTypeCheck::cover_image);
		concealData(image_vec, args.option, args.data_file_path);
	}
	catch (const std::exception& e) {
		std::println(std::cerr, "\n{}\n", e.what());
		return 1;
	}
	return 0;
}
