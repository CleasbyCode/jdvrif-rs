#include "args_in.h"

#include <format>
#include <stdexcept>
#include <string_view>

void ProgramArgs::die(const std::string& usage) {
	throw std::runtime_error(usage);
}

ProgramArgs ProgramArgs::parse(int argc, char** argv) {
	const auto arg = [&](int i) -> std::string_view {
		return (i >= 0 && i < argc) ? argv[i] : std::string_view{};
	};

	const std::string
		prog = fs::path(argv[0]).filename().string(),
		usage = std::format("Usage: {} [-b] <cover_image> <secret_file>", prog);

	ProgramArgs out{};
	int i = 1;

	if (i < argc && arg(i) == "-b") {
		out.option = Option::Bluesky;
		++i;
	}

	if (i + 2 != argc || arg(i).empty() || arg(i + 1).empty()) die(usage);

	out.image_file_path = arg(i);
	out.data_file_path = arg(i + 1);
	return out;
}
