#pragma once

#include "file_utils.h"

#include <cstddef>
#include <string>

[[nodiscard]] fs::path validatedRecoveryPath(std::string decrypted_filename);
[[nodiscard]] fs::path commitRecoveredOutput(const StagingFile& staged_file, const fs::path& base_output_path);
void printRecoveryComplete();
