#include "encryption.h"
#include "io_utils.h"
#include <algorithm>
#include <array>
#include <bit>
#include <charconv>
#include <cstring>
#include <limits>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string_view>
namespace {

constexpr auto KDF_METADATA_MAGIC_V2 =
    std::to_array<Byte>({'K', 'D', 'F', '2'});
constexpr auto KDF_METADATA_MAGIC_V3 =
    std::to_array<Byte>({'K', 'D', 'F', '3'});
constexpr std::size_t KDF_MAGIC_OFFSET = 0;
constexpr std::size_t KDF_ALG_OFFSET = 4;
constexpr std::size_t KDF_SENTINEL_OFFSET = 5;
constexpr std::size_t KDF_PARAMETER_ENCODING_OFFSET = 6;
constexpr std::size_t KDF_FLAGS_OFFSET = 7;
constexpr std::size_t KDF_SALT_OFFSET = 8;
constexpr std::size_t KDF_NONCE_OFFSET = 24;
constexpr std::size_t KDF_OPSLIMIT_OFFSET = 48;
constexpr std::size_t KDF_MEMLIMIT_KIB_OFFSET = 52;
constexpr Byte KDF_ALG_ARGON2ID13 = 1;
constexpr Byte KDF_SENTINEL = 0xA5;
constexpr Byte KDF_PARAMETER_ENCODING_BE32 = 1;
constexpr Byte KDF_FLAGS_NONE = 0;

// KDF2 files were created with libsodium's Argon2id "interactive" preset.
// Record the historical numeric values here rather than consulting the
// mutable convenience macros during recovery.  KDF3 stores and validates the
// same numeric values in its metadata, so future library preset changes cannot
// change the on-disk format.
constexpr unsigned long long KDF_ARGON2ID13_OPSLIMIT = 2;
constexpr std::uint32_t KDF_ARGON2ID13_MEMLIMIT_KIB = 64 * 1024;
constexpr std::size_t KDF_ARGON2ID13_MEMLIMIT =
    static_cast<std::size_t>(KDF_ARGON2ID13_MEMLIMIT_KIB) * 1024;
static_assert(KDF_ARGON2ID13_OPSLIMIT >= crypto_pwhash_OPSLIMIT_MIN);
static_assert(KDF_ARGON2ID13_OPSLIMIT <= crypto_pwhash_OPSLIMIT_MAX);
static_assert(KDF_ARGON2ID13_MEMLIMIT >= crypto_pwhash_MEMLIMIT_MIN);
static_assert(KDF_ARGON2ID13_MEMLIMIT <= crypto_pwhash_MEMLIMIT_MAX);
static_assert(KDF_MEMLIMIT_KIB_OFFSET + sizeof(std::uint32_t) ==
              KDF_METADATA_REGION_BYTES);

// These fields must stay gap-free so writeKdfMetadata never publishes
// uninitialized bytes.
static_assert(KDF_MAGIC_OFFSET + KDF_METADATA_MAGIC_V3.size() ==
              KDF_ALG_OFFSET);
static_assert(KDF_ALG_OFFSET + 1 == KDF_SENTINEL_OFFSET);
static_assert(KDF_SENTINEL_OFFSET + 1 == KDF_PARAMETER_ENCODING_OFFSET);
static_assert(KDF_PARAMETER_ENCODING_OFFSET + 1 == KDF_FLAGS_OFFSET);
static_assert(KDF_FLAGS_OFFSET + 1 == KDF_SALT_OFFSET);
static_assert(KDF_SALT_OFFSET + crypto_pwhash_SALTBYTES == KDF_NONCE_OFFSET);
static_assert(KDF_NONCE_OFFSET +
                  crypto_secretstream_xchacha20poly1305_HEADERBYTES ==
              KDF_OPSLIMIT_OFFSET);
static_assert(KDF_OPSLIMIT_OFFSET + sizeof(std::uint32_t) ==
              KDF_MEMLIMIT_KIB_OFFSET);

constexpr const char *CORRUPT_PROFILE_ERROR =
    "Internal Error: Corrupt profile template.";
constexpr const char *CORRUPT_FILE_ERROR =
    "File Recovery Error: Embedded profile is corrupt.";

// Zeroed-on-destruction holder for a trivially-copyable secret (the derived
// key, the secretstream state). Non-copyable so a secret can never be
// duplicated into an unguarded object.
template <class T> struct Sensitive {
  static_assert(std::is_trivially_copyable_v<T>);
  T value{};

  Sensitive() = default;
  ~Sensitive() { sodium_memzero(&value, sizeof(value)); }
  Sensitive(const Sensitive &) = delete;
  Sensitive &operator=(const Sensitive &) = delete;
};

constexpr std::size_t STREAM_CHUNK_SIZE = 1 * 1024 * 1024;
constexpr std::size_t STREAM_FRAME_LEN_BYTES = 4;
using StreamHeader =
    std::array<Byte, crypto_secretstream_xchacha20poly1305_HEADERBYTES>;
constexpr std::size_t MAX_FILENAME_PREFIX_BYTES =
    1 + static_cast<std::size_t>(std::numeric_limits<Byte>::max());
using FilenamePrefixStorage = std::array<Byte, MAX_FILENAME_PREFIX_BYTES>;

struct FilenamePrefixBuffer {
  FilenamePrefixStorage bytes;
  std::size_t size{0};

  FilenamePrefixBuffer(const FilenamePrefixBuffer &) = delete;
  FilenamePrefixBuffer &operator=(const FilenamePrefixBuffer &) = delete;
  FilenamePrefixBuffer() = default;

  ~FilenamePrefixBuffer() {
    if (size != 0) {
      sodium_memzero(bytes.data(), size);
    }
  }

  [[nodiscard]] std::span<const Byte> span() const noexcept {
    return {bytes.data(), size};
  }
};

[[nodiscard]] std::size_t
computeStreamEncryptedSize(std::size_t plaintext_size) {
  const std::size_t chunks =
      (plaintext_size == 0) ? 1
                            : ((plaintext_size - 1) / STREAM_CHUNK_SIZE) + 1;
  const std::size_t per_chunk_overhead =
      STREAM_FRAME_LEN_BYTES + crypto_secretstream_xchacha20poly1305_ABYTES;
  constexpr std::size_t header_size = StreamHeader{}.size();
  if (plaintext_size > std::numeric_limits<std::size_t>::max() - header_size ||
      chunks > (std::numeric_limits<std::size_t>::max() - header_size -
                plaintext_size) /
                   per_chunk_overhead) {
    throw std::runtime_error(
        "Data File Error: Data file too large to encrypt.");
  }
  return header_size + plaintext_size + (chunks * per_chunk_overhead);
}

void writeFrameLen(vBytes &out, std::uint32_t frame_len) {
  const std::size_t offset = out.size();
  out.resize(offset + STREAM_FRAME_LEN_BYTES);
  writeBe32At(out, offset, frame_len);
}

constexpr std::string_view ENCRYPTED_TOO_LARGE_ERROR =
    "Data File Error: Encrypted data is too large.";

// Encrypt prefix||body into output_vec (appended). On exit, body is zeroed and
// cleared. Writing directly to output_vec eliminates a ciphertext-sized memcpy
// that the caller would otherwise do to splice an intermediate ciphertext
// buffer into its output.
void encryptWithSecretStream(vBytes &output_vec, std::span<const Byte> prefix,
                             vBytes &body, const Key &key,
                             StreamHeader &header) {
  Sensitive<crypto_secretstream_xchacha20poly1305_state> stream_state;
  if (crypto_secretstream_xchacha20poly1305_init_push(
          &stream_state.value, header.data(), key.data()) != 0) {
    throw std::runtime_error("crypto_secretstream init_push failed.");
  }
  const std::size_t total =
      checkedAddSize(prefix.size(), body.size(),
                     "Data File Error: Data file too large to encrypt.");
  output_vec.reserve(
      checkedAddSize(output_vec.size(), computeStreamEncryptedSize(total),
                     "Data File Error: Encrypted data is too large."));
  appendBytes(output_vec, std::span<const Byte>(header),
              ENCRYPTED_TOO_LARGE_ERROR);
  vBytes cipher_chunk(STREAM_CHUNK_SIZE +
                      crypto_secretstream_xchacha20poly1305_ABYTES);

  // Only the first chunk ever needs a scratch buffer to join prefix + body;
  // subsequent chunks push straight from body's storage with no extra copies.
  vBytes staging;
  if (!prefix.empty()) {
    staging.reserve(STREAM_CHUNK_SIZE);
  }
  SensitiveBytesGuard body_guard(body);
  SensitiveBytesGuard staging_guard(staging);
  SensitiveBytesGuard cipher_chunk_guard(cipher_chunk);

  // Store each ciphertext frame as [length][ciphertext] so recovery can
  // validate bounds before attempting to decrypt any chunk data.
  std::size_t logical_offset = 0;
  while (true) {
    const std::size_t remaining = total - logical_offset;
    const std::size_t chunk_len = std::min(remaining, STREAM_CHUNK_SIZE);
    const bool is_final = (logical_offset + chunk_len == total);
    const unsigned char tag =
        is_final ? crypto_secretstream_xchacha20poly1305_TAG_FINAL : 0;

    const Byte *chunk_ptr = nullptr;
    if (chunk_len != 0) {
      if (logical_offset < prefix.size()) {
        // Chunk straddles prefix and body: build it in a scratch buffer.
        staging.resize(chunk_len);
        const std::size_t from_prefix =
            std::min(chunk_len, prefix.size() - logical_offset);
        std::memcpy(staging.data(), prefix.data() + logical_offset,
                    from_prefix);
        const std::size_t from_body = chunk_len - from_prefix;
        if (from_body > 0) {
          std::memcpy(staging.data() + from_prefix, body.data(), from_body);
        }
        chunk_ptr = staging.data();
      } else {
        chunk_ptr = body.data() + (logical_offset - prefix.size());
      }
    }

    unsigned long long clen_ull = 0;
    if (crypto_secretstream_xchacha20poly1305_push(
            &stream_state.value, cipher_chunk.data(), &clen_ull, chunk_ptr,
            chunk_len, nullptr, 0, tag) != 0) {
      throw std::runtime_error("crypto_secretstream push failed.");
    }
    if (clen_ull > static_cast<unsigned long long>(
                       std::numeric_limits<std::uint32_t>::max())) {
      throw std::runtime_error("crypto_secretstream frame too large.");
    }
    const auto clen = static_cast<std::uint32_t>(clen_ull);
    writeFrameLen(output_vec, clen);
    appendBytes(output_vec, std::span<const Byte>(cipher_chunk.data(), clen),
                ENCRYPTED_TOO_LARGE_ERROR);
    logical_offset += chunk_len;
    if (is_final) {
      break;
    }
  }
  if (!staging.empty()) {
    sodium_memzero(staging.data(), staging.size());
  }
  if (!body.empty()) {
    sodium_memzero(body.data(), body.size());
  }
  body.clear();
}

// Decrypt in place: cipher at storage[cipher_start..cipher_start+cipher_len),
// plaintext written to storage[0..]. Plaintext write trails unread cipher by at
// least (cipher_start + header.size() + 21*N) bytes after frame N — always
// safe. On success, storage is resized to plaintext size. On failure, any
// partial plaintext is wiped.
[[nodiscard]] bool decryptWithSecretStreamInPlace(vBytes &storage,
                                                  std::size_t cipher_start,
                                                  std::size_t cipher_len,
                                                  const Key &key,
                                                  const StreamHeader &header) {
  if (cipher_len < header.size()) {
    return false;
  }
  if (!spanHasRange(storage, cipher_start, cipher_len)) {
    return false;
  }
  if (!std::ranges::equal(
          std::span<const Byte>(storage.data() + cipher_start, header.size()),
          header)) {
    return false;
  }
  Sensitive<crypto_secretstream_xchacha20poly1305_state> stream_state;
  if (crypto_secretstream_xchacha20poly1305_init_pull(
          &stream_state.value, header.data(), key.data()) != 0) {
    return false;
  }
  vBytes plain_chunk(STREAM_CHUNK_SIZE);
  SensitiveBytesGuard plain_chunk_guard(plain_chunk);

  std::size_t cipher_pos = cipher_start + header.size();
  const std::size_t cipher_end = cipher_start + cipher_len;
  std::size_t plain_pos = 0;
  bool has_final_tag = false;

  auto fail = [&]() -> bool {
    sodium_memzero(storage.data(), plain_pos);
    return false;
  };

  while (cipher_pos < cipher_end) {
    if (cipher_end - cipher_pos < STREAM_FRAME_LEN_BYTES) {
      return fail();
    }
    const std::uint32_t frame_len = readBe32At(storage, cipher_pos);
    cipher_pos += STREAM_FRAME_LEN_BYTES;
    if (frame_len < crypto_secretstream_xchacha20poly1305_ABYTES ||
        frame_len > cipher_end - cipher_pos) {
      return fail();
    }
    const std::size_t max_plain_chunk =
        static_cast<std::size_t>(frame_len) -
        crypto_secretstream_xchacha20poly1305_ABYTES;
    if (max_plain_chunk > plain_chunk.size()) {
      return fail();
    }
    unsigned long long mlen = 0;
    unsigned char tag = 0;
    if (crypto_secretstream_xchacha20poly1305_pull(
            &stream_state.value, plain_chunk.data(), &mlen, &tag,
            storage.data() + cipher_pos, frame_len, nullptr, 0) != 0) {
      return fail();
    }
    if (mlen > max_plain_chunk) {
      return fail();
    }
    if (mlen > 0) {
      std::memcpy(storage.data() + plain_pos, plain_chunk.data(), mlen);
      plain_pos += mlen;
    }
    cipher_pos += frame_len;
    if (tag == crypto_secretstream_xchacha20poly1305_TAG_FINAL) {
      has_final_tag = true;
      break;
    }
  }
  if (!has_final_tag || cipher_pos != cipher_end) {
    return fail();
  }
  // Wipe trailing ciphertext bytes before truncating.
  if (plain_pos < storage.size()) {
    sodium_memzero(storage.data() + plain_pos, storage.size() - plain_pos);
  }
  storage.resize(plain_pos);
  return true;
}

struct KdfParameters {
  unsigned long long opslimit;
  std::size_t memlimit;
};

constexpr KdfParameters FIXED_KDF_PARAMETERS = {
    KDF_ARGON2ID13_OPSLIMIT, KDF_ARGON2ID13_MEMLIMIT};

// PINs round-trip through a uint64: interactive entry is parsed as a number
// and the KDF input is the canonical decimal encoding, so leading zeros typed
// at recovery ("00123") canonicalize to the same PIN ("123").
void deriveKeyFromPin(Key &out_key, std::uint64_t pin, const Salt &salt,
                      const KdfParameters &parameters) {
  std::array<char, 32> pin_buf{};
  auto [ptr, ec] =
      std::to_chars(pin_buf.data(), pin_buf.data() + pin_buf.size(), pin);
  if (ec != std::errc{}) {
    sodium_memzero(pin_buf.data(), pin_buf.size());
    throw std::runtime_error("KDF Error: Failed to encode recovery PIN.");
  }
  const auto pin_len = static_cast<unsigned long long>(ptr - pin_buf.data());
  const int rc = crypto_pwhash(
      out_key.data(), out_key.size(), pin_buf.data(), pin_len, salt.data(),
      parameters.opslimit, parameters.memlimit,
      crypto_pwhash_ALG_ARGON2ID13);
  sodium_memzero(pin_buf.data(), pin_buf.size());
  if (rc != 0) {
    throw std::runtime_error("KDF Error: Unable to derive encryption key.");
  }
}

// Bounds-checked copy of a fixed-size field into / out of the metadata region.
// Both directions validate against the same span before touching a byte.
void putField(vBytes &profile_vec, std::size_t offset,
              std::span<const Byte> field, std::string_view message) {
  requireSpanRange(profile_vec, offset, field.size(), message);
  std::memcpy(profile_vec.data() + offset, field.data(), field.size());
}

void getField(const vBytes &profile_vec, std::size_t offset,
              std::span<Byte> field, std::string_view message) {
  requireSpanRange(profile_vec, offset, field.size(), message);
  std::memcpy(field.data(), profile_vec.data() + offset, field.size());
}

void writeKdfMetadata(vBytes &profile_vec, const ProfileOffsets &offsets,
                      const Salt &salt, const StreamHeader &stream_header) {
  const std::size_t base = offsets.kdf_metadata;
  requireSpanRange(profile_vec, base, KDF_METADATA_REGION_BYTES,
                   CORRUPT_PROFILE_ERROR);
  putField(profile_vec, base + KDF_MAGIC_OFFSET, KDF_METADATA_MAGIC_V3,
           CORRUPT_PROFILE_ERROR);
  profile_vec[base + KDF_ALG_OFFSET] = KDF_ALG_ARGON2ID13;
  profile_vec[base + KDF_SENTINEL_OFFSET] = KDF_SENTINEL;
  profile_vec[base + KDF_PARAMETER_ENCODING_OFFSET] =
      KDF_PARAMETER_ENCODING_BE32;
  profile_vec[base + KDF_FLAGS_OFFSET] = KDF_FLAGS_NONE;
  putField(profile_vec, base + KDF_SALT_OFFSET, salt, CORRUPT_PROFILE_ERROR);
  putField(profile_vec, base + KDF_NONCE_OFFSET, stream_header,
           CORRUPT_PROFILE_ERROR);
  writeBe32At(profile_vec, base + KDF_OPSLIMIT_OFFSET,
              static_cast<std::uint32_t>(KDF_ARGON2ID13_OPSLIMIT));
  writeBe32At(profile_vec, base + KDF_MEMLIMIT_KIB_OFFSET,
              KDF_ARGON2ID13_MEMLIMIT_KIB);
}

void readKdfMetadata(const vBytes &profile_vec, const ProfileOffsets &offsets,
                     Salt &salt, StreamHeader &stream_header) {
  const std::size_t base = offsets.kdf_metadata;
  getField(profile_vec, base + KDF_SALT_OFFSET, salt, CORRUPT_FILE_ERROR);
  getField(profile_vec, base + KDF_NONCE_OFFSET, stream_header,
           CORRUPT_FILE_ERROR);
}

[[nodiscard]] bool metadataMagicEquals(std::span<const Byte> data,
                                       std::size_t base_index,
                                       std::span<const Byte> magic) {
  return spanHasRange(data, base_index + KDF_MAGIC_OFFSET, magic.size()) &&
         std::ranges::equal(
             data.subspan(base_index + KDF_MAGIC_OFFSET, magic.size()), magic);
}

[[nodiscard]] KdfParameters
readKdfParameters(std::span<const Byte> data, std::size_t base_index) {
  requireSpanRange(data, base_index, KDF_METADATA_REGION_BYTES,
                   CORRUPT_FILE_ERROR);
  const bool common_fields_valid =
      data[base_index + KDF_ALG_OFFSET] == KDF_ALG_ARGON2ID13 &&
      data[base_index + KDF_SENTINEL_OFFSET] == KDF_SENTINEL;

  if (metadataMagicEquals(data, base_index, KDF_METADATA_MAGIC_V2)) {
    if (!common_fields_valid) {
      throw std::runtime_error(CORRUPT_FILE_ERROR);
    }
    // KDF2's unused bytes were randomized, so only its defined fields can be
    // validated.  Always use the historical literal parameters.
    return FIXED_KDF_PARAMETERS;
  }

  if (!metadataMagicEquals(data, base_index, KDF_METADATA_MAGIC_V3)) {
    throw std::runtime_error(
        "File Decryption Error: Unsupported legacy encrypted file format. "
        "Use an older wbpdv release to recover this file.");
  }
  if (!common_fields_valid ||
      data[base_index + KDF_PARAMETER_ENCODING_OFFSET] !=
          KDF_PARAMETER_ENCODING_BE32 ||
      data[base_index + KDF_FLAGS_OFFSET] != KDF_FLAGS_NONE) {
    throw std::runtime_error(
        "File Decryption Error: Invalid or unsupported KDF3 metadata.");
  }

  const std::uint32_t encoded_opslimit =
      readBe32At(data, base_index + KDF_OPSLIMIT_OFFSET);
  const std::uint32_t encoded_memlimit_kib =
      readBe32At(data, base_index + KDF_MEMLIMIT_KIB_OFFSET);
  if (encoded_opslimit != KDF_ARGON2ID13_OPSLIMIT ||
      encoded_memlimit_kib != KDF_ARGON2ID13_MEMLIMIT_KIB) {
    throw std::runtime_error(
        "File Decryption Error: Invalid or unsupported KDF3 parameters.");
  }
  return FIXED_KDF_PARAMETERS;
}

[[nodiscard]] std::uint64_t generateRecoveryPin() {
  std::uint64_t pin = 0;
  while (pin == 0) {
    randombytes_buf(&pin, sizeof(pin));
  }
  return pin;
}

template <typename T> [[nodiscard]] T fromBigEndian(T value) {
  if constexpr (std::endian::native == std::endian::little) {
    return std::byteswap(value);
  } else {
    return value;
  }
}

// PIN file format: exactly 8 bytes — the big-endian encoding of the numeric
// recovery PIN that wpdv_in prints in decimal. The PIN round-trips through a
// uint64 and the KDF input is its canonical decimal encoding, so leading
// zeros in the displayed PIN are insignificant: "00123" and "123" encode to
// the same 8-byte file.
[[nodiscard]] std::uint64_t getPinFromFile(vBytes &pin_vec) {
  SensitiveBytesGuard pin_guard(pin_vec);
  constexpr std::size_t PIN_BYTES = sizeof(std::uint64_t);
  if (pin_vec.size() != PIN_BYTES) {
    throw std::runtime_error("PIN File Error: Invalid file size.");
  }

  std::uint64_t encoded = 0;
  std::memcpy(&encoded, pin_vec.data(), sizeof(encoded));
  return fromBigEndian(encoded);
}

[[nodiscard]] std::span<const Byte>
makeFilenamePrefix(const std::string &data_filename,
                   FilenamePrefixBuffer &prefix_buffer) {
  if (data_filename.empty() ||
      data_filename.size() >
          static_cast<std::size_t>(std::numeric_limits<Byte>::max())) {
    throw std::runtime_error("Data File Error: Invalid data filename length.");
  }

  prefix_buffer.size = 1 + data_filename.size();
  prefix_buffer.bytes[0] = static_cast<Byte>(data_filename.size());
  std::memcpy(prefix_buffer.bytes.data() + 1, data_filename.data(),
              data_filename.size());
  return prefix_buffer.span();
}

[[nodiscard]] std::string extractFilenamePrefix(vBytes &payload) {
  if (payload.empty() || payload[0] == 0) {
    throw std::runtime_error(CORRUPT_FILE_ERROR);
  }
  const std::size_t filename_len = payload[0];
  const std::size_t prefix_len = 1 + filename_len;
  requireSpanRange(payload, 0, prefix_len, CORRUPT_FILE_ERROR);
  std::string decrypted_filename(
      reinterpret_cast<const char *>(payload.data() + 1), filename_len);

  const std::size_t remaining = payload.size() - prefix_len;
  if (remaining > 0) {
    std::memmove(payload.data(),
                 payload.data() + static_cast<std::ptrdiff_t>(prefix_len),
                 remaining);
  }
  sodium_memzero(payload.data() + static_cast<std::ptrdiff_t>(remaining),
                 prefix_len);
  payload.resize(remaining);
  return decrypted_filename;
}

} // namespace

std::uint64_t encryptDataFile(vBytes &profile_vec, vBytes &data_vec,
                              const std::string &data_filename,
                              const ProfileOffsets &offsets) {
  requireSpanRange(profile_vec, offsets.kdf_metadata, KDF_METADATA_REGION_BYTES,
                   CORRUPT_PROFILE_ERROR);
  if (offsets.encrypted_file != profile_vec.size()) {
    throw std::runtime_error(CORRUPT_PROFILE_ERROR);
  }
  FilenamePrefixBuffer prefix_buffer;
  const std::span<const Byte> prefix =
      makeFilenamePrefix(data_filename, prefix_buffer);
  const std::size_t prefix_len = prefix.size();
  if (data_vec.size() > std::numeric_limits<std::size_t>::max() - prefix_len) {
    throw std::runtime_error(
        "Data File Error: Data file too large to encrypt.");
  }
  Sensitive<Key> key;
  Salt salt{};
  StreamHeader stream_header{};
  const std::uint64_t pin = generateRecoveryPin();
  randombytes_buf(salt.data(), salt.size());
  deriveKeyFromPin(key.value, pin, salt, FIXED_KDF_PARAMETERS);
  encryptWithSecretStream(profile_vec, prefix, data_vec, key.value,
                          stream_header);
  writeKdfMetadata(profile_vec, offsets, salt, stream_header);
  return pin;
}

std::optional<std::string>
decryptDataFileWithPin(vBytes &profile_vec, const ProfileOffsets &offsets,
                       std::uint64_t recovery_pin) {
  requireSpanRange(profile_vec, offsets.kdf_metadata, KDF_METADATA_REGION_BYTES,
                   CORRUPT_FILE_ERROR);
  if (offsets.encrypted_file > profile_vec.size()) {
    throw std::runtime_error(CORRUPT_FILE_ERROR);
  }
  const KdfParameters kdf_parameters =
      readKdfParameters(profile_vec, offsets.kdf_metadata);
  Sensitive<Key> key;
  Salt salt{};
  StreamHeader stream_header{};
  readKdfMetadata(profile_vec, offsets, salt, stream_header);
  deriveKeyFromPin(key.value, recovery_pin, salt, kdf_parameters);
  sodium_memzero(&recovery_pin, sizeof(recovery_pin));
  const std::size_t ciphertext_length =
      profile_vec.size() - offsets.encrypted_file;
  const std::size_t min_stream_cipher_size =
      StreamHeader{}.size() + STREAM_FRAME_LEN_BYTES +
      crypto_secretstream_xchacha20poly1305_ABYTES;
  if (ciphertext_length < min_stream_cipher_size) {
    throw std::runtime_error(CORRUPT_FILE_ERROR);
  }
  if (!decryptWithSecretStreamInPlace(profile_vec, offsets.encrypted_file,
                                      ciphertext_length, key.value,
                                      stream_header)) {
    return std::nullopt;
  }
  return extractFilenamePrefix(profile_vec);
}

std::optional<std::string> decryptDataFile(vBytes &profile_vec,
                                           vBytes &pin_vec,
                                           const ProfileOffsets &offsets) {
  return decryptDataFileWithPin(profile_vec, offsets,
                                getPinFromFile(pin_vec));
}
