#include "args_out.h"

#include <format>
#include <stdexcept>
#include <string_view>

void ProgramArgs::die(const std::string& usage) {
	throw std::runtime_error(usage);
}

ProgramArgs ProgramArgs::parse(int argc, char** argv) {
	const auto arg = [&](int i) -> std::string_view {
		return (i >= 0 && i < argc) ? argv[i] : std::string_view{};
	};

	const std::string
		prog = fs::path(argv[0]).filename().string(),
		usage = std::format("Usage: {} <cover_image> <passphrase_file>", prog);

	if (argc != 3 || arg(1).empty()) die(usage);

	ProgramArgs out{};
	out.image_file_path = fs::path(arg(1));
	out.passphrase_file_path = fs::path(arg(2));
	return out;
}
