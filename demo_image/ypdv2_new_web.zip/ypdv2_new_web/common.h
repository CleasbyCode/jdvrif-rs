// PNG Data Vehicle (pdvrdt). Created by Nicholas Cleasby (@CleasbyCode) 24/01/2023

#pragma once

// ---------------------------------------------------------------------------
// Platform + toolchain floor. pdvrdt is distributed as source and built by
// each user, so fail early with a clear message rather than a wall of errors
// when the environment is unsupported.
//
// Platform: Linux only (renameat2(RENAME_NOREPLACE), termios PIN entry, etc.).
// Toolchain: features that set this floor:
//   - std::print / std::println          (GCC 14, Clang 18 + libc++ 18)
//   - std::format, std::ranges, [[assume]] (GCC 13+ / Clang 19)
//   - std::move_only_function, std::ranges::fold_left (libstdc++ 13)
//   - std::views::zip / chunk / enumerate (libstdc++ 13; not in libc++ 18)
//   - static lambdas, uz literals         (GCC 13, Clang 16)
// A matching C++23 standard library is required. Clang builds must therefore
// use libstdc++ 14+.
// ---------------------------------------------------------------------------
#if !defined(__linux__)
#  error "pdvrdt requires Linux."
#endif
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ < 14
#  error "pdvrdt requires GCC >= 14 (for std::print/std::format). Please upgrade your compiler."
#elif defined(__clang__) && __clang_major__ < 18
#  error "pdvrdt requires Clang >= 18 with libstdc++ 14+. Please upgrade your compiler."
#endif

// External library dependencies (included only where needed):
//   lodepng — PNG encoding/decoding (vendored in lodepng/)
//   zlib    — compression           (https://zlib.net)
//   libsodium — cryptography       (https://libsodium.org)

#include <sodium.h>

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <span>
#include <string>
#include <string_view>
#include <vector>

namespace fs = std::filesystem;

// Single source of truth for the release version. Reported by `--info`; bump
// here only. Deliberately not duplicated in CMakeLists.txt or file banners.
inline constexpr std::string_view PDVRDT_VERSION = "6.0";

using Byte    = std::uint8_t;
using vBytes  = std::vector<Byte>;

using Key   = std::array<Byte, crypto_secretstream_xchacha20poly1305_KEYBYTES>;
using Salt  = std::array<Byte, crypto_pwhash_SALTBYTES>;

// Scrub a secret on scope exit.
//
// Construct from any container or byte range (vector, array, string, span) to
// wipe what it holds, or from a plain object to wipe its bytes. The range is
// re-read at destruction rather than captured up front, so a resize -- or a move
// that leaves the source empty -- is honoured instead of scribbling over memory
// the object no longer owns.
//
// sodium_memzero() is specifically guaranteed not to be optimized away, unlike
// an ordinary assignment to a dying object.
template <typename T>
class ScopedWipe {
public:
	explicit ScopedWipe(T& target) noexcept : target_(&target) {}
	ScopedWipe(const ScopedWipe&) = delete;
	ScopedWipe& operator=(const ScopedWipe&) = delete;

	~ScopedWipe() {
		if (target_ == nullptr) return;
		if constexpr (requires { target_->data(); target_->size(); }) {
			if (target_->size() != 0) {
				sodium_memzero(target_->data(), target_->size() * sizeof(*target_->data()));
			}
		} else {
			sodium_memzero(target_, sizeof(T));
		}
	}

	// The bytes are no longer secret here (ownership passed to the caller).
	void release() noexcept { target_ = nullptr; }

private:
	T* target_;
};

template <typename T> ScopedWipe(T&) -> ScopedWipe<T>;

// Wipe a 64-bit secret (e.g. recovery PIN) on scope exit.
//
// Producers of a secret (PIN generation, PIN entry) fill one of these through a
// reference rather than returning std::uint64_t by value: a by-value return
// leaves an unwiped copy of the secret in the return slot that nothing owns.
// For the same reason this type is neither copyable nor movable -- a secret has
// exactly one home, and it is scrubbed when that home goes out of scope.
struct SensitiveU64 {
	std::uint64_t value{};

	SensitiveU64() = default;
	explicit SensitiveU64(std::uint64_t v) noexcept : value(v) {}

	SensitiveU64(const SensitiveU64&) = delete;
	SensitiveU64& operator=(const SensitiveU64&) = delete;
	SensitiveU64(SensitiveU64&&) = delete;
	SensitiveU64& operator=(SensitiveU64&&) = delete;

	// sodium_memzero() is specifically guaranteed not to be optimized away,
	// unlike an ordinary assignment to a dying object.
	~SensitiveU64() {
		sodium_memzero(&value, sizeof(value));
	}
};

// The secret a payload is recovered with: a 128-bit recovery KEY (pdvrdt 6.0
// and later) or, for older images, a numeric PIN of up to 64 bits. Like
// SensitiveU64 it has exactly one home, is filled in place by reference, and is
// scrubbed when that home goes out of scope.
struct RecoveryPin {
	static constexpr std::size_t KEY_BYTES = 16;
	enum class Kind : Byte { none, legacy_pin, key128 };

	Kind kind{Kind::none};
	std::uint64_t legacy_value{};
	std::array<Byte, KEY_BYTES> key{};

	RecoveryPin() = default;
	RecoveryPin(const RecoveryPin&) = delete;
	RecoveryPin& operator=(const RecoveryPin&) = delete;
	RecoveryPin(RecoveryPin&&) = delete;
	RecoveryPin& operator=(RecoveryPin&&) = delete;
	~RecoveryPin() { clear(); }

	void clear() noexcept {
		kind = Kind::none;
		sodium_memzero(&legacy_value, sizeof(legacy_value));
		sodium_memzero(key.data(), key.size());
	}
	[[nodiscard]] bool isKey() const noexcept { return kind == Kind::key128; }
};

// Which word the recovery prompt and its errors use. Default and Mastodon
// images record whether they take a KEY (6.0+) or a PIN (older). A Reddit
// carrier cannot be read until after entry -- the secret locates it -- so its
// prompt names both.
enum class PinPrompt : Byte { key, pin, key_or_pin };

[[nodiscard]] constexpr const char* pinPromptWord(PinPrompt prompt) noexcept {
	switch (prompt) {
		case PinPrompt::key: return "KEY";
		case PinPrompt::pin: return "PIN";
		case PinPrompt::key_or_pin: break;
	}
	return "KEY/PIN";
}

enum class Mode   : Byte { conceal, recover, capsize };
enum class Option : Byte { None, Mastodon, Reddit };
