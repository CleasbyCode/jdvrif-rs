#include "image_processing_internal.h"

#include <algorithm>
#include <cmath>
#include <stdexcept>
#include <vector>

// Permit the portable path to be exercised on x86 builds as well.
#ifndef PDVZIP_HAS_X86_SIMD
#if defined(__SSE2__) || defined(_M_X64) || (defined(_M_IX86_FP) && _M_IX86_FP >= 2)
#define PDVZIP_HAS_X86_SIMD 1
#else
#define PDVZIP_HAS_X86_SIMD 0
#endif
#endif

#if PDVZIP_HAS_X86_SIMD
#include <immintrin.h>
#endif

namespace {

struct ResizeAxisSample {
	unsigned lower{};
	unsigned upper{};
	unsigned nearest{};
	float lower_weight{};
	float upper_weight{};
};

[[nodiscard]] std::vector<ResizeAxisSample> buildResizeAxisSamples(unsigned source_size, unsigned target_size) {
	constexpr double SAMPLING_OFFSET = 0.5;

	std::vector<ResizeAxisSample> samples(target_size);
	const double ratio = static_cast<double>(source_size) / static_cast<double>(target_size);

	for (unsigned i = 0; i < target_size; ++i) {
		const double source_position = std::clamp(
			(i + SAMPLING_OFFSET) * ratio - SAMPLING_OFFSET,
			0.0,
			static_cast<double>(source_size - 1)
		);
		const unsigned lower = static_cast<unsigned>(source_position);
		const float upper_weight = static_cast<float>(source_position - static_cast<double>(lower));

		samples[i] = ResizeAxisSample{
			.lower = lower,
			.upper = std::min(lower + 1, source_size - 1),
			.nearest = static_cast<unsigned>(std::round(source_position)),
			.lower_weight = 1.0f - upper_weight,
			.upper_weight = upper_weight
		};
	}

	return samples;
}

template <unsigned Channels>
inline void interpolatePixelScalar(
	Byte* destination,
	const Byte* top_left,
	const Byte* top_right,
	const Byte* bottom_left,
	const Byte* bottom_right,
	float top_left_weight,
	float top_right_weight,
	float bottom_left_weight,
	float bottom_right_weight
) {
	float alpha = 1.0f;
	if constexpr (Channels == 4) {
		// Weight color by coverage so hidden RGB cannot darken visible edges.
		top_left_weight *= static_cast<float>(top_left[3]);
		top_right_weight *= static_cast<float>(top_right[3]);
		bottom_left_weight *= static_cast<float>(bottom_left[3]);
		bottom_right_weight *= static_cast<float>(bottom_right[3]);
		alpha = top_left_weight + top_right_weight + bottom_left_weight + bottom_right_weight;
		if (alpha < 0.5f) {
			std::fill_n(destination, 4, Byte{0});
			return;
		}
		destination[3] = static_cast<Byte>(std::clamp(std::round(alpha), 0.0f, 255.0f));
	}

	for (unsigned channel = 0; channel < 3; ++channel) {
		const float value =
			top_left_weight * static_cast<float>(top_left[channel]) +
			top_right_weight * static_cast<float>(top_right[channel]) +
			bottom_left_weight * static_cast<float>(bottom_left[channel]) +
			bottom_right_weight * static_cast<float>(bottom_right[channel]);
		destination[channel] = static_cast<Byte>(std::clamp(std::round(value / alpha), 0.0f, 255.0f));
	}
}

#if PDVZIP_HAS_X86_SIMD
template <unsigned Channels>
[[nodiscard]] inline __m128 loadPixelAsFloat(const Byte* source) {
	if constexpr (Channels == 4) {
		return _mm_setr_ps(
			static_cast<float>(source[0]),
			static_cast<float>(source[1]),
			static_cast<float>(source[2]),
			1.0f);
	} else {
		return _mm_setr_ps(
			static_cast<float>(source[0]),
			static_cast<float>(source[1]),
			static_cast<float>(source[2]),
			0.0f);
	}
}

template <unsigned Channels>
inline void storeRoundedPixel(Byte* destination, __m128 value) {
	const __m128 clamped = _mm_min_ps(_mm_max_ps(value, _mm_setzero_ps()), _mm_set1_ps(255.0f));
	const __m128 biased = _mm_add_ps(clamped, _mm_set1_ps(0.5f));
	const __m128i rounded = _mm_cvttps_epi32(biased);

	alignas(16) int components[4]{};
	_mm_storeu_si128(reinterpret_cast<__m128i*>(components), rounded);

	for (unsigned channel = 0; channel < Channels; ++channel) {
		destination[channel] = static_cast<Byte>(components[channel]);
	}
}

template <unsigned Channels>
inline void interpolatePixelSimd(
	Byte* destination,
	const Byte* top_left,
	const Byte* top_right,
	const Byte* bottom_left,
	const Byte* bottom_right,
	float top_left_weight,
	float top_right_weight,
	float bottom_left_weight,
	float bottom_right_weight
) {
	if constexpr (Channels == 4) {
		top_left_weight *= static_cast<float>(top_left[3]);
		top_right_weight *= static_cast<float>(top_right[3]);
		bottom_left_weight *= static_cast<float>(bottom_left[3]);
		bottom_right_weight *= static_cast<float>(bottom_right[3]);
	}

	// For RGBA the fourth lane accumulates coverage, while RGB accumulates
	// premultiplied color. RGB-only input retains ordinary bilinear filtering.
	__m128 sum = _mm_add_ps(
		_mm_add_ps(
			_mm_mul_ps(loadPixelAsFloat<Channels>(top_left), _mm_set1_ps(top_left_weight)),
			_mm_mul_ps(loadPixelAsFloat<Channels>(top_right), _mm_set1_ps(top_right_weight))),
		_mm_add_ps(
			_mm_mul_ps(loadPixelAsFloat<Channels>(bottom_left), _mm_set1_ps(bottom_left_weight)),
			_mm_mul_ps(loadPixelAsFloat<Channels>(bottom_right), _mm_set1_ps(bottom_right_weight))));

	if constexpr (Channels == 4) {
		const float alpha = _mm_cvtss_f32(_mm_shuffle_ps(sum, sum, _MM_SHUFFLE(3, 3, 3, 3)));
		if (alpha < 0.5f) {
			std::fill_n(destination, 4, Byte{0});
			return;
		}
		sum = _mm_div_ps(sum, _mm_setr_ps(alpha, alpha, alpha, 1.0f));
	}

	storeRoundedPixel<Channels>(destination, sum);
}
#endif

template <unsigned Channels>
inline void interpolatePixel(
	Byte* destination,
	const Byte* top_left,
	const Byte* top_right,
	const Byte* bottom_left,
	const Byte* bottom_right,
	float top_left_weight,
	float top_right_weight,
	float bottom_left_weight,
	float bottom_right_weight
) {
#if PDVZIP_HAS_X86_SIMD
	interpolatePixelSimd<Channels>(
		destination,
		top_left,
		top_right,
		bottom_left,
		bottom_right,
		top_left_weight,
		top_right_weight,
		bottom_left_weight,
		bottom_right_weight);
#else
	interpolatePixelScalar<Channels>(
		destination,
		top_left,
		top_right,
		bottom_left,
		bottom_right,
		top_left_weight,
		top_right_weight,
		bottom_left_weight,
		bottom_right_weight);
#endif
}

void resizePaletteImage(
	vBytes& resized,
	const vBytes& pixels,
	unsigned width,
	unsigned new_width,
	unsigned new_height,
	const std::vector<ResizeAxisSample>& x_samples,
	const std::vector<ResizeAxisSample>& y_samples
) {
	for (unsigned y = 0; y < new_height; ++y) {
		const std::size_t source_row = static_cast<std::size_t>(y_samples[y].nearest) * width;
		Byte* const destination_row = resized.data() + static_cast<std::size_t>(y) * new_width;

		for (unsigned x = 0; x < new_width; ++x) {
			destination_row[x] = pixels[source_row + x_samples[x].nearest];
		}
	}
}

template <unsigned Channels>
void resizeTruecolorImage(
	vBytes& resized,
	const vBytes& pixels,
	unsigned width,
	unsigned new_width,
	unsigned new_height,
	const std::vector<ResizeAxisSample>& x_samples,
	const std::vector<ResizeAxisSample>& y_samples
) {
	const std::size_t source_row_stride = static_cast<std::size_t>(width) * Channels;
	const std::size_t destination_row_stride = static_cast<std::size_t>(new_width) * Channels;

	for (unsigned y = 0; y < new_height; ++y) {
		const ResizeAxisSample& y_sample = y_samples[y];
		const Byte* const top_row = pixels.data() + static_cast<std::size_t>(y_sample.lower) * source_row_stride;
		const Byte* const bottom_row = pixels.data() + static_cast<std::size_t>(y_sample.upper) * source_row_stride;
		Byte* const destination_row = resized.data() + static_cast<std::size_t>(y) * destination_row_stride;

		for (unsigned x = 0; x < new_width; ++x) {
			const ResizeAxisSample& x_sample = x_samples[x];
			const std::size_t left_offset = static_cast<std::size_t>(x_sample.lower) * Channels;
			const std::size_t right_offset = static_cast<std::size_t>(x_sample.upper) * Channels;

			const float top_left_weight = x_sample.lower_weight * y_sample.lower_weight;
			const float top_right_weight = x_sample.upper_weight * y_sample.lower_weight;
			const float bottom_left_weight = x_sample.lower_weight * y_sample.upper_weight;
			const float bottom_right_weight = x_sample.upper_weight * y_sample.upper_weight;

			interpolatePixel<Channels>(
				destination_row + static_cast<std::size_t>(x) * Channels,
				top_row + left_offset,
				top_row + right_offset,
				bottom_row + left_offset,
				bottom_row + right_offset,
				top_left_weight,
				top_right_weight,
				bottom_left_weight,
				bottom_right_weight);
		}
	}
}

void decodePreservingColorType(
	const vBytes& image_file_vec,
	vBytes& pixels,
	unsigned& width,
	unsigned& height,
	lodepng::State& decode_state) {

	decode_state.decoder.color_convert = 0;
	image_processing_internal::configurePngInflateLimit(decode_state, image_file_vec);
	const unsigned error = lodepng::decode(pixels, width, height, decode_state, image_file_vec);
	image_processing_internal::throwLodepngError("LodePNG decode error", error);
}

void validateResizeTarget(unsigned new_width, unsigned new_height, unsigned width, unsigned height) {
	constexpr unsigned MIN_DIMENSION = 68;

	if (new_width < MIN_DIMENSION || new_height < MIN_DIMENSION) {
		throw std::runtime_error("Image Error: Resize target dimensions are below the minimum.");
	}
	if (new_width > width || new_height > height) {
		throw std::runtime_error("Image Error: Resize target must not exceed source dimensions.");
	}
}

void validateDecodedResizeFormat(bool is_palette, unsigned channels, unsigned bitdepth) {
	if (channels == 0) {
		throw std::runtime_error("Image Error: Decoded image reports 0 channels.");
	}
	if (!is_palette && bitdepth != 8) {
		throw std::runtime_error("Image Error: Only 8-bit truecolor/grayscale PNGs are supported.");
	}
	if (!is_palette && channels != 3 && channels != 4) {
		throw std::runtime_error("Image Error: Resize only supports RGB/RGBA truecolor PNGs.");
	}
}

void redecodeSubBytePalette(
	const vBytes& image_file_vec,
	const lodepng::State& decode_state,
	vBytes& pixels,
	unsigned& width,
	unsigned& height) {

	lodepng::State redecode_state;
	redecode_state.decoder.color_convert = 1;
	redecode_state.info_raw.colortype = LCT_PALETTE;
	redecode_state.info_raw.bitdepth = 8;
	image_processing_internal::configurePngInflateLimit(redecode_state, image_file_vec);

	// Copy the palette into info_raw so lodepng can convert.
	const auto& src_color = decode_state.info_png.color;
	image_processing_internal::copyPalette(src_color.palette, src_color.palettesize, redecode_state.info_raw);

	pixels.clear();
	const unsigned error = lodepng::decode(pixels, width, height, redecode_state, image_file_vec);
	image_processing_internal::throwLodepngError("LodePNG re-decode error", error);
}

[[nodiscard]] std::size_t bytesPerPixel(bool is_palette, unsigned channels) {
	return is_palette ? 1 : channels;
}

void validateSourceBufferSize(const vBytes& pixels, unsigned width, unsigned height, std::size_t bytes_per_pixel) {
	const std::size_t source_pixel_count = checkedMultiply(
		static_cast<std::size_t>(width),
		static_cast<std::size_t>(height),
		"Image Error: Source image dimensions overflow.");
	const std::size_t source_byte_count = checkedMultiply(
		source_pixel_count,
		bytes_per_pixel,
		"Image Error: Source image buffer size overflow.");
	if (pixels.size() < source_byte_count) {
		throw std::runtime_error("Image Error: Decoded image buffer is truncated.");
	}
}

[[nodiscard]] vBytes makeResizedPixelBuffer(unsigned new_width, unsigned new_height, std::size_t bytes_per_pixel) {
	const std::size_t resized_pixel_count = checkedMultiply(
		static_cast<std::size_t>(new_width),
		static_cast<std::size_t>(new_height),
		"Image Error: Resized image dimensions overflow.");
	return vBytes(checkedMultiply(
		resized_pixel_count,
		bytes_per_pixel,
		"Image Error: Resized image buffer size overflow."));
}

void resizePixels(
	vBytes& resized,
	const vBytes& pixels,
	unsigned width,
	unsigned new_width,
	unsigned new_height,
	bool is_palette,
	unsigned channels,
	const std::vector<ResizeAxisSample>& x_samples,
	const std::vector<ResizeAxisSample>& y_samples) {

	if (is_palette) {
		resizePaletteImage(resized, pixels, width, new_width, new_height, x_samples, y_samples);
	} else if (channels == 4) {
		resizeTruecolorImage<4>(resized, pixels, width, new_width, new_height, x_samples, y_samples);
	} else {
		resizeTruecolorImage<3>(resized, pixels, width, new_width, new_height, x_samples, y_samples);
	}
}

[[nodiscard]] lodepng::State makeEncodeState(
	const LodePNGColorMode& png_color,
	bool is_palette) {

	lodepng::State encode_state;

	// A color key cannot represent the partial coverage created by filtering.
	const auto output_color_type = png_color.colortype == LCT_RGB && png_color.key_defined
		? LCT_RGBA : png_color.colortype;
	encode_state.info_raw.colortype = output_color_type;
	// Resampling uses one unpacked byte per palette index. LodePNG can convert
	// that raw 8-bit representation back to the original 1/2/4-bit PNG mode.
	encode_state.info_raw.bitdepth = is_palette ? 8 : png_color.bitdepth;
	encode_state.info_png.color.colortype = output_color_type;
	encode_state.info_png.color.bitdepth = png_color.bitdepth;
	encode_state.encoder.auto_convert = 0;

	if (is_palette) {
		image_processing_internal::copyPalette(png_color.palette, png_color.palettesize, encode_state.info_png.color);
		image_processing_internal::copyPalette(png_color.palette, png_color.palettesize, encode_state.info_raw);
	}

	return encode_state;
}

}  // namespace

namespace image_processing_internal {

void resizeImage(vBytes& image_file_vec, unsigned new_width, unsigned new_height) {
	lodepng::State decode_state;
	vBytes pixels;
	unsigned width = 0;
	unsigned height = 0;
	decodePreservingColorType(image_file_vec, pixels, width, height, decode_state);

	validateResizeTarget(new_width, new_height, width, height);
	if (new_width == width && new_height == height) {
		// Nothing to resample — keep the current encoding untouched.
		return;
	}

	const auto& raw = decode_state.info_raw;

	unsigned channels = lodepng_get_channels(&raw);
	const unsigned bitdepth = raw.bitdepth;

	const bool is_palette = (raw.colortype == LCT_PALETTE);
	validateDecodedResizeFormat(is_palette, channels, bitdepth);

	// Sub-byte palette images need conversion to 8-bit palette first; bilinear
	// interpolation on packed palette indices would add disproportionate complexity.
	if (is_palette && bitdepth < 8) {
		redecodeSubBytePalette(image_file_vec, decode_state, pixels, width, height);
		// From here on, treat as 8-bit palette (1 byte per pixel index).
	}

	validateSourceBufferSize(pixels, width, height, bytesPerPixel(is_palette, channels));
	lodepng::State encode_state = makeEncodeState(decode_state.info_png.color, is_palette);
	if (raw.colortype == LCT_RGB && encode_state.info_raw.colortype == LCT_RGBA) {
		vBytes rgba = makeResizedPixelBuffer(width, height, 4);
		const unsigned error = lodepng_convert(
			rgba.data(), pixels.data(), &encode_state.info_raw, &raw, width, height);
		throwLodepngError("LodePNG RGB transparency conversion error", error);
		pixels = std::move(rgba);
		channels = 4;
	}

	// Palette images use 1 byte per pixel index; truecolor uses `channels`.
	const std::size_t pixel_size = bytesPerPixel(is_palette, channels);
	const std::vector<ResizeAxisSample> x_samples = buildResizeAxisSamples(width, new_width);
	const std::vector<ResizeAxisSample> y_samples = buildResizeAxisSamples(height, new_height);

	vBytes resized = makeResizedPixelBuffer(new_width, new_height, pixel_size);
	resizePixels(resized, pixels, width, new_width, new_height, is_palette, channels, x_samples, y_samples);

	// Keep the source format, except RGB color keys now use an alpha channel.
	vBytes output;
	unsigned error = lodepng::encode(output, resized, new_width, new_height, encode_state);
	throwLodepngError("LodePNG encode error", error);

	image_file_vec = std::move(output);
}

}  // namespace image_processing_internal
