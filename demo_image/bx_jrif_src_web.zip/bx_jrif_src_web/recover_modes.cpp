#include "recover_modes.h"
#include "recover_internal.h"
#include "binary_io.h"
#include "embedded_layout.h"
#include "encryption.h"
#include "encryption_internal.h"
#include "file_utils.h"
#include "recover_output.h"
#include "reddit_steg.h"

#include <algorithm>
#include <fstream>
#include <span>
#include <stdexcept>

namespace {
// Smallest secretstream ciphertext: 4-byte frame length + empty-frame ABYTES.
constexpr std::size_t MIN_EMBEDDED_CIPHERTEXT =
    STREAM_FRAME_LEN_BYTES + crypto_secretstream_xchacha20poly1305_ABYTES;

enum class RecoveryFormat : Byte {
    default_icc,
    bluesky,
    reddit,
};

[[nodiscard]] constexpr bool isBlueskyFormat(RecoveryFormat format) noexcept {
    return format == RecoveryFormat::bluesky;
}

[[nodiscard]] constexpr bool isRedditFormat(RecoveryFormat format) noexcept {
    return format == RecoveryFormat::reddit;
}

[[nodiscard]] constexpr std::size_t maxDeclaredSpan(RecoveryFormat format) noexcept {
    switch (format) {
        case RecoveryFormat::default_icc:
            return MAX_EMBEDDED_SPAN_RECOVERY_DEFAULT;
        case RecoveryFormat::bluesky:
            return MAX_EMBEDDED_CIPHERTEXT_BLUESKY;
        case RecoveryFormat::reddit:
            return REDDIT_UPLOAD_SIZE_LIMIT;
    }
    return 0;
}

void validateDeclaredCipherSize(std::size_t embedded_file_size, RecoveryFormat format) {
    throwIf(embedded_file_size == 0, "File Extraction Error: Embedded data file is empty.");
    throwIf(embedded_file_size < MIN_EMBEDDED_CIPHERTEXT, "File Extraction Error: Embedded data file is corrupt!");

    const std::size_t max_size = maxDeclaredSpan(format);
    throwIf(
        embedded_file_size > max_size,
        "File Extraction Error: Embedded data size exceeds the maximum allowed for this format.");
}

// The embedded metadata block always sits at a fixed prefix of the image, so
// read exactly that many bytes and close the stream again before any of it is
// interpreted.
[[nodiscard]] vBytes readEmbeddedMetadata(const fs::path& image_file_path, std::size_t offset, std::size_t size) {
    vBytes metadata_vec(size);
    std::ifstream input = openBinaryInputOrThrow(image_file_path, "Read Error: Failed to open image file.");
    readExactAt(input, offset, std::span<Byte>(metadata_vec));
    return metadata_vec;
}

// Both stages are link-free StagingFile inodes. That matters most for the
// second one: it holds the fully decrypted payload, so a named temporary would
// leave plaintext on disk under a real directory entry -- visible to a backup
// or sync client, and surviving a SIGKILL or power loss. It reaches its final
// name via linkat(2) on /proc/self/fd (tryCommitStagingFileNoReplace), so the
// contents never exist under any name but the one the user is told about.
template <typename WorkFn>
void runWithRecoverStageFiles(WorkFn&& work) {
    StagingFile cipher_stage({}, "cipher");
    StagingFile stream_stage({}, "plain");
    work(cipher_stage, stream_stage);
}

void finalizeRecoveredOutput(DecryptResult decrypt_result, const StagingFile& stream_stage) {
    throwIf(decrypt_result.failed, "File Decryption Error: Invalid recovery PIN or file is corrupt.");

    // Make the decrypted payload durable before it is given its final name and
    // reported as extracted.
    syncStagingFileOrThrow(stream_stage, WRITE_COMPLETE_ERROR);

    const fs::path output_path = commitRecoveredOutput(
        stream_stage,
        validatedRecoveryPath(std::move(decrypt_result.filename)));
    printRecoverySuccess(output_path, decrypt_result.output_size);
}

// Order: validate declared size → PIN/KDF → extract ciphertext → decrypt.
// Extracting before PIN validation would let a crafted image force multi-GB
// staging I/O; size caps also bound work after a wrong PIN.
template <typename ExtractFn>
void recoverFromCipherExtractor(
    vBytes& metadata_vec,
    vBytes& pin_vec,
    RecoveryFormat format,
    bool is_data_compressed,
    std::size_t embedded_file_size,
    ExtractFn&& extract_cipher) {

    validateDeclaredCipherSize(embedded_file_size, format);
    const bool is_bluesky_file = isBlueskyFormat(format);

    runWithRecoverStageFiles([&](StagingFile& cipher_stage, StagingFile& stream_stage) {
        SecureBuffer<Key> key;
        StreamHeader stream_header{};
        const KdfMetadataVersion metadata_version = isRedditFormat(format)
            ? prepareDecryptKeyFromKdfMetadata(
                metadata_vec,
                pin_vec,
                key.buf,
                stream_header)
            : prepareDecryptKeyFromMetadata(
                metadata_vec,
                pin_vec,
                is_bluesky_file,
                key.buf,
                stream_header);

        throwIf(extract_cipher(cipher_stage.path()) == 0, "File Extraction Error: Embedded data file is empty.");

        DecryptResult decrypt_result = decryptDataFileWithKey(
            key.buf,
            stream_header,
            metadata_version,
            cipher_stage.path(),
            stream_stage.path(),
            is_data_compressed);
        finalizeRecoveredOutput(std::move(decrypt_result), stream_stage);
    });
}
} // namespace

void recoverFromIccPath(
    const fs::path& image_file_path,
    std::size_t image_file_size,
    std::size_t icc_profile_sig_index,
    vBytes& pin_vec) {

    throwIf(icc_profile_sig_index < ICC_PROFILE_SIGNATURE_OFFSET, "File Extraction Error: Corrupt ICC metadata.");

    // jdvrif writes the ICC profile at one fixed offset, so a signed profile
    // found anywhere else is a layout this build does not support.
    const std::size_t base_offset = icc_profile_sig_index - ICC_PROFILE_SIGNATURE_OFFSET;
    throwIf(
        base_offset != DEFAULT_TEMPLATE_BASE_OFFSET,
        "File Extraction Error: Unsupported embedded profile layout.");
    throwIf(base_offset > image_file_size ||
        ICC_CIPHER_LAYOUT.encrypted_payload_start_index > image_file_size - base_offset,
        "File Extraction Error: Embedded data file is corrupt!");

    vBytes metadata_vec = readEmbeddedMetadata(
        image_file_path, base_offset, ICC_CIPHER_LAYOUT.encrypted_payload_start_index);

    throwIf(!spanHasRange(metadata_vec, ICC_SEGMENT_LAYOUT.compression_flag_index, 1) ||
        !spanHasRange(metadata_vec, ICC_SEGMENT_LAYOUT.embedded_total_profile_header_segments_index, 2) ||
        !spanHasRange(metadata_vec, ICC_CIPHER_LAYOUT.file_size_index, 4),
        "File Extraction Error: Corrupt metadata.");

    const bool is_data_compressed = (metadata_vec[ICC_SEGMENT_LAYOUT.compression_flag_index] != NO_ZLIB_COMPRESSION_ID);
    const auto total_profile_header_segments = static_cast<std::uint16_t>(
        getValue(metadata_vec, ICC_SEGMENT_LAYOUT.embedded_total_profile_header_segments_index));
    const std::size_t embedded_file_size = getValue(metadata_vec, ICC_CIPHER_LAYOUT.file_size_index, 4);

    recoverFromCipherExtractor(metadata_vec, pin_vec, RecoveryFormat::default_icc, is_data_compressed, embedded_file_size, [&](const fs::path& cipher_path) {
        return extractDefaultCiphertextToFile(
            image_file_path,
            image_file_size,
            base_offset,
            embedded_file_size,
            total_profile_header_segments,
            cipher_path);
    });
}

void recoverFromBlueskyPath(
    const fs::path& image_file_path,
    std::size_t image_file_size,
    std::size_t jdvrif_sig_index,
    vBytes& pin_vec) {

    throwIf(
        BLUESKY_CIPHER_LAYOUT.encrypted_payload_start_index > image_file_size,
        "Image File Error: Corrupt signature metadata.");

    vBytes metadata_vec = readEmbeddedMetadata(
        image_file_path, 0, BLUESKY_CIPHER_LAYOUT.encrypted_payload_start_index);

    throwIf(jdvrif_sig_index > metadata_vec.size() ||
        JDVRIF_SIGNATURE.size() > metadata_vec.size() - jdvrif_sig_index,
        "Image File Error: Corrupt signature metadata.");
    const auto sig_begin = metadata_vec.begin() + static_cast<std::ptrdiff_t>(jdvrif_sig_index);
    throwIf(
        !std::equal(JDVRIF_SIGNATURE.begin(), JDVRIF_SIGNATURE.end(), sig_begin),
        "Image File Error: Corrupt signature metadata.");
    throwIf(
        !spanHasRange(metadata_vec, BLUESKY_CIPHER_LAYOUT.file_size_index, 4),
        "File Extraction Error: Corrupt metadata.");

    const std::size_t embedded_file_size = getValue(metadata_vec, BLUESKY_CIPHER_LAYOUT.file_size_index, 4);

    // is_data_compressed is hardcoded true for Bluesky. A payload is only stored
    // uncompressed when conceal bypasses compression (source > COMPRESS_BYPASS_SIZE,
    // 10 MB), but such a payload always exceeds the 2 MB Bluesky encrypted cap
    // (MAX_EMBEDDED_CIPHERTEXT_BLUESKY) and is rejected at conceal time — so a valid
    // Bluesky image is always zlib-compressed. Revisit this coupling if those limits change.
    recoverFromCipherExtractor(metadata_vec, pin_vec, RecoveryFormat::bluesky, true, embedded_file_size, [&](const fs::path& cipher_path) {
        return extractBlueskyCiphertextToFile(image_file_path, image_file_size, embedded_file_size, cipher_path);
    });
}

void recoverFromRedditPath(
    RedditEncryptedEnvelope envelope,
    vBytes& pin_vec) {

    const std::size_t embedded_file_size =
        envelope.encrypted_data.size();
    recoverFromCipherExtractor(
        envelope.kdf_metadata,
        pin_vec,
        RecoveryFormat::reddit,
        envelope.is_compressed,
        embedded_file_size,
        [&](const fs::path& cipher_path) {
            std::ofstream output =
                openBinaryOutputForStagingOrThrow(cipher_path);
            writeBytesOrThrow(
                output,
                envelope.encrypted_data,
                WRITE_COMPLETE_ERROR);
            closeOutputOrThrow(output, WRITE_COMPLETE_ERROR);
            return embedded_file_size;
        });
}
