#include "args_out.h"

#include <format>
#include <stdexcept>
#include <string_view>

void ProgramArgs::die(const std::string &usage) {
  throw std::runtime_error(usage);
}

namespace {
[[nodiscard]] std::string programName(int argc, char **argv) {
  if (argc >= 1 && argv != nullptr && argv[0] != nullptr) {
    return fs::path(argv[0]).filename().string();
  }
  return "wpdv_out";
}

[[nodiscard]] std::string buildUsage(std::string_view prog) {
  return std::format("Usage: {} <cover_image> <pin_file>", prog);
}

[[nodiscard]] const char *requireArg(int argc, char **argv, int index,
                                     const std::string &usage) {
  if (argv == nullptr || index < 0 || index >= argc || argv[index] == nullptr) {
    ProgramArgs::die(usage);
  }
  return argv[index];
}
} // namespace

ProgramArgs ProgramArgs::parse(int argc, char **argv) {
  const std::string usage = buildUsage(programName(argc, argv));

  if (argc != 3 || std::string_view(requireArg(argc, argv, 1, usage)).empty() ||
      std::string_view(requireArg(argc, argv, 2, usage)).empty()) {
    die(usage);
  }

  ProgramArgs out{};
  out.image_file_path = requireArg(argc, argv, 1, usage);
  out.pin_file_path = requireArg(argc, argv, 2, usage);
  return out;
}
