#include "recover.h"
#include "base64.h"
#include "compression.h"
#include "encryption.h"
#include "io_utils.h"
#include <algorithm>
#include <cctype>
#include <cstring>
#include <format>
#include <optional>
#include <print>
#include <ranges>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>

std::size_t checkedBlueskyProfileSize(std::size_t exif_artist_size,
                                      std::size_t xmp_overflow_size) {
  const std::size_t profile_size = checkedAddSize(
      exif_artist_size, xmp_overflow_size,
      "File Recovery Error: Embedded Bluesky metadata size overflow.");
  if (profile_size > MAX_BLUESKY_UPLOAD_SIZE) {
    throw std::runtime_error(
        "File Recovery Error: Embedded Bluesky metadata exceeds the upload "
        "size limit.");
  }
  return profile_size;
}

fs::path recoveryCollisionCandidate(const fs::path &candidate,
                                    std::size_t index) {
  const std::string filename = candidate.filename().string();
  // Split at the first interior '.' so every part of a multi-part extension
  // stays attached: "archive.tar.gz" -> "archive_1.tar.gz", not the
  // "archive.tar_1.gz" that splitting on the final '.' would produce. The
  // search starts at 1 because a leading '.' is a hidden-file marker rather
  // than a suffix separator (and is rejected upstream anyway).
  const std::size_t suffix_start = filename.find('.', 1);
  std::string_view stem(filename);
  std::string_view extension;
  if (suffix_start != std::string::npos) {
    stem = std::string_view(filename).substr(0, suffix_start);
    extension = std::string_view(filename).substr(suffix_start);
  }
  if (stem.empty()) {
    stem = "recovered";
  }
  // Keep the candidate within NAME_MAX. Embedded names may already be up to
  // 255 bytes, and renameat2 would otherwise fail with ENAMETOOLONG instead of
  // reporting a collision. Shorten the stem (on a UTF-8 code point boundary);
  // if the extension alone leaves no room, fold it into the stem.
  constexpr std::size_t NAME_MAX_BYTES = 255;
  const std::string suffix = std::format("_{}", index);
  if (suffix.size() + extension.size() >= NAME_MAX_BYTES) {
    stem = filename;
    extension = {};
  }
  const std::size_t stem_budget =
      NAME_MAX_BYTES - suffix.size() - extension.size();
  if (stem.size() > stem_budget) {
    std::size_t cut = stem_budget;
    while (cut > 1 &&
           (static_cast<unsigned char>(stem[cut]) & 0xC0U) == 0x80U) {
      --cut;
    }
    stem = stem.substr(0, cut);
  }
  return fs::path(std::format("{}{}{}", stem, suffix, extension));
}

namespace {

constexpr const char *CORRUPT_RIFF_ERROR =
    "Image File Error: Invalid or corrupt WEBP container.";
constexpr const char *CORRUPT_EXIF_ERROR =
    "File Recovery Error: Embedded EXIF data is corrupt.";

constexpr auto RIFF_CHUNK_TAG = std::to_array<Byte>({'R', 'I', 'F', 'F'});
constexpr auto WEBP_CHUNK_TAG = std::to_array<Byte>({'W', 'E', 'B', 'P'});
constexpr auto EXIF_CHUNK_TAG = std::to_array<Byte>({'E', 'X', 'I', 'F'});

struct RiffChunkSet {
  std::optional<std::span<const Byte>> iccp;
  std::optional<std::span<const Byte>> exif;
  std::optional<std::span<const Byte>> xmp;
};

enum class ByteOrder : Byte { little = 0, big = 1 };

constexpr std::size_t TIFF_HEADER_OFFSET = 6;
constexpr std::size_t MAX_IFD_ENTRIES = 64;
constexpr std::uint16_t TIFF_MAGIC = 42;
constexpr std::uint16_t EXIF_ARTIST_TAG = 0x013B;
constexpr std::uint16_t EXIF_ASCII_TYPE = 0x0002;

template <std::size_t N>
[[nodiscard]] std::optional<std::size_t>
searchSig(std::span<const Byte> vec, const std::array<Byte, N> &sig) {
  if constexpr (N == 0) {
    return 0;
  }
  if (vec.size() < N) {
    return std::nullopt;
  }
  const Byte *const begin = vec.data();
  const Byte *const end = begin + (vec.size() - N + 1);
  const Byte *current = begin;
  while (current < end) {
    const auto remaining = static_cast<std::size_t>(end - current);
    const void *found = std::memchr(current, sig[0], remaining);
    if (found == nullptr) {
      return std::nullopt;
    }
    current = static_cast<const Byte *>(found);
    if (N == 1 || std::memcmp(current, sig.data(), N) == 0) {
      return static_cast<std::size_t>(current - begin);
    }
    ++current;
  }
  return std::nullopt;
}

[[nodiscard]] std::uint16_t readExif16(std::span<const Byte> data,
                                       std::size_t offset,
                                       ByteOrder byte_order) {
  return byte_order == ByteOrder::big ? readBe16At(data, offset)
                                      : readLe16At(data, offset);
}

[[nodiscard]] std::uint32_t readExif32(std::span<const Byte> data,
                                       std::size_t offset,
                                       ByteOrder byte_order) {
  return byte_order == ByteOrder::big ? readBe32At(data, offset)
                                      : readLe32At(data, offset);
}

[[nodiscard]] std::span<const Byte>
parseRiffWebP(std::span<const Byte> image_data) {
  requireSpanRange(image_data, 0, 12, CORRUPT_RIFF_ERROR);
  if (!std::ranges::equal(image_data.first(RIFF_CHUNK_TAG.size()),
                          RIFF_CHUNK_TAG) ||
      !std::ranges::equal(image_data.subspan(8, WEBP_CHUNK_TAG.size()),
                          WEBP_CHUNK_TAG)) {
    throw std::runtime_error("Error: Not a valid WEBP image.");
  }
  const std::size_t riff_total_size =
      checkedAddSize(8, static_cast<std::size_t>(readLe32At(image_data, 4)),
                     CORRUPT_RIFF_ERROR);
  if (riff_total_size - 8 < WEBP_CHUNK_TAG.size() ||
      !spanHasRange(image_data, 0, riff_total_size)) {
    throw std::runtime_error(CORRUPT_RIFF_ERROR);
  }
  return image_data.first(riff_total_size);
}

[[nodiscard]] RiffChunkSet findRelevantChunks(std::span<const Byte> riff_file) {
  RiffChunkSet chunks;
  for (std::size_t offset = 12; offset < riff_file.size();) {
    requireSpanRange(riff_file, offset, 8, CORRUPT_RIFF_ERROR);
    const std::uint32_t chunk_size = readLe32At(riff_file, offset + 4);
    const std::size_t data_offset =
        checkedAddSize(offset, 8, CORRUPT_RIFF_ERROR);
    std::size_t padded_chunk_size = checkedAddSize(
        static_cast<std::size_t>(chunk_size),
        static_cast<std::size_t>(chunk_size & 1U), CORRUPT_RIFF_ERROR);
    if (!spanHasRange(riff_file, data_offset, padded_chunk_size)) {
      // Some muxers omit the pad byte after an odd-sized final chunk. Accept
      // exactly that case; any other overrun is still corruption.
      if (padded_chunk_size == chunk_size ||
          !spanHasRange(riff_file, data_offset, chunk_size) ||
          data_offset + chunk_size != riff_file.size()) {
        throw std::runtime_error(CORRUPT_RIFF_ERROR);
      }
      padded_chunk_size = chunk_size;
    }
    const auto tag = riff_file.subspan(offset, ICCP_CHUNK_TAG.size());
    const auto chunk_data = std::span<const Byte>(
        riff_file.data() + static_cast<std::ptrdiff_t>(data_offset),
        chunk_size);
    if (!chunks.iccp && std::ranges::equal(tag, ICCP_CHUNK_TAG)) {
      chunks.iccp = chunk_data;
    } else if (!chunks.exif && std::ranges::equal(tag, EXIF_CHUNK_TAG)) {
      chunks.exif = chunk_data;
    } else if (!chunks.xmp && std::ranges::equal(tag, XMP_CHUNK_TAG)) {
      chunks.xmp = chunk_data;
    }
    offset = checkedAddSize(data_offset, padded_chunk_size, CORRUPT_RIFF_ERROR);
  }
  return chunks;
}

// Offset of the embedded profile within `iccp_data`, or nullopt when this is
// not a wbpdv payload. Returning it saves the recovery path a second scan.
[[nodiscard]] std::optional<std::size_t>
findIccProfileStart(std::span<const Byte> iccp_data) {
  const auto icc_pos = searchSig(iccp_data, ICC_PROFILE_SIGNATURE);
  if (!icc_pos || *icc_pos < ICC_SIG_OFFSET_FROM_PROFILE_START) {
    return std::nullopt;
  }
  const std::size_t profile_start =
      *icc_pos - ICC_SIG_OFFSET_FROM_PROFILE_START;
  const auto profile_data = iccp_data.subspan(profile_start);
  if (!spanHasRange(profile_data, WEBP_EXTRACT_OFFSETS.kdf_metadata,
                    KDF_METADATA_REGION_BYTES)) {
    return std::nullopt;
  }
  // Unlike the Bluesky path, which derives both offsets from where the marker
  // is found, this path decrypts at the fixed template offset. Require the
  // marker exactly where that offset implies rather than anywhere in the
  // profile: a displaced marker can never decrypt, so it should be reported as
  // "not a wbpdv image" instead of costing the user a wasted upload and a full
  // Argon2id derivation first.
  const auto wdv_pos = searchSig(profile_data, WDV_SIGNATURE);
  if (!wdv_pos || checkedAddSize(*wdv_pos, WDV_SIGNATURE_SPAN,
                                 "Image File Error: Corrupt profile "
                                 "location.") !=
                      WEBP_EXTRACT_OFFSETS.encrypted_file) {
    return std::nullopt;
  }
  return profile_start;
}

// Offset of the WDV marker within `exif_data`, or nullopt when it is absent or
// too close to the start for the KDF metadata that precedes it.
[[nodiscard]] std::optional<std::size_t>
findBlueskyWdvMarker(std::span<const Byte> exif_data) {
  const auto wdv_pos = searchSig(exif_data, WDV_SIGNATURE);
  if (!wdv_pos || *wdv_pos < BLUESKY_WDV_TO_KDF ||
      !spanHasRange(exif_data, *wdv_pos - BLUESKY_WDV_TO_KDF,
                    KDF_METADATA_REGION_BYTES)) {
    return std::nullopt;
  }
  return wdv_pos;
}

[[nodiscard]] ByteOrder parseExifByteOrder(std::span<const Byte> exif_data) {
  requireSpanRange(exif_data, TIFF_HEADER_OFFSET, 8, CORRUPT_EXIF_ERROR);
  if (exif_data[TIFF_HEADER_OFFSET] == 'M' &&
      exif_data[TIFF_HEADER_OFFSET + 1] == 'M') {
    return ByteOrder::big;
  }
  if (exif_data[TIFF_HEADER_OFFSET] == 'I' &&
      exif_data[TIFF_HEADER_OFFSET + 1] == 'I') {
    return ByteOrder::little;
  }
  throw std::runtime_error(CORRUPT_EXIF_ERROR);
}

[[nodiscard]] std::size_t findExifArtistEnd(std::span<const Byte> exif_data) {
  requireSpanRange(exif_data, 0, EXIF_HEADER_SIGNATURE.size(),
                   CORRUPT_EXIF_ERROR);
  if (!std::ranges::equal(exif_data.first(EXIF_HEADER_SIGNATURE.size()),
                          EXIF_HEADER_SIGNATURE)) {
    throw std::runtime_error(
        "Image File Error: Cannot locate EXIF data in image.");
  }

  const ByteOrder byte_order = parseExifByteOrder(exif_data);
  if (readExif16(exif_data, TIFF_HEADER_OFFSET + 2, byte_order) != TIFF_MAGIC) {
    throw std::runtime_error(CORRUPT_EXIF_ERROR);
  }
  const std::size_t ifd_count_offset =
      checkedAddSize(TIFF_HEADER_OFFSET,
                     static_cast<std::size_t>(readExif32(
                         exif_data, TIFF_HEADER_OFFSET + 4, byte_order)),
                     CORRUPT_EXIF_ERROR);
  requireSpanRange(exif_data, ifd_count_offset, 2, CORRUPT_EXIF_ERROR);
  const std::uint16_t ifd_count =
      readExif16(exif_data, ifd_count_offset, byte_order);
  if (ifd_count == 0 || ifd_count > MAX_IFD_ENTRIES) {
    throw std::runtime_error(CORRUPT_EXIF_ERROR);
  }

  for (std::uint16_t i = 0; i < ifd_count; ++i) {
    const std::size_t entry_index_bytes =
        checkedMulSize(static_cast<std::size_t>(i), 12, CORRUPT_EXIF_ERROR);
    const std::size_t entry_off =
        checkedSum(CORRUPT_EXIF_ERROR, ifd_count_offset, 2, entry_index_bytes);
    requireSpanRange(exif_data, entry_off, 12, CORRUPT_EXIF_ERROR);
    if (readExif16(exif_data, entry_off, byte_order) != EXIF_ARTIST_TAG) {
      continue;
    }
    const std::uint16_t type = readExif16(exif_data, entry_off + 2, byte_order);
    const std::uint32_t artist_count =
        readExif32(exif_data, entry_off + 4, byte_order);
    const std::uint32_t artist_tiff_offset =
        readExif32(exif_data, entry_off + 8, byte_order);
    if (type != EXIF_ASCII_TYPE || artist_count == 0) {
      throw std::runtime_error(CORRUPT_EXIF_ERROR);
    }
    const std::size_t artist_data_offset = checkedAddSize(
        TIFF_HEADER_OFFSET, static_cast<std::size_t>(artist_tiff_offset),
        CORRUPT_EXIF_ERROR);
    requireSpanRange(exif_data, artist_data_offset,
                     static_cast<std::size_t>(artist_count),
                     CORRUPT_EXIF_ERROR);
    return checkedAddSize(artist_data_offset,
                          static_cast<std::size_t>(artist_count),
                          CORRUPT_EXIF_ERROR);
  }
  throw std::runtime_error(CORRUPT_EXIF_ERROR);
}

constexpr std::size_t MAX_RECOVERY_NAME_ATTEMPTS = 10000;

[[nodiscard]] fs::path safeRecoveryPath(std::string decrypted_filename) {
  constexpr std::size_t MAX_RECOVERED_FILENAME_LEN = 255;
  if (decrypted_filename.empty() ||
      decrypted_filename.size() > MAX_RECOVERED_FILENAME_LEN) {
    throw std::runtime_error(
        "File Recovery Error: Recovered filename is unsafe.");
  }
  fs::path parsed(std::move(decrypted_filename));
  if (parsed.has_root_path() || parsed.has_parent_path() ||
      parsed != parsed.filename() || !hasSafeEmbeddedFilename(parsed)) {
    throw std::runtime_error(
        "File Recovery Error: Recovered filename is unsafe.");
  }
  return parsed.filename();
}

void commitRecoveredFile(UniqueFileHandle &staged_file,
                         const fs::path &output_base,
                         std::size_t recovered_size) {
  syncFdOrThrow(staged_file.fd(),
                "Write File Error: Failed to sync output file: ");
  staged_file.closeOrThrow();

  // The atomic no-replace rename is the existence check, so there is no
  // exists-then-rename window: on EEXIST the already-staged bytes are simply
  // retried under the next collision candidate instead of failing.
  fs::path committed_path;
  for (std::size_t i = 0; i <= MAX_RECOVERY_NAME_ATTEMPTS; ++i) {
    const fs::path candidate =
        i == 0 ? output_base : recoveryCollisionCandidate(output_base, i);
    if (tryCommitPathAtomically(
            staged_file.path(), candidate,
            "Write File Error: Failed to commit recovered file: ")) {
      committed_path = candidate;
      break;
    }
  }
  if (committed_path.empty()) {
    throw std::runtime_error(
        "Write File Error: Unable to create a unique output filename.");
  }
  // Staged path was renamed into place; drop ownership so the destructor does
  // not attempt to unlink the committed destination.
  staged_file.release();
  std::println("\nExtracted hidden file: {} ({} bytes).\n\nComplete! Please "
               "check your file.\n",
               committed_path.string(), recovered_size);
}

void decryptInflateAndWrite(vBytes &image_vec, vBytes &pin_vec,
                            const ProfileOffsets &offsets,
                            std::string_view corrupt_error) {
  requireSpanRange(image_vec, offsets.kdf_metadata, KDF_METADATA_REGION_BYTES,
                   corrupt_error);
  // From a successful decryption on, image_vec holds the compressed plaintext.
  // Guard it before decrypting so every exit path scrubs it, including a
  // filename or inflate failure after authentication succeeded.
  SensitiveBytesGuard plaintext_guard(image_vec);
  auto result = decryptDataFile(image_vec, pin_vec, offsets);
  if (!result) {
    throw std::runtime_error(
        "File Recovery Error: Invalid PIN or file is corrupt.");
  }
  const fs::path output_base = safeRecoveryPath(std::move(*result));

  // Inflate straight into the staged file: the recovered plaintext is never
  // held in memory as a whole. On any failure the handle's destructor unlinks
  // the partial staged file.
  auto staged_file = createUniqueFile(
      output_base.parent_path(), ".wbpdv_tmp_", "", 1024,
      "Write File Error: Unable to create temp output file: ",
      "Write File Error: Unable to allocate temporary output filename.");
  const std::size_t recovered_size =
      zlibInflateToFd(byteSpan(image_vec), staged_file.fd());
  plaintext_guard.wipe();
  commitRecoveredFile(staged_file, output_base, recovered_size);
}

void recoverFromIccPath(vBytes &image_vec, vBytes &pin_vec,
                        std::span<const Byte> iccp_data,
                        std::size_t profile_start) {
  // iccp_data is a span into image_vec; shift the profile to the front in place
  // and truncate, instead of allocating a separate profile vector.
  const std::size_t profile_offset =
      static_cast<std::size_t>(iccp_data.data() - image_vec.data()) +
      profile_start;
  const std::size_t profile_length = iccp_data.size() - profile_start;
  std::memmove(image_vec.data(), image_vec.data() + profile_offset,
               profile_length);
  image_vec.resize(profile_length);

  decryptInflateAndWrite(image_vec, pin_vec, WEBP_EXTRACT_OFFSETS,
                         "File Recovery Error: Embedded profile is corrupt.");
}

[[nodiscard]] vBytes extractXmpOverflowData(std::span<const Byte> xmp_data) {
  constexpr const char *XMP_ERROR = "File Extraction Error: Corrupt XMP data.";
  if (xmp_data.empty()) {
    return {};
  }
  auto rdfli_pos = searchSig(xmp_data, XMP_RDFLI_SIGNATURE);
  if (!rdfli_pos) {
    return {};
  }
  const auto start_it =
      std::find(xmp_data.begin() + static_cast<std::ptrdiff_t>(
                                       *rdfli_pos + XMP_RDFLI_SIGNATURE.size()),
                xmp_data.end(), static_cast<Byte>('>'));
  if (start_it == xmp_data.end()) {
    throw std::runtime_error(XMP_ERROR);
  }
  std::size_t base64_begin =
      static_cast<std::size_t>(std::distance(xmp_data.begin(), start_it)) + 1;
  while (base64_begin < xmp_data.size() &&
         std::isspace(static_cast<unsigned char>(xmp_data[base64_begin])) !=
             0) {
    ++base64_begin;
  }
  if (base64_begin >= xmp_data.size()) {
    throw std::runtime_error(XMP_ERROR);
  }
  auto end_it =
      std::find(xmp_data.begin() + static_cast<std::ptrdiff_t>(base64_begin),
                xmp_data.end(), XMP_BASE64_END_DELIM);
  if (end_it == xmp_data.end()) {
    throw std::runtime_error(XMP_ERROR);
  }
  std::size_t base64_end =
      static_cast<std::size_t>(std::distance(xmp_data.begin(), end_it));
  while (base64_end > base64_begin && std::isspace(static_cast<unsigned char>(
                                          xmp_data[base64_end - 1])) != 0) {
    --base64_end;
  }
  if (base64_end <= base64_begin) {
    throw std::runtime_error(XMP_ERROR);
  }
  std::span<const Byte> base64_span(
      xmp_data.data() + static_cast<std::ptrdiff_t>(base64_begin),
      base64_end - base64_begin);
  vBytes decoded;
  appendBase64AsBinary(base64_span, decoded, MAX_BLUESKY_UPLOAD_SIZE);
  return decoded;
}

void recoverFromBlueskyPath(vBytes &image_vec, vBytes &pin_vec,
                            std::span<const Byte> exif_data,
                            std::span<const Byte> xmp_data,
                            std::size_t wdv_pos) {
  const std::size_t kdf_offset = wdv_pos - BLUESKY_WDV_TO_KDF;
  const std::size_t encrypted_offset =
      checkedAddSize(wdv_pos, WDV_SIGNATURE_SPAN, CORRUPT_EXIF_ERROR);
  const std::size_t artist_end = findExifArtistEnd(exif_data);
  if (wdv_pos >= artist_end || encrypted_offset > artist_end) {
    throw std::runtime_error(CORRUPT_EXIF_ERROR);
  }

  // Bluesky keeps overflow encrypted bytes in XMP when the EXIF artist field
  // is not large enough to hold the full ciphertext. Reject an oversized
  // Artist field before doing any XMP scan or Base64 allocation.
  (void)checkedBlueskyProfileSize(artist_end, 0);
  vBytes xmp_overflow = extractXmpOverflowData(xmp_data);
  const std::size_t profile_size =
      checkedBlueskyProfileSize(artist_end, xmp_overflow.size());

  // The strict Bluesky limit above is checked before allocation, so this copy
  // is bounded to 2,000,000 bytes even if a hostile input contains an enormous
  // EXIF chunk. Moving it into image_vec also releases the original image's
  // potentially much larger backing allocation before PIN derivation/inflate.
  vBytes profile(profile_size);
  std::memcpy(profile.data(), exif_data.data(), artist_end);
  if (!xmp_overflow.empty()) {
    std::memcpy(profile.data() + static_cast<std::ptrdiff_t>(artist_end),
                xmp_overflow.data(), xmp_overflow.size());
  }
  image_vec = std::move(profile);
  const ProfileOffsets bluesky_offsets = {kdf_offset, encrypted_offset};
  if (xmp_overflow.empty() &&
      !hasCompleteCiphertextFraming(image_vec, bluesky_offsets)) {
    throw std::runtime_error(
        "File Recovery Error: Embedded data is incomplete. The XMP metadata "
        "that holds the rest of the encrypted data is missing; it may have "
        "been stripped by the platform or an image editor.");
  }
  decryptInflateAndWrite(image_vec, pin_vec, bluesky_offsets,
                         CORRUPT_EXIF_ERROR);
}
} // namespace

void recoverData(vBytes &image_vec, vBytes &pin_vec) {
  const auto riff_file = parseRiffWebP(byteSpan(image_vec));
  const RiffChunkSet chunks = findRelevantChunks(riff_file);

  if (chunks.iccp) {
    if (const auto profile_start = findIccProfileStart(*chunks.iccp)) {
      recoverFromIccPath(image_vec, pin_vec, *chunks.iccp, *profile_start);
      return;
    }
  }

  if (chunks.exif) {
    if (const auto wdv_pos = findBlueskyWdvMarker(*chunks.exif)) {
      recoverFromBlueskyPath(image_vec, pin_vec, *chunks.exif,
                             chunks.xmp.value_or(std::span<const Byte>{}),
                             *wdv_pos);
      return;
    }
  }
  throw std::runtime_error("Image File Error: Signature check failure. This is "
                           "not a valid wbpdv file-embedded image.");
}
