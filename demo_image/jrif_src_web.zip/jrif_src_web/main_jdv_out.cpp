// JPG Data Vehicle (jdv_out) Created by Nicholas Cleasby (@CleasbyCode) 10/04/2023

#include "common.h"
#include "file_utils.h"
#include "program_args_out.h"
#include "recover.h"

#include <iostream>
#include <print>
#include <stdexcept>

namespace {
void initializeCrypto() {
    if (sodium_init() < 0) {
        throw std::runtime_error("Libsodium initialization failed!");
    }
}

[[nodiscard]] int run(int argc, char** argv) {
    initializeCrypto();
    auto args = ProgramArgs::parse(argc, argv);
    vBytes pin_vec = readFile(args.pin_file_path, FileTypeCheck::pin_file);
    recoverData(args.image_file_path, pin_vec);
    return 0;
}
}

int main(int argc, char** argv) {
    try {
        return run(argc, argv);
    } catch (const std::exception& e) {
        std::println(std::cerr, "\n{}\n", e.what());
        return 1;
    } catch (...) {
        std::println(std::cerr, "\nUnknown fatal error.\n");
        return 1;
    }
}
