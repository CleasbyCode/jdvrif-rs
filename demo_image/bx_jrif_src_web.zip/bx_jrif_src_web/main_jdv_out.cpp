// JPG Data Vehicle (jdv_out) Created by Nicholas Cleasby (@CleasbyCode) 10/04/2023

#include "common.h"
#include "file_utils.h"
#include "program_args_out.h"
#include "recover.h"
#include "signal_utils.h"

#include <iostream>
#include <print>
#include <stdexcept>

namespace {
struct PinContentsGuard {
    vBytes& bytes;

    explicit PinContentsGuard(vBytes& value) noexcept : bytes(value) {}
    PinContentsGuard(const PinContentsGuard&) = delete;
    PinContentsGuard& operator=(const PinContentsGuard&) = delete;

    ~PinContentsGuard() {
        if (!bytes.empty()) {
            sodium_memzero(bytes.data(), bytes.size());
        }
        bytes.clear();
    }
};

[[nodiscard]] int run(int argc, char** argv) {
    throwIf(sodium_init() < 0, "Libsodium initialization failed!");
    auto args = ProgramArgs::parse(argc, argv);
    vBytes pin_vec = readFile(args.pin_file_path, FileTypeCheck::pin_file);
    PinContentsGuard pin_guard(pin_vec);
    recoverData(args.image_file_path, pin_vec);
    return 0;
}
} // namespace

int main(int argc, char** argv) {
    try {
        installProcessSignalHandlers();
        return run(argc, argv);
    } catch (const SignalCancellation& interruption) {
        reraiseSignalAfterCleanup(interruption.signalNumber());
    } catch (const std::exception& e) {
        std::println(std::cerr, "\n{}\n", e.what());
        return 1;
    } catch (...) {
        std::println(std::cerr, "\nUnknown fatal error.\n");
        return 1;
    }
}
