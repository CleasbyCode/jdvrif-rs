#pragma once

#include "common.h"

void recoverData(vBytes& image_vec, vBytes& passphrase_vec);
