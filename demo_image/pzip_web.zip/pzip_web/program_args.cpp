#include "pdvzip.h"

ProgramArgs ProgramArgs::parse(int argc, char** argv) {
	if (argc < 1 || argv[0] == nullptr) {
		throw std::runtime_error("Invalid program invocation: missing program name");
	}

	if (argc != 5) {
		const std::string prog = fs::path(argv[0]).filename().string();
		throw std::runtime_error(std::format(
			"Usage: {} <cover_image> <zip/jar> <linux_args.txt> <windows_args.txt>",
			prog));
	}

	return ProgramArgs{
		.image_file_path       = argv[1],
		.archive_file_path     = argv[2],
		.linux_args_filename   = argv[3],
		.windows_args_filename = argv[4]
	};
}
