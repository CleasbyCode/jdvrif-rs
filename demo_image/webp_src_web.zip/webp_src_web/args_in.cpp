#include "args_in.h"

#include <format>
#include <stdexcept>
#include <string_view>

void ProgramArgs::die(const std::string& usage) {
  throw std::runtime_error(usage);
}

namespace {
[[nodiscard]] const char* requireArg(int argc, char** argv, int index, const std::string& usage) {
  if (argv == nullptr || index < 0 || index >= argc || argv[index] == nullptr) {
    ProgramArgs::die(usage);
  }
  return argv[index];
}
} // namespace

ProgramArgs ProgramArgs::parse(int argc, char** argv) {
  const std::string prog = (argc >= 1 && argv != nullptr && argv[0] != nullptr) ? fs::path(argv[0]).filename().string() : std::string{"wpdv_in"};
  const std::string usage = std::format("Usage: {} [-b] <cover_image> <secret_file>", prog);

  ProgramArgs out{};
  int i = 1;

  if (i < argc && std::string_view(requireArg(argc, argv, i, usage)) == "-b") {
    out.option = Option::Bluesky;
    ++i;
  }

  if (i + 2 != argc || std::string_view(requireArg(argc, argv, i, usage)).empty() ||
      std::string_view(requireArg(argc, argv, i + 1, usage)).empty()) {
    die(usage);
  }

  out.image_file_path = requireArg(argc, argv, i, usage);
  out.data_file_path = requireArg(argc, argv, i + 1, usage);
  return out;
}
