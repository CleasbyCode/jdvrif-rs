#!/bin/bash
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
IN_BIN="${JDV_IN_BIN:-$ROOT/jdv_in}"
OUT_BIN="${JDV_OUT_BIN:-$ROOT/jdv_out}"
NO_BUILD=0

usage() {
    cat <<'EOF'
Usage: tests/run_tests.sh [options]

Options:
  --no-build        Reuse existing binaries.
  --in-bin <path>   Use an explicit jdv_in binary path.
  --out-bin <path>  Use an explicit jdv_out binary path.
  -h, --help        Show this help.

JDV_IN_BIN and JDV_OUT_BIN provide the same binary overrides.
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --no-build)
            NO_BUILD=1
            shift
            ;;
        --in-bin)
            [[ $# -ge 2 ]] || { echo "--in-bin requires a path" >&2; exit 2; }
            IN_BIN="$2"
            NO_BUILD=1
            shift 2
            ;;
        --out-bin)
            [[ $# -ge 2 ]] || { echo "--out-bin requires a path" >&2; exit 2; }
            OUT_BIN="$2"
            NO_BUILD=1
            shift 2
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            usage >&2
            exit 2
            ;;
    esac
done

if [[ "$IN_BIN" != /* ]]; then IN_BIN="$(pwd -P)/${IN_BIN#./}"; fi
if [[ "$OUT_BIN" != /* ]]; then OUT_BIN="$(pwd -P)/${OUT_BIN#./}"; fi

if [[ "$NO_BUILD" -eq 0 ]]; then
    (cd "$ROOT" && bash ./compile_jdv_in.sh && bash ./compile_jdv_out.sh)
fi

COMMON_ARGS=(--no-build --in-bin "$IN_BIN" --out-bin "$OUT_BIN")
bash "$ROOT/tests/run_golden_tests.sh" --no-build --out-bin "$OUT_BIN"
bash "$ROOT/tests/run_roundtrip_tests.sh" "${COMMON_ARGS[@]}"
bash "$ROOT/tests/run_security_smoke.sh" "${COMMON_ARGS[@]}"
