#pragma once

#include "common.h"

void displayRedditCapacity(vBytes& png_vec);
void concealData(vBytes& png_vec, Option option, const fs::path& data_file_path);
