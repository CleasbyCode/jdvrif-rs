#include "pdvzip.h"

namespace {

vBytes readArgsFile(const fs::path& filepath) {
	if (!fs::exists(filepath)) {
		return vBytes{0x20};
	}

	const auto file_size = fs::file_size(filepath);
	if (file_size == 0) {
		return vBytes{0x20};
	}

	std::ifstream ifs(filepath, std::ios::binary);
	if (!ifs) {
		return vBytes{0x20};
	}

	vBytes data(file_size);
	ifs.read(reinterpret_cast<char*>(data.data()), static_cast<std::streamsize>(file_size));
	return data;
}

} // anonymous namespace

UserArguments loadArguments(FileType file_type, const fs::path& linux_args_file,
                            const fs::path& windows_args_file) {
	UserArguments args;

	const bool needs_args =
		(file_type > FileType::PDF && file_type < FileType::UNKNOWN_FILE_TYPE)
		|| file_type == FileType::LINUX_EXECUTABLE
		|| file_type == FileType::JAR;

	if (!needs_args) {
		return args;
	}

	if (file_type != FileType::WINDOWS_EXECUTABLE) {
		args.linux_args = readArgsFile(linux_args_file);
	}

	if (file_type != FileType::LINUX_EXECUTABLE) {
		args.windows_args = readArgsFile(windows_args_file);
	}

	return args;
}
