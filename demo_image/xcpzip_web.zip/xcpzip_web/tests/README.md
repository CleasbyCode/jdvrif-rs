Run the web variant's regression checks from its source directory:

```sh
python3 tests/run_tests.py
```

To retain the build for subsequent runs:

```sh
python3 tests/run_tests.py --build-dir /tmp/pdvzip-web-tests
```

The runner builds the web source with CMake and runs seven C++ suites, 31 Linux
launcher cases, and a 4096 × 4096 indexed-image case under a 64 MiB address-space
limit. Fixtures and generated polyglots stay in temporary directories.

Coverage includes archive metadata and path limits, output-name exhaustion,
descriptor-based output handling, extraction collisions, shell parsing and
quoting, alpha-correct resizing, native indexed decoding, basename classification,
and FIFO rejection. The web argument-file tests also check the four-path CLI,
optional and empty files, CRLF trimming, byte-preserving argument loading,
1024-byte limits, symlink rejection, and platform-specific argument selection.

The launcher tests invoke the web binary with Linux and Windows argument files
and closed stdin. They use benign payloads and stub desktop/media launchers.
Windows script rendering is checked by the C++ tests; this Linux suite does not
execute the generated scripts on Windows.
