#include "pdvzip.h"

namespace {

constexpr std::size_t
	ICCP_CHUNK_INDEX            = 0x21,
	VALUE_BYTE_LENGTH_FOUR      = 4,
	ARCHIVE_INSERT_INDEX_DIFF   = 12,
	EXCLUDE_SIZE_AND_CRC_LENGTH = 8,
	LAST_IDAT_INDEX_DIFF        = 4,
	LAST_IDAT_CRC_INDEX_DIFF    = 16;

struct ZipEocdInfo {
	std::size_t index;
	uint16_t total_records;
	uint32_t central_size;
	uint32_t central_offset;
	uint16_t comment_length;
};

[[nodiscard]] ZipEocdInfo findZipEocd(
	std::span<const Byte> image_vec,
	std::size_t zip_base_offset,
	std::size_t zip_end_offset) {


	constexpr std::size_t
		EOCD_MIN_SIZE             = 22,
		EOCD_DISK_NUMBER_OFFSET   = 4,
		EOCD_CENTRAL_DISK_OFFSET  = 6,
		EOCD_RECORDS_ON_DISK      = 8,
		EOCD_TOTAL_RECORDS_OFFSET = 10,
		EOCD_CENTRAL_SIZE_OFFSET  = 12,
		EOCD_CENTRAL_OFFSET       = 16;

	if (zip_end_offset > image_vec.size() || zip_end_offset < zip_base_offset
		|| zip_end_offset - zip_base_offset < EOCD_MIN_SIZE) {
		throw std::runtime_error("ZIP Error: Archive is too small.");
	}

	const auto locator = findZipEocdLocator(image_vec, zip_base_offset, zip_end_offset);
	if (!locator) {
		throw std::runtime_error("ZIP Error: End of Central Directory signature not found.");
	}

	const std::size_t pos = locator->index;
	const auto info = ZipEocdInfo{
		.index          = pos,
		.total_records  = readLe16(image_vec, pos + EOCD_TOTAL_RECORDS_OFFSET),
		.central_size   = readLe32(image_vec, pos + EOCD_CENTRAL_SIZE_OFFSET),
		.central_offset = readLe32(image_vec, pos + EOCD_CENTRAL_OFFSET),
		.comment_length = locator->comment_length,
	};

	const uint16_t disk_number = readLe16(image_vec, pos + EOCD_DISK_NUMBER_OFFSET);
	const uint16_t central_disk = readLe16(image_vec, pos + EOCD_CENTRAL_DISK_OFFSET);
	const uint16_t records_on_disk = readLe16(image_vec, pos + EOCD_RECORDS_ON_DISK);

	if (disk_number != 0 || central_disk != 0 || records_on_disk != info.total_records
		|| info.total_records == UINT16_MAX || info.central_size == UINT32_MAX
		|| info.central_offset == UINT32_MAX) {
		throw std::runtime_error("ZIP Error: ZIP64 or multi-disk archives are not supported.");
	}
	if (info.total_records == 0) {
		throw std::runtime_error("ZIP Error: Archive contains no records.");
	}

	const std::size_t central_start = checkedAdd(
		zip_base_offset,
		static_cast<std::size_t>(info.central_offset),
		"ZIP Error: Central directory offset overflow.");
	const std::size_t central_end = checkedAdd(
		central_start,
		static_cast<std::size_t>(info.central_size),
		"ZIP Error: Central directory size overflow.");
	if (central_start > zip_end_offset || central_end > zip_end_offset || central_end != pos) {
		throw std::runtime_error("ZIP Error: Central directory bounds are invalid.");
	}
	return info;
}

// Fix all ZIP record offsets so the archive remains valid after being embedded
// behind the PNG wrapper bytes.
void fixZipOffsets(vBytes& image_vec, std::size_t original_image_size, std::size_t script_data_size) {
	constexpr std::size_t
		ZIP_BASE_SHIFT                 = 8,
		PNG_TRAILING_BYTES             = 16,
		CENTRAL_RECORD_MIN_SIZE        = 46,
		CENTRAL_NAME_LENGTH_OFFSET     = 28,
		CENTRAL_EXTRA_LENGTH_OFFSET    = 30,
		CENTRAL_COMMENT_LENGTH_OFFSET  = 32,
		CENTRAL_DISK_START_OFFSET      = 34,
		CENTRAL_LOCAL_OFFSET_OFFSET    = 42;

	const std::size_t zip_base_offset = checkedAdd(
		checkedAdd(original_image_size, script_data_size, "ZIP Error: Base offset overflow."),
		ZIP_BASE_SHIFT,
		"ZIP Error: Base offset overflow.");
	if (image_vec.size() < PNG_TRAILING_BYTES) {
		throw std::runtime_error("ZIP Error: Embedded image is truncated.");
	}
	const std::size_t zip_end_offset = image_vec.size() - PNG_TRAILING_BYTES;
	const ZipEocdInfo eocd = findZipEocd(image_vec, zip_base_offset, zip_end_offset);
	const std::size_t central_start = checkedAdd(
		zip_base_offset,
		static_cast<std::size_t>(eocd.central_offset),
		"ZIP Error: Central directory offset overflow.");
	const std::size_t central_end = checkedAdd(
		central_start,
		static_cast<std::size_t>(eocd.central_size),
		"ZIP Error: Central directory size overflow.");

	if (central_start > zip_end_offset || central_end > zip_end_offset || central_end != eocd.index) {
		throw std::runtime_error("ZIP Error: Central directory bounds are invalid.");
	}
	if (central_start > UINT32_MAX) {
		throw std::runtime_error("ZIP Error: Central directory offset exceeds ZIP32 limits.");
	}
	if (eocd.comment_length > UINT16_MAX - PNG_TRAILING_BYTES) {
		throw std::runtime_error("ZIP Error: Comment length overflow.");
	}

	writeLe16(image_vec, eocd.index + 20, static_cast<uint16_t>(eocd.comment_length + PNG_TRAILING_BYTES));
	writeLe32(image_vec, eocd.index + 16, static_cast<uint32_t>(central_start));

	std::size_t cursor = central_start;
	for (uint16_t i = 0; i < eocd.total_records; ++i) {
		if (cursor > image_vec.size() || CENTRAL_RECORD_MIN_SIZE > image_vec.size() - cursor) {
			throw std::runtime_error("ZIP Error: Truncated central directory file header.");
		}

		if (!hasLe32Signature(image_vec, cursor, ZIP_CENTRAL_DIRECTORY_SIGNATURE)) {
			throw std::runtime_error(std::format(
				"ZIP Error: Invalid central directory file header signature at record {}.", i + 1));
		}

		const std::size_t name_length = readLe16(image_vec, cursor + CENTRAL_NAME_LENGTH_OFFSET);
		const std::size_t extra_length = readLe16(image_vec, cursor + CENTRAL_EXTRA_LENGTH_OFFSET);
		const std::size_t comment_length = readLe16(image_vec, cursor + CENTRAL_COMMENT_LENGTH_OFFSET);
		const uint16_t entry_disk_start = readLe16(image_vec, cursor + CENTRAL_DISK_START_OFFSET);
		const std::size_t record_size = CENTRAL_RECORD_MIN_SIZE + name_length + extra_length + comment_length;

		if (entry_disk_start != 0) {
			throw std::runtime_error(std::format(
				"ZIP Error: Multi-disk local header reference on record {} is not supported.", i + 1));
		}
		if (record_size > image_vec.size() - cursor || cursor + record_size > central_end) {
			throw std::runtime_error("ZIP Error: Central directory entry exceeds archive bounds.");
		}

		const std::size_t local_offset = checkedAdd(
			zip_base_offset,
			static_cast<std::size_t>(readLe32(image_vec, cursor + CENTRAL_LOCAL_OFFSET_OFFSET)),
			"ZIP Error: Local file header offset overflow.");
		if (local_offset > UINT32_MAX) {
			throw std::runtime_error("ZIP Error: Local file header offset exceeds ZIP32 limits.");
		}
		if (local_offset >= central_start || 4 > image_vec.size() - local_offset) {
			throw std::runtime_error("ZIP Error: Local file header offset is out of bounds.");
		}
		if (!hasLe32Signature(image_vec, local_offset, ZIP_LOCAL_FILE_HEADER_SIGNATURE)) {
			throw std::runtime_error(std::format(
				"ZIP Error: Local file header signature mismatch for record {}.", i + 1));
		}

		writeLe32(image_vec, cursor + CENTRAL_LOCAL_OFFSET_OFFSET, static_cast<uint32_t>(local_offset));
		cursor += record_size;
	}

	if (cursor != central_end) {
		throw std::runtime_error("ZIP Error: Central directory size does not match parsed records.");
	}
}

void validateEmbedInputs(const vBytes& image_vec, const vBytes& script_vec, const vBytes& archive_vec) {
	if (image_vec.size() < ICCP_CHUNK_INDEX || image_vec.size() < ARCHIVE_INSERT_INDEX_DIFF) {
		throw std::runtime_error("Embed Error: Optimized PNG is too small for chunk insertion.");
	}
	if (script_vec.size() < CHUNK_FIELDS_COMBINED_LENGTH) {
		throw std::runtime_error("Embed Error: Script chunk is truncated.");
	}
	if (archive_vec.size() < CHUNK_FIELDS_COMBINED_LENGTH) {
		throw std::runtime_error("Embed Error: Archive chunk is truncated.");
	}
}

void reserveEmbeddedImageSize(vBytes& image_vec, std::size_t script_size, std::size_t archive_size) {
	const std::size_t output_size = checkedAdd(
		checkedAdd(image_vec.size(), script_size, "Embed Error: Output image size overflow."),
		archive_size,
		"Embed Error: Output image size overflow.");
	image_vec.reserve(output_size);
}

void insertScriptChunk(vBytes& image_vec, const vBytes& script_vec) {
	image_vec.insert(image_vec.begin() + ICCP_CHUNK_INDEX, script_vec.begin(), script_vec.end());
}

void insertArchiveChunk(vBytes& image_vec, const vBytes& archive_vec) {
	image_vec.insert(image_vec.end() - ARCHIVE_INSERT_INDEX_DIFF, archive_vec.begin(), archive_vec.end());
}

void writeLastIdatCrc(
	vBytes& image_vec,
	std::size_t original_image_size,
	std::size_t script_data_size,
	std::size_t archive_file_size) {

	const std::size_t last_idat_index = checkedAdd(
		checkedAdd(original_image_size, script_data_size, "Embed Error: IDAT index overflow."),
		LAST_IDAT_INDEX_DIFF,
		"Embed Error: IDAT index overflow.");
	const std::size_t complete_size = image_vec.size();

	if (archive_file_size < EXCLUDE_SIZE_AND_CRC_LENGTH) {
		throw std::runtime_error("Embed Error: Archive too small for CRC computation.");
	}

	const std::size_t crc_length = archive_file_size - EXCLUDE_SIZE_AND_CRC_LENGTH;
	if (last_idat_index > complete_size || crc_length > complete_size - last_idat_index) {
		throw std::runtime_error("Embed Error: IDAT CRC region exceeds image bounds.");
	}

	const uint32_t last_idat_crc = lodepng_crc32(&image_vec[last_idat_index], crc_length);
	const std::size_t crc_index = complete_size - LAST_IDAT_CRC_INDEX_DIFF;
	writeValueAt(image_vec, crc_index, last_idat_crc, VALUE_BYTE_LENGTH_FOUR);
}

} // anonymous namespace

// ============================================================================
// Public: Embed the script chunk and archive into the image
// ============================================================================

void embedChunks(vBytes& image_vec, vBytes script_vec, vBytes archive_vec, std::size_t original_image_size) {
	validateEmbedInputs(image_vec, script_vec, archive_vec);

	const std::size_t script_data_size = script_vec.size() - CHUNK_FIELDS_COMBINED_LENGTH;
	const std::size_t archive_file_size = archive_vec.size();

	reserveEmbeddedImageSize(image_vec, script_vec.size(), archive_vec.size());

	// Insert iCCP script chunk after the PNG header.
	insertScriptChunk(image_vec, script_vec);
	script_vec = vBytes{}; // Release memory.

	// Insert archive data before the IEND chunk.
	insertArchiveChunk(image_vec, archive_vec);
	archive_vec = vBytes{}; // Release memory.

	// Fix ZIP internal offsets (must happen before CRC computation,
	// since the offsets are within the CRC-covered region).
	fixZipOffsets(image_vec, original_image_size, script_data_size);

	// Recompute the last IDAT chunk CRC.
	writeLastIdatCrc(image_vec, original_image_size, script_data_size, archive_file_size);
}
