#include "program_args_out.h"
#include "file_utils.h"

#include <format>
#include <string>

namespace {
[[nodiscard]] std::string programName(int argc, char** argv) {
    if (argc <= 0 || argv[0] == nullptr) return "jdv_out";
    return displaySafeFilename(fs::path(argv[0]));
}

[[nodiscard]] std::string usageText(int argc, char** argv) {
    return std::format("Usage: {} <cover_image> <key_file>", programName(argc, argv));
}
} // namespace

ProgramArgs ProgramArgs::parse(int argc, char** argv) {
    const std::string usage = usageText(argc, argv);
    if (argc != 3) throwError(usage);

    ProgramArgs out;
    out.image_file_path = argv[1];
    out.key_file_path = argv[2];
    return out;
}
