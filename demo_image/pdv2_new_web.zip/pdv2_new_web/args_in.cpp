#include "args_in.h"

#include <format>
#include <stdexcept>
#include <string_view>

[[noreturn]] static void dieUsage(const std::string& usage) {
	throw std::runtime_error(usage);
}

ProgramArgs ProgramArgs::parse(int argc, char** argv) {
	const auto arg = [&](int i) -> std::string_view {
		if (i < 0 || i >= argc) return {};
		const char* const s = argv[i];
		return s ? std::string_view{s} : std::string_view{};
	};

	// POSIX permits argc == 0 and argv[0] == nullptr; fall back to the binary name.
	const std::string
		prog = (argc >= 1 && argv[0] != nullptr)
			? fs::path(argv[0]).filename().string()
			: std::string{"pdv_in"},
		usage = std::format("Usage: {} [-m|-r] <cover_image> <secret_file>", prog);

	ProgramArgs out{};
	int i = 1;

	if (arg(i) == "-m" || arg(i) == "-r") {
		out.option = (arg(i) == "-m") ? Option::Mastodon : Option::Reddit;
		++i;
	}

	if (argc != i + 2 || arg(i).empty() || arg(i + 1).empty()) dieUsage(usage);

	out.image_file_path = arg(i);
	out.data_file_path = arg(i + 1);
	return out;
}
