#pragma once

#include "carrier_common.h"
#include "cipher_source.h"
#include "common.h"

#include <array>
#include <span>
#include <string>

// Layout of the 56-byte KDF metadata region:
//   0..3   magic ("KDF2" / "KDF3" / "KDF4")
//   4      KDF algorithm id
//   5      sentinel
//   6..7   random filler
//   8..23  Argon2id salt
//   24..47 secretstream header
//   48..51 Argon2id opslimit, big-endian   (V4 only; random filler before V4)
//   52..55 Argon2id memlimit, big-endian   (V4 only; random filler before V4)
inline constexpr std::size_t
    KDF_METADATA_REGION_BYTES = 56,
    KDF_MAGIC_OFFSET          = 0,
    KDF_ALG_OFFSET            = 4,
    KDF_SENTINEL_OFFSET       = 5,
    KDF_SALT_OFFSET           = 8,
    KDF_NONCE_OFFSET          = 24,
    KDF_OPSLIMIT_OFFSET       = 48,
    KDF_MEMLIMIT_OFFSET       = 52,
    KDF_COST_FIELD_BYTES      = 4;

inline constexpr Byte KDF_ALG_ARGON2ID13 = 1;
inline constexpr Byte KDF_SENTINEL = 0xA5;

inline constexpr auto KDF_METADATA_MAGIC_V2 = std::to_array<Byte>({'K', 'D', 'F', '2'});
inline constexpr auto KDF_METADATA_MAGIC_V3 = std::to_array<Byte>({'K', 'D', 'F', '3'});
inline constexpr auto KDF_METADATA_MAGIC_V4 = std::to_array<Byte>({'K', 'D', 'F', '4'});

// V3 authenticates the payload interpretation on every secretstream frame.
// The JPEG metadata remains readable for routing, but changing its compression
// marker can no longer make valid ciphertext be decoded with different rules.
inline constexpr Byte STREAM_MODE_ZLIB = 1;
inline constexpr Byte STREAM_MODE_RAW  = 2;

inline constexpr std::size_t STREAM_CHUNK_SIZE = 1 * 1024 * 1024;
inline constexpr std::size_t STREAM_FRAME_LEN_BYTES = 4;

enum class KdfMetadataVersion : Byte {
    none = 0,
    v2_secretstream = 2,
    v3_secretstream_authenticated_mode = 3,
    // V4 is V3 plus an explicit record of the Argon2id cost parameters. V2/V3
    // left them implicit, so retuning them would have turned every existing
    // image into an "invalid PIN" -- with V4 the image states what it was
    // derived with and old costs stay readable.
    v4_recorded_kdf_parameters = 4,
};

// Argon2id cost parameters used to derive a key from the recovery PIN.
struct KdfParams {
    std::uint64_t opslimit{crypto_pwhash_OPSLIMIT_INTERACTIVE};
    std::size_t   memlimit{crypto_pwhash_MEMLIMIT_INTERACTIVE};
};

// Costs jdvrif mints today. Every new image is V4 and records them, so they
// can be retuned freely: older V4 images keep the costs they recorded.
inline constexpr KdfParams KDF_PARAMS_CURRENT{
    .opslimit = crypto_pwhash_OPSLIMIT_INTERACTIVE,
    .memlimit = crypto_pwhash_MEMLIMIT_INTERACTIVE,
};

// Costs every V2/V3 image was made with. Those formats record nothing, so
// these are part of the formats and must never change. Written out rather
// than taken from libsodium's INTERACTIVE preset (equal today) so neither a
// retune of KDF_PARAMS_CURRENT nor a libsodium change can move them.
inline constexpr KdfParams KDF_PARAMS_V2_V3{
    .opslimit = 2,
    .memlimit = 64uz * 1024 * 1024,
};

// Accepted range when reading costs back out of an image. The floors are
// libsodium's own minimums; the ceilings bound the work a hostile image can
// demand, since Argon2id allocates memlimit bytes and runs opslimit passes
// over them before the PIN is known to be wrong.
inline constexpr std::uint64_t KDF_OPSLIMIT_MIN_ACCEPTED = crypto_pwhash_OPSLIMIT_MIN;
inline constexpr std::uint64_t KDF_OPSLIMIT_MAX_ACCEPTED = 16;
inline constexpr std::size_t   KDF_MEMLIMIT_MIN_ACCEPTED = crypto_pwhash_MEMLIMIT_MIN;
inline constexpr std::size_t   KDF_MEMLIMIT_MAX_ACCEPTED = 512uz * 1024 * 1024;

static_assert(KDF_PARAMS_CURRENT.opslimit >= KDF_OPSLIMIT_MIN_ACCEPTED &&
              KDF_PARAMS_CURRENT.opslimit <= KDF_OPSLIMIT_MAX_ACCEPTED &&
              KDF_PARAMS_CURRENT.memlimit >= KDF_MEMLIMIT_MIN_ACCEPTED &&
              KDF_PARAMS_CURRENT.memlimit <= KDF_MEMLIMIT_MAX_ACCEPTED,
              "jdvrif must be able to read back the KDF costs it writes.");
static_assert(KDF_PARAMS_CURRENT.memlimit <= 0xFFFFFFFFULL,
              "KDF cost fields are 32-bit.");

[[nodiscard]] constexpr Byte streamModeByte(bool is_compressed_payload) noexcept {
    return is_compressed_payload ? STREAM_MODE_ZLIB : STREAM_MODE_RAW;
}

// True for the versions that bind the payload interpretation into every
// secretstream frame as associated data.
[[nodiscard]] constexpr bool authenticatesStreamMode(KdfMetadataVersion version) noexcept {
    return version == KdfMetadataVersion::v3_secretstream_authenticated_mode ||
           version == KdfMetadataVersion::v4_recorded_kdf_parameters;
}

[[nodiscard]] constexpr bool isSupportedKdfMetadataVersion(KdfMetadataVersion version) noexcept {
    return version == KdfMetadataVersion::v2_secretstream ||
           authenticatesStreamMode(version);
}

[[nodiscard]] std::size_t computeStreamEncryptedSize(std::size_t plaintext_size);

// Reads pin.value for the KDF; does not wipe `pin` (caller may still need it).
// Any stack copy of the integer made inside is zeroed before return.
void deriveKeyFromPin(Key& out_key, const SecurePin& pin, const Salt& salt, const KdfParams& params);
[[nodiscard]] KdfMetadataVersion getKdfMetadataVersion(std::span<const Byte> data, std::size_t base_index);
// Cost parameters this image says its key was derived with. V2/V3 carry no
// record, so they resolve to KDF_PARAMS_V2_V3; V4 reads the stored pair and
// rejects anything outside the accepted range.
[[nodiscard]] KdfParams readKdfParams(
    std::span<const Byte> data,
    std::size_t base_index,
    KdfMetadataVersion version,
    const char* corrupt_error);
[[nodiscard]] SecurePin generateRecoveryPin();

// Argon2id costs for the carrier key. Part of the RQSTEG2 / JXSTEG3 formats:
// nothing in the image records them (the key is needed to read anything), so
// they are pinned here rather than tracking KDF_PARAMS_CURRENT. Changing them
// requires a new carrier format version. Numerically equal to libsodium's
// INTERACTIVE preset today, written out so a libsodium change cannot move them.
inline constexpr KdfParams CARRIER_KDF_PARAMS{
    .opslimit = 2,
    .memlimit = 64uz * 1024 * 1024,
};

// Fixed Argon2id salt for the carrier key (see deriveCarrierKeyFromPin).
inline constexpr Salt CARRIER_KDF_SALT{
    'j', 'd', 'v', 'r', 'i', 'f', '-', 'c', 'a', 'r', 'r', 'i', 'e', 'r', 'v', '2'
};

// Key for metadata-stripping carriers' coefficient permutation, whitening and
// dither (formats RQSTEG2 / JXSTEG3).
//
// It cannot be the envelope's encryption key: that derivation needs the random
// salt, and the salt lives inside the envelope this key is required to locate.
// So it is Argon2id over the PIN with a fixed, domain-separating salt. It must
// still be slow: the carrier header carries a magic and CRC, so whatever this
// key costs is the price of testing one PIN guess against an image. A fixed salt
// is safe here because the PIN is 64 uniformly random bits -- precomputing a
// useful fraction of that space is out of reach.
[[nodiscard]] std::uint64_t deriveCarrierKeyFromPin(const SecurePin& pin);

// The jdvrif v9.0 carrier key (RQSTEG1 / JXSTEG2): a single salt-free BLAKE2b
// of the PIN. Cheap, and therefore a fast PIN oracle -- used only to keep
// recovering images written by v9.0, never to write new ones.
[[nodiscard]] std::uint64_t deriveLegacyCarrierKeyFromPin(const SecurePin& pin);

// Both of the above, for recovery.
[[nodiscard]] CarrierKeys deriveCarrierKeysFromPin(const SecurePin& pin);

void encryptFileWithSecretStreamPrefixed(
    const fs::path& data_path,
    std::size_t input_size,
    std::span<const Byte> prefix_plaintext,
    Byte authenticated_mode,
    const Key& key,
    std::array<Byte, crypto_secretstream_xchacha20poly1305_HEADERBYTES>& header,
    vBytes& output_vec);

void encryptFileWithSecretStreamPrefixedToFile(
    const fs::path& data_path,
    std::size_t input_size,
    std::span<const Byte> prefix_plaintext,
    Byte authenticated_mode,
    const Key& key,
    std::array<Byte, crypto_secretstream_xchacha20poly1305_HEADERBYTES>& header,
    const fs::path& output_path);

[[nodiscard]] bool decryptSecretStreamToFileExtractingFilename(
    CipherSource& encrypted_input,
    const Key& key,
    const std::array<Byte, crypto_secretstream_xchacha20poly1305_HEADERBYTES>& header,
    KdfMetadataVersion metadata_version,
    bool is_compressed_payload,
    const fs::path& output_path,
    std::size_t& output_size,
    std::string& decrypted_filename);
