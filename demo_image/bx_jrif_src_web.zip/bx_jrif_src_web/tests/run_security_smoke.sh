#!/bin/bash
# Focused regressions for security/correctness fixes shared with the main CLI.
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
TESTS="$ROOT/tests"
FIXTURES="$TESTS/fixtures"
IN_BIN="${JDV_IN_BIN:-$ROOT/jdv_in}"
OUT_BIN="${JDV_OUT_BIN:-$ROOT/jdv_out}"
NO_BUILD=0

usage() {
    cat <<'EOF'
Usage: tests/run_security_smoke.sh [options]

Options:
  --no-build        Reuse existing binaries.
  --in-bin <path>   Use an explicit jdv_in binary path.
  --out-bin <path>  Use an explicit jdv_out binary path.
  -h, --help        Show this help.

JDV_IN_BIN and JDV_OUT_BIN provide the same binary overrides.
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --no-build)
            NO_BUILD=1
            shift
            ;;
        --in-bin)
            [[ $# -ge 2 ]] || { echo "--in-bin requires a path" >&2; exit 2; }
            IN_BIN="$2"
            NO_BUILD=1
            shift 2
            ;;
        --out-bin)
            [[ $# -ge 2 ]] || { echo "--out-bin requires a path" >&2; exit 2; }
            OUT_BIN="$2"
            NO_BUILD=1
            shift 2
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            usage >&2
            exit 2
            ;;
    esac
done

if [[ "$IN_BIN" != /* ]]; then IN_BIN="$(pwd -P)/${IN_BIN#./}"; fi
if [[ "$OUT_BIN" != /* ]]; then OUT_BIN="$(pwd -P)/${OUT_BIN#./}"; fi
if [[ "$NO_BUILD" -eq 0 ]]; then
    (cd "$ROOT" && bash ./compile_jdv_in.sh && bash ./compile_jdv_out.sh)
fi
for binary in "$IN_BIN" "$OUT_BIN"; do
    [[ -x "$binary" ]] || { echo "Binary not found or not executable: $binary" >&2; exit 1; }
done
for command_name in cmp find grep python3 sed stat; do
    command -v "$command_name" >/dev/null 2>&1 || {
        echo "Missing required command: $command_name" >&2
        exit 1
    }
done

COVER="$FIXTURES/covers/cover_default.jpg"
PAYLOAD="$FIXTURES/payloads/payload_text.txt"
WORK="$(mktemp -d "${TMPDIR:-/tmp}/jdv-web-security.XXXXXX")"
trap 'rm -rf "$WORK"' EXIT

extract_embedded_image() {
    sed -n 's/.*Saved "file-embedded" JPG image: \(.*\) ([0-9][0-9]* bytes)\..*/\1/p' "$1" | tail -n 1
}

extract_pin() {
    sed -n 's/.*Recovery PIN: \[\*\*\*\([0-9][0-9]*\)\*\*\*\].*/\1/p' "$1" | tail -n 1
}

extract_recovered_file() {
    sed -n 's/.*Extracted hidden file: \(.*\) ([0-9][0-9]* bytes)\..*/\1/p' "$1" | tail -n 1
}

# AddressSanitizer reserves a multi-terabyte shadow mapping at startup, so an
# instrumented binary aborts under `ulimit -v` before reaching any jdv_in code.
# Tests that use an address-space cap must drop it for such a build. Detect this
# from the binary itself: ASAN_OPTIONS is only set if the caller exported it,
# which makes it an unreliable signal when running the suite directly.
binary_is_sanitized() {
    [[ -n "${ASAN_OPTIONS:-}" ]] && return 0
    ldd "$1" 2>/dev/null | grep -q 'libasan' && return 0
    grep -qa '__asan_init' "$1" 2>/dev/null && return 0
    return 1
}

assert_no_stage_files() {
    local found
    found="$(find "$1" -maxdepth 1 \
        \( -name '.jdvrif_*' -o -name '.*.jdvrif_tmp_*' \) -print -quit)"
    if [[ -n "$found" ]]; then
        echo "staging file remains: $found" >&2
        return 1
    fi
}

prepare_fixture() {
    local dir="$WORK/fresh_default"
    local embedded pin
    mkdir -p "$dir"
    (cd "$dir" && "$IN_BIN" "$COVER" "$PAYLOAD" > conceal.log 2>&1)
    embedded="$(extract_embedded_image "$dir/conceal.log")"
    pin="$(extract_pin "$dir/conceal.log")"
    [[ -n "$embedded" && -n "$pin" && -f "$dir/$embedded" ]] || {
        cat "$dir/conceal.log" >&2
        return 1
    }
    printf '%s\n' "$pin" > "$dir/pin.txt"
    chmod 600 "$dir/pin.txt"
    DEFAULT_IMAGE="$dir/$embedded"
    DEFAULT_PIN_FILE="$dir/pin.txt"
}

prepare_fixture

test_authenticated_compression_mode() {
    local dir="$WORK/compression_tamper"
    mkdir -p "$dir"
    cp "$DEFAULT_PIN_FILE" "$dir/pin.txt"
    python3 - "$DEFAULT_IMAGE" "$dir/mode.jpg" "$dir/downgrade.jpg" <<'PY'
import sys
from pathlib import Path

data = bytearray(Path(sys.argv[1]).read_bytes())
mntr = data.find(b"mntrRGB")
if mntr < 8:
    raise SystemExit("ICC signature not found")
base = mntr - 8
compression_flag = base + 0x68
kdf_marker = base + 0x2FB
# Accept any framing that authenticates the mode (KDF3, KDF4, ...) so retiring
# a mint version stays a one-line change here.
if bytes(data[kdf_marker:kdf_marker + 4]) not in (b"KDF3", b"KDF4"):
    raise SystemExit(
        f"fresh fixture does not use an authenticated KDF framing: "
        f"{bytes(data[kdf_marker:kdf_marker + 4])!r}")
if data[compression_flag] == 0x58:
    raise SystemExit("fresh small payload unexpectedly bypassed compression")

data[compression_flag] = 0x58
Path(sys.argv[2]).write_bytes(data)
data[kdf_marker:kdf_marker + 4] = b"KDF2"
Path(sys.argv[3]).write_bytes(data)
PY
    local image
    for image in mode.jpg downgrade.jpg; do
        if (cd "$dir" && "$OUT_BIN" "$image" pin.txt > "recover-$image.log" 2>&1); then
            echo "tampered compression semantics were accepted from $image" >&2
            return 1
        fi
    done
    if find "$dir" -maxdepth 1 -type f -name 'payload_text*' -print -quit | grep -q .; then
        echo "tampered recovery left plaintext output" >&2
        return 1
    fi
    assert_no_stage_files "$dir"
}

# KDF4 records the Argon2id cost parameters in the image. Out-of-range costs
# drive an allocation and a work loop that both run before a wrong PIN can be
# detected, so they must be refused outright -- and refused without the PIN file
# being consumed, like every other unusable-metadata rejection.
test_kdf_cost_bounds() {
    local dir="$WORK/kdf_costs"
    mkdir -p "$dir"
    cp "$DEFAULT_PIN_FILE" "$dir/pin.txt"
    python3 - "$DEFAULT_IMAGE" "$dir" <<'KDFPY'
import sys
from pathlib import Path

data = bytearray(Path(sys.argv[1]).read_bytes())
out = Path(sys.argv[2])
mntr = data.find(b"mntrRGB")
if mntr < 8:
    raise SystemExit("ICC signature not found")
kdf = mntr - 8 + 0x2FB
if bytes(data[kdf:kdf + 4]) != b"KDF4":
    raise SystemExit(f"fixture is not KDF4: {bytes(data[kdf:kdf + 4])!r}")

ops = kdf + 48
mem = kdf + 52
if int.from_bytes(data[ops:ops + 4], "big") != 2:
    raise SystemExit("unexpected recorded opslimit")
if int.from_bytes(data[mem:mem + 4], "big") != 64 * 1024 * 1024:
    raise SystemExit("unexpected recorded memlimit")

for name, (offset, value) in {
    "huge_mem.jpg": (mem, 0xFFFFFFFF),
    "zero_mem.jpg": (mem, 0),
    "huge_ops.jpg": (ops, 0xFFFFFFFF),
    "zero_ops.jpg": (ops, 0),
}.items():
    patched = bytearray(data)
    patched[offset:offset + 4] = value.to_bytes(4, "big")
    (out / name).write_bytes(patched)
KDFPY

    local image
    for image in huge_mem.jpg zero_mem.jpg huge_ops.jpg zero_ops.jpg; do
        if (cd "$dir" && "$OUT_BIN" "$image" pin.txt > "recover-$image.log" 2>&1); then
            echo "out-of-range KDF costs were accepted from $image" >&2
            return 1
        fi
        if ! grep -Fq 'unsupported key-derivation parameters' "$dir/recover-$image.log"; then
            echo "wrong rejection reason for $image:" >&2
            cat "$dir/recover-$image.log" >&2
            return 1
        fi
    done
    if find "$dir" -maxdepth 1 -type f -name 'payload_text*' -print -quit | grep -q .; then
        echo "rejected recovery left plaintext output" >&2
        return 1
    fi
    assert_no_stage_files "$dir"
}

test_wrong_pin_leaves_no_plaintext() {
    local dir="$WORK/wrong_pin"
    local actual_pin wrong_pin=1
    mkdir -p "$dir"
    cp "$DEFAULT_IMAGE" "$dir/input.jpg"
    actual_pin="$(sed -n '1{s/[^0-9]//g;p;}' "$DEFAULT_PIN_FILE")"
    if [[ "$actual_pin" == "$wrong_pin" ]]; then wrong_pin=2; fi
    printf '%s\n' "$wrong_pin" > "$dir/wrong-pin.txt"
    if (cd "$dir" && "$OUT_BIN" input.jpg wrong-pin.txt > recover.log 2>&1); then
        echo "jdv_out unexpectedly accepted a wrong PIN" >&2
        return 1
    fi
    if find "$dir" -maxdepth 1 -type f -name 'payload_text*' -print -quit | grep -q .; then
        echo "wrong-PIN recovery left plaintext output" >&2
        return 1
    fi
    assert_no_stage_files "$dir"
}

test_oversized_pin_file_rejected() {
    local dir="$WORK/oversized_pin"
    mkdir -p "$dir"
    cp "$DEFAULT_IMAGE" "$dir/input.jpg"
    python3 - "$dir/oversized-pin.txt" <<'PY'
import sys
from pathlib import Path

Path(sys.argv[1]).write_bytes(b"1" * 65)
PY
    if (cd "$dir" && "$OUT_BIN" input.jpg oversized-pin.txt > recover.log 2>&1); then
        echo "jdv_out accepted a PIN file over 64 bytes" >&2
        return 1
    fi
    grep -Eiq 'PIN.*64-byte size limit|PIN.*size limit' "$dir/recover.log"
    if find "$dir" -maxdepth 1 -type f -name 'payload_text*' -print -quit | grep -q .; then
        echo "oversized-PIN recovery left plaintext output" >&2
        return 1
    fi
    assert_no_stage_files "$dir"
}

test_truncated_ciphertext() {
    local dir="$WORK/truncated"
    mkdir -p "$dir"
    cp "$DEFAULT_PIN_FILE" "$dir/pin.txt"
    python3 - "$DEFAULT_IMAGE" "$dir/input.jpg" <<'PY'
import sys
from pathlib import Path

data = Path(sys.argv[1]).read_bytes()
mntr = data.find(b"mntrRGB")
if mntr < 8:
    raise SystemExit("ICC signature not found")
base = mntr - 8
size = int.from_bytes(data[base + 0x2CA:base + 0x2CE], "big")
payload = base + 0x33B
if size < 2 or payload + size > len(data):
    raise SystemExit("unexpected embedded layout")
Path(sys.argv[2]).write_bytes(data[:payload + size - 1])
PY
    if (cd "$dir" && "$OUT_BIN" input.jpg pin.txt > recover.log 2>&1); then
        echo "jdv_out accepted truncated ciphertext" >&2
        return 1
    fi
    if find "$dir" -maxdepth 1 -type f -name 'payload_text*' -print -quit | grep -q .; then
        echo "truncated recovery left plaintext output" >&2
        return 1
    fi
    assert_no_stage_files "$dir"
}

test_nondefault_icc_offset_rejected() {
    local dir="$WORK/nondefault_icc_offset"
    mkdir -p "$dir"
    cp "$DEFAULT_PIN_FILE" "$dir/pin.txt"
    python3 - "$DEFAULT_IMAGE" "$dir/input.jpg" <<'PY'
import sys
from pathlib import Path

data = Path(sys.argv[1]).read_bytes()
if not data.startswith(b"\xff\xd8"):
    raise SystemExit("default fixture is not a JPEG")

# Insert a valid APP0 segment after SOI. The embedded profile remains intact,
# but is no longer at jdvrif's one supported ICC offset.
app0 = b"\xff\xe0\x00\x04AB"
Path(sys.argv[2]).write_bytes(data[:2] + app0 + data[2:])
PY
    if (cd "$dir" && "$OUT_BIN" input.jpg pin.txt > recover.log 2>&1); then
        echo "jdv_out accepted an embedded profile at a nondefault offset" >&2
        return 1
    fi
    # jdv_out verifies the ICC and jdvrif signatures at their two fixed offsets
    # rather than scanning for them, so a shifted profile is not recognised as a
    # jdvrif image at all. It used to be found by the scan and then refused by
    # the layout check ("Unsupported embedded profile layout."); the rejection
    # now happens one step earlier, without reading the rest of the file.
    if ! grep -Fq 'Signature check failure.' "$dir/recover.log"; then
        echo "nondefault ICC offset was not rejected as a signature failure" >&2
        cat "$dir/recover.log" >&2
        return 1
    fi
    if find "$dir" -maxdepth 1 -type f -name 'payload_text*' -print -quit | grep -q .; then
        echo "nondefault ICC recovery left plaintext output" >&2
        return 1
    fi
    assert_no_stage_files "$dir"
}

test_pin_delivery_failure_is_transactional() {
    local dir="$WORK/full_stdout"
    local found
    [[ -e /dev/full ]] || return 77
    mkdir -p "$dir"
    if (cd "$dir" && "$IN_BIN" "$COVER" "$PAYLOAD" > /dev/full 2> conceal.err); then
        echo "jdv_in succeeded although its PIN could not be delivered" >&2
        return 1
    fi
    found="$(find "$dir" -maxdepth 1 \
        \( -name 'jrif_*.jpg' -o -name '.jdvrif_*' -o -name '.*.jdvrif_tmp_*' \) \
        -print -quit)"
    if [[ -n "$found" ]]; then
        echo "jdv_in committed or leaked output after PIN delivery failure: $found" >&2
        return 1
    fi
}

# After the recovery PIN has been printed, the fsynced temp image is the only
# durable copy that PIN can open. A later commit failure (here: colliding the
# chosen output name) must leave that image in place and name it in the error.
test_commit_collision_after_pin_keeps_image() {
    local dir="$WORK/commit_collision"
    mkdir -p "$dir"
    python3 - "$IN_BIN" "$COVER" "$PAYLOAD" "$dir" <<'PY'
import ctypes
import os
import struct
import subprocess
import sys
from pathlib import Path

binary, cover, payload, work = sys.argv[1:]
work = Path(work)

libc = ctypes.CDLL("libc.so.6", use_errno=True)
IN_CREATE = 0x00000100
IN_MOVED_TO = 0x00000080
EVENT = struct.Struct("iIII")

fd = libc.inotify_init1(os.O_CLOEXEC)
if fd < 0:
    raise OSError(ctypes.get_errno(), "inotify_init1")
watch = libc.inotify_add_watch(fd, os.fsencode(work), IN_CREATE | IN_MOVED_TO)
if watch < 0:
    os.close(fd)
    raise OSError(ctypes.get_errno(), "inotify_add_watch")

proc = subprocess.Popen(
    [binary, cover, payload],
    cwd=work,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True,
)

temp = None
try:
    leftover = b""
    while temp is None:
        if proc.poll() is not None:
            break
        chunk = leftover + os.read(fd, 4096)
        leftover = b""
        pos = 0
        while pos + EVENT.size <= len(chunk):
            wd, mask, cookie, length = EVENT.unpack_from(chunk, pos)
            pos += EVENT.size
            if pos + length > len(chunk):
                leftover = chunk[pos - EVENT.size:]
                break
            name = chunk[pos:pos + length].split(b"\x00", 1)[0].decode()
            pos += length
            if ".jdvrif_tmp_" not in name or not name.startswith(".jrif_"):
                continue
            temp = work / name
            marker = ".jdvrif_tmp_"
            output_name = name[1:name.find(marker)]
            (work / output_name).write_bytes(b"collision")
            break
    stdout, stderr = proc.communicate(timeout=30)
finally:
    if proc.poll() is None:
        proc.kill()
        proc.wait()
    os.close(fd)

log = stdout + "\n" + stderr
if temp is None:
    raise RuntimeError(f"did not observe staged output before conceal exited:\n{log}")
if proc.returncode == 0:
    raise RuntimeError("jdv_in succeeded despite an output-name collision")
if "Recovery PIN:" not in log:
    raise RuntimeError(f"PIN was not delivered before commit failure:\n{log}")
if not temp.exists():
    raise RuntimeError("durable staged image was deleted after PIN delivery")
if temp.name not in log and str(temp) not in log:
    raise RuntimeError(f"error did not mention leftover image path:\n{log}")
PY
}

test_bluesky_final_output_size_limit() {
    local dir="$WORK/bluesky_final_size"
    local accepted_payload="$FIXTURES/payloads/bsingle.bin"
    local rejected_payload="$FIXTURES/payloads/bxmp.bin"
    local embedded accepted_size found

    if ! command -v ffmpeg >/dev/null 2>&1; then
        echo "ffmpeg is unavailable; near-limit Bluesky fixture not generated" >&2
        return 77
    fi

    mkdir -p "$dir/accepted" "$dir/rejected"
    ffmpeg -hide_banner -loglevel error -y \
        -f lavfi \
        -i 'nullsrc=size=1770x1770,noise=alls=100:allf=u:all_seed=12345' \
        -frames:v 1 -q:v 2 "$dir/cover.jpg"

    (
        cd "$dir/accepted"
        "$IN_BIN" -b "$dir/cover.jpg" "$accepted_payload" > conceal.log 2>&1
    )
    embedded="$(extract_embedded_image "$dir/accepted/conceal.log")"
    if [[ -z "$embedded" || ! -f "$dir/accepted/$embedded" ]]; then
        echo "near-limit Bluesky control did not produce an output image" >&2
        cat "$dir/accepted/conceal.log" >&2
        return 1
    fi
    accepted_size="$(stat -c '%s' "$dir/accepted/$embedded")"
    if [[ "$accepted_size" -gt 2000000 ]]; then
        echo "Bluesky conceal accepted a $accepted_size-byte output image" >&2
        return 1
    fi
    assert_no_stage_files "$dir/accepted"

    if (
        cd "$dir/rejected"
        "$IN_BIN" -b "$dir/cover.jpg" "$rejected_payload" > conceal.log 2>&1
    ); then
        echo "Bluesky conceal accepted a final output image over 2,000,000 bytes" >&2
        return 1
    fi
    grep -Fq \
        'File Size Error: Final output image exceeds the 2,000,000-byte limit for the Bluesky platform.' \
        "$dir/rejected/conceal.log"
    grep -Fq \
        '                 Use a smaller cover image or reduce the size of the payload (hidden data file).' \
        "$dir/rejected/conceal.log"
    if grep -Fq 'Recovery PIN:' "$dir/rejected/conceal.log"; then
        echo "Bluesky conceal disclosed a PIN for a rejected output image" >&2
        return 1
    fi
    found="$(find "$dir/rejected" -maxdepth 1 -type f -name 'jrif_*.jpg' -print -quit)"
    if [[ -n "$found" ]]; then
        echo "Bluesky conceal committed an oversized output image: $found" >&2
        return 1
    fi
    assert_no_stage_files "$dir/rejected"
}

test_oversized_jpeg_dimensions() {
    local dir="$WORK/huge_dimensions"
    local rc
    mkdir -p "$dir"
    python3 - "$COVER" "$dir/huge.jpg" <<'PY'
import sys
from pathlib import Path

data = bytearray(Path(sys.argv[1]).read_bytes())
pos = 2
sof = None
while pos + 4 <= len(data):
    if data[pos] != 0xFF:
        pos += 1
        continue
    while pos < len(data) and data[pos] == 0xFF:
        pos += 1
    marker = data[pos]
    pos += 1
    if marker in (0x01, 0xD8, 0xD9) or 0xD0 <= marker <= 0xD7:
        continue
    if marker == 0xDA:
        break
    length = int.from_bytes(data[pos:pos + 2], "big")
    if marker in {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                  0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}:
        sof = pos + 2
        break
    pos += length
if sof is None:
    raise SystemExit("SOF marker not found")
data[sof + 1:sof + 3] = (65000).to_bytes(2, "big")
data[sof + 3:sof + 5] = (65000).to_bytes(2, "big")
Path(sys.argv[2]).write_bytes(data)
PY
    local capped=1
    if binary_is_sanitized "$IN_BIN"; then
        capped=0
    fi

    if command -v timeout >/dev/null 2>&1; then
        set +e
        (
            cd "$dir"
            if [[ "$capped" -eq 1 ]]; then ulimit -v 524288; fi
            timeout 10 "$IN_BIN" huge.jpg "$PAYLOAD" > conceal.log 2>&1
        )
        rc=$?
        set -e
        if [[ "$rc" -eq 0 || "$rc" -eq 124 || "$rc" -eq 137 ]]; then
            echo "oversized-dimension rejection returned unsafe status $rc" >&2
            return 1
        fi
    else
        if (
            cd "$dir"
            if [[ "$capped" -eq 1 ]]; then ulimit -v 524288; fi
            "$IN_BIN" huge.jpg "$PAYLOAD" > conceal.log 2>&1
        ); then
            echo "oversized JPEG dimensions were accepted" >&2
            return 1
        fi
    fi
    grep -Eiq 'dimension|pixel|too large|maximum' "$dir/conceal.log"
    assert_no_stage_files "$dir"
}

test_cmyk_cover_rejected() {
    local dir="$WORK/cmyk"
    if ! python3 -c 'import PIL' >/dev/null 2>&1; then
        return 77
    fi
    mkdir -p "$dir"
    python3 - "$dir/cmyk.jpg" <<'PY'
import sys
from PIL import Image

Image.new("CMYK", (500, 500), (0, 255, 255, 0)).save(
    sys.argv[1], format="JPEG", quality=90
)
PY
    if (cd "$dir" && "$IN_BIN" cmyk.jpg "$PAYLOAD" > conceal.log 2>&1); then
        echo "CMYK cover was accepted" >&2
        return 1
    fi
    grep -Eiq 'CMYK|YCCK|color space|unsupported' "$dir/conceal.log"
}

test_post_transform_dimensions() {
    local dir="$WORK/trimmed_dimensions"
    local magick_bin
    magick_bin="$(command -v magick || command -v convert || true)"
    if [[ -z "$magick_bin" ]]; then
        return 77
    fi
    mkdir -p "$dir"
    "$magick_bin" -size 400x401 gradient:red-blue -colorspace sRGB \
        -sampling-factor 4:1:1 -quality 90 "$dir/base.jpg"
    python3 - "$dir/base.jpg" "$dir/oriented.jpg" <<'PY'
import struct
import sys
from pathlib import Path

data = Path(sys.argv[1]).read_bytes()
if not data.startswith(b"\xff\xd8"):
    raise SystemExit("not a JPEG")
tiff = (
    b"II\x2a\x00" + struct.pack("<I", 8) + struct.pack("<H", 1) +
    struct.pack("<HHI", 0x0112, 3, 1) + struct.pack("<H", 2) + b"\x00\x00" +
    struct.pack("<I", 0)
)
payload = b"Exif\x00\x00" + tiff
app1 = b"\xff\xe1" + struct.pack(">H", len(payload) + 2) + payload
Path(sys.argv[2]).write_bytes(data[:2] + app1 + data[2:])
PY
    if (cd "$dir" && "$IN_BIN" oriented.jpg "$PAYLOAD" > conceal.log 2>&1); then
        echo "cover trimmed below 400px was accepted" >&2
        return 1
    fi
    grep -Eiq 'dimension|too small|at least 400' "$dir/conceal.log"
    assert_no_stage_files "$dir"
}

test_referenced_nonzero_dqt_quality() {
    local dir="$WORK/nonzero_dqt"
    local embedded
    if ! python3 -c 'import PIL' >/dev/null 2>&1; then
        return 77
    fi
    mkdir -p "$dir"
    python3 - "$dir/dqt1.jpg" <<'PY'
import io
import sys
from pathlib import Path
from PIL import Image

buffer = io.BytesIO()
Image.new("L", (500, 500), 128).save(buffer, format="JPEG", quality=100)
data = bytearray(buffer.getvalue())
pos = 2
changed_dqt = False
changed_sof = False
while pos + 4 <= len(data):
    if data[pos] != 0xFF:
        pos += 1
        continue
    while pos < len(data) and data[pos] == 0xFF:
        pos += 1
    marker = data[pos]
    pos += 1
    if marker in (0x01, 0xD8, 0xD9) or 0xD0 <= marker <= 0xD7:
        continue
    if marker == 0xDA:
        break
    length = int.from_bytes(data[pos:pos + 2], "big")
    payload = pos + 2
    end = pos + length
    if marker == 0xDB:
        cursor = payload
        while cursor < end:
            header = data[cursor]
            table_size = 128 if header >> 4 else 64
            if (header & 0x0F) == 0:
                data[cursor] = (header & 0xF0) | 1
                changed_dqt = True
            cursor += 1 + table_size
    elif marker in {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                    0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}:
        components = data[payload + 5]
        for index in range(components):
            qsel = payload + 6 + index * 3 + 2
            if data[qsel] == 0:
                data[qsel] = 1
                changed_sof = True
    pos = end
if not (changed_dqt and changed_sof):
    raise SystemExit("failed to build nonzero-DQT fixture")
Path(sys.argv[1]).write_bytes(data)
PY
    if (cd "$dir" && "$IN_BIN" dqt1.jpg "$PAYLOAD" > conceal.log 2>&1); then
        echo "quality-100 cover using DQT table 1 was accepted" >&2
        return 1
    fi
    grep -Eiq 'quality.*exceeds|quality.*maximum' "$dir/conceal.log"
    assert_no_stage_files "$dir"

    mkdir -p "$dir/bluesky"
    if ! (
        cd "$dir/bluesky"
        "$IN_BIN" -b "$dir/dqt1.jpg" "$PAYLOAD" > conceal.log 2>&1
    ); then
        echo "quality-100 cover was rejected in Bluesky mode" >&2
        cat "$dir/bluesky/conceal.log" >&2
        return 1
    fi
    embedded="$(extract_embedded_image "$dir/bluesky/conceal.log")"
    if [[ -z "$embedded" || ! -f "$dir/bluesky/$embedded" ]]; then
        echo "Bluesky mode did not produce an output for the quality-100 cover" >&2
        cat "$dir/bluesky/conceal.log" >&2
        return 1
    fi
    assert_no_stage_files "$dir/bluesky"
}

# The compression stage holds the deflated payload, which is plaintext-
# equivalent. It must live on a link-free inode (StagingFile): never present as
# a directory entry, so it cannot be listed, backed up or sync-uploaded, and
# cannot outlive a SIGKILL. Detect it through /proc/<pid>/fd, where such an
# inode appears as "<dir>/... (deleted)", and assert it never appears by name.
staging_inode_open() {
    local pid="$1" dir="$2" fd target
    for fd in /proc/"$pid"/fd/*; do
        target="$(readlink "$fd" 2>/dev/null)" || continue
        case "$target" in
            "$dir"/*" (deleted)") return 0 ;;
        esac
    done
    return 1
}

test_signal_cleans_compression_stage() {
    local dir="$WORK/signal_cleanup"
    local pid status seen=0
    command -v truncate >/dev/null 2>&1 || return 77
    mkdir -p "$dir"
    truncate -s "$((512 * 1024 * 1024))" "$dir/source.bin"
    (
        cd "$dir"
        exec "$IN_BIN" "$COVER" source.bin > conceal.log 2>&1
    ) &
    pid=$!

    for ((attempt = 0; attempt < 1000; ++attempt)); do
        # A named staging file at any point is the failure this test exists for.
        if find "$dir" -maxdepth 1 -type f \
            \( -name '.jdvrif_*' -o -name '.*.jdvrif_tmp_*' \) -print -quit | grep -q .; then
            kill -TERM "$pid" 2>/dev/null || true
            wait "$pid" 2>/dev/null || true
            echo "compression stage appeared as a named file in the working directory" >&2
            return 1
        fi
        if staging_inode_open "$pid" "$dir"; then
            seen=1
            kill -TERM "$pid"
            break
        fi
        if ! kill -0 "$pid" 2>/dev/null; then break; fi
        sleep 0.01
    done
    if [[ "$seen" -eq 0 ]]; then
        if kill -0 "$pid" 2>/dev/null; then kill -TERM "$pid"; fi
        wait "$pid" 2>/dev/null || true
        echo "did not observe the anonymous compression staging inode before jdv_in exited" >&2
        return 1
    fi

    set +e
    wait "$pid"
    status=$?
    set -e
    if [[ "$status" -eq 0 ]]; then
        echo "signal-interrupted jdv_in returned success" >&2
        return 1
    fi
    assert_no_stage_files "$dir"
    if find "$dir" -maxdepth 1 -type f -name 'jrif_*.jpg' -print -quit | grep -q .; then
        echo "signal-interrupted jdv_in committed an output image" >&2
        return 1
    fi
}

test_dangling_symlink_collision() {
    local dir="$WORK/dangling_symlink"
    local recovered
    mkdir -p "$dir"
    cp "$DEFAULT_IMAGE" "$dir/input.jpg"
    cp "$DEFAULT_PIN_FILE" "$dir/pin.txt"
    ln -s missing-target "$dir/payload_text.txt"
    (cd "$dir" && "$OUT_BIN" input.jpg pin.txt > recover.log 2>&1)
    recovered="$(extract_recovered_file "$dir/recover.log")"
    [[ "$recovered" == "payload_text_1.txt" ]] || {
        echo "expected payload_text_1.txt, got ${recovered:-<none>}" >&2
        return 1
    }
    [[ -L "$dir/payload_text.txt" ]]
    [[ "$(readlink "$dir/payload_text.txt")" == "missing-target" ]]
    cmp -s "$dir/$recovered" "$PAYLOAD"
    assert_no_stage_files "$dir"
}

patch_declared_size() {
    python3 - "$1" "$2" "$3" <<'PY'
import sys
from pathlib import Path

data = bytearray(Path(sys.argv[1]).read_bytes())
mntr = data.find(b"mntrRGB")
if mntr < 8:
    raise SystemExit("ICC signature not found")
base = mntr - 8
data[base + 0x2CA:base + 0x2CE] = int(sys.argv[3]).to_bytes(4, "big")
Path(sys.argv[2]).write_bytes(data)
PY
}

assert_recovery_cap() {
    local source_image="$1"
    local source_pin="$2"
    local maximum="$3"
    local tag="$4"
    local dir="$WORK/$tag"
    mkdir -p "$dir/at_limit" "$dir/over_limit"
    cp "$source_pin" "$dir/pin.txt"
    patch_declared_size "$source_image" "$dir/at_limit/input.jpg" "$maximum"
    patch_declared_size "$source_image" "$dir/over_limit/input.jpg" "$((maximum + 1))"

    if (cd "$dir/at_limit" && "$OUT_BIN" input.jpg ../pin.txt > recover.log 2>&1); then
        echo "synthetic at-limit fixture unexpectedly recovered" >&2
        return 1
    fi
    if grep -q 'exceeds the maximum allowed' "$dir/at_limit/recover.log"; then
        echo "$tag rejected its documented wiggle-room boundary" >&2
        return 1
    fi
    if (cd "$dir/over_limit" && "$OUT_BIN" input.jpg ../pin.txt > recover.log 2>&1); then
        echo "$tag accepted a declaration over its recovery cap" >&2
        return 1
    fi
    grep -q 'exceeds the maximum allowed' "$dir/over_limit/recover.log"
    assert_no_stage_files "$dir/at_limit"
    assert_no_stage_files "$dir/over_limit"
}

test_default_recovery_wiggle_room() {
    assert_recovery_cap "$DEFAULT_IMAGE" "$DEFAULT_PIN_FILE" \
        "$((2 * 1024 * 1024 * 1024 + 50 * 1024 * 1024))" default_size_boundary
}

PASS=0
FAIL=0
SKIP=0
run_test() {
    local name="$1"
    shift
    local rc
    # The test body runs in a subshell that is NOT itself a condition, so its
    # errexit stays armed: a bare assertion (grep -q, cmp -s, [[ ... ]]) that
    # fails aborts the test instead of being silently ignored. `if (set -e;
    # "$@")` would put the function in a condition context, where bash disables
    # errexit for the whole call -- which made every such assertion a no-op.
    set +e
    ( set -euo pipefail; "$@" )
    rc=$?
    set -e
    if [[ "$rc" -eq 0 ]]; then
        echo "[PASS] $name"
        PASS=$((PASS + 1))
    else
        if [[ "$rc" -eq 77 ]]; then
            echo "[SKIP] $name"
            SKIP=$((SKIP + 1))
        else
            echo "[FAIL] $name" >&2
            FAIL=$((FAIL + 1))
        fi
    fi
}

run_test authenticated_compression_mode test_authenticated_compression_mode
run_test kdf_cost_bounds test_kdf_cost_bounds
run_test wrong_pin_no_plaintext test_wrong_pin_leaves_no_plaintext
run_test oversized_pin_file test_oversized_pin_file_rejected
run_test truncated_ciphertext test_truncated_ciphertext
run_test nondefault_icc_offset_rejected test_nondefault_icc_offset_rejected
run_test transactional_pin_delivery test_pin_delivery_failure_is_transactional
run_test post_pin_commit_failure_keeps_image test_commit_collision_after_pin_keeps_image
run_test bluesky_final_output_size_limit test_bluesky_final_output_size_limit
run_test oversized_jpeg_dimensions test_oversized_jpeg_dimensions
run_test cmyk_cover_rejected test_cmyk_cover_rejected
run_test post_transform_dimensions test_post_transform_dimensions
run_test mode_specific_quality_limit test_referenced_nonzero_dqt_quality
run_test dangling_symlink_collision test_dangling_symlink_collision
run_test default_recovery_wiggle_room test_default_recovery_wiggle_room
run_test compression_stage_anonymous_sigterm test_signal_cleans_compression_stage

echo
echo "Security smoke summary: PASS=$PASS FAIL=$FAIL SKIP=$SKIP"
echo "jdv_in:  $IN_BIN"
echo "jdv_out: $OUT_BIN"
[[ "$FAIL" -eq 0 ]]
