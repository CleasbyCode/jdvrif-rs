#pragma once

#include "common.h"

template<typename T>
struct SecureBuffer {
    T buf{};

    SecureBuffer() = default;

    ~SecureBuffer() {
        sodium_memzero(buf.data(), buf.size());
    }

    SecureBuffer(const SecureBuffer&) = delete;
    SecureBuffer& operator=(const SecureBuffer&) = delete;
    SecureBuffer(SecureBuffer&&) = delete;
    SecureBuffer& operator=(SecureBuffer&&) = delete;

    auto data() { return buf.data(); }
    auto size() const { return buf.size(); }
};

void buildBlueskySegments(vBytes& segment_vec, const vBytes& data_vec);

[[nodiscard]] std::size_t estimateStreamEncryptedSizePrefixed(
    std::size_t input_plaintext_size,
    std::size_t prefix_plaintext_size);

[[nodiscard]] std::uint64_t encryptDataFileForBluesky(
    vBytes& segment_vec,
    const fs::path& data_path,
    std::size_t input_size,
    vString& platforms_vec,
    const std::string& data_filename);

[[nodiscard]] std::uint64_t encryptDataFileToFile(
    vBytes& segment_vec,
    const fs::path& data_path,
    std::size_t input_size,
    const std::string& data_filename,
    const fs::path& encrypted_output_path);

struct DecryptResult {
    std::string filename{};
    std::size_t output_size{0};
    bool failed{false};
};

// Derives the key from the embedded KDF metadata in metadata_vec (recovery
// PIN supplied via pin_vec, the raw bytes of the user's PIN file), then
// streams encrypted_input_path through decrypt (and inflate, when
// is_data_compressed) into stream_output_path.
[[nodiscard]] DecryptResult decryptDataFile(
    vBytes& metadata_vec,
    vBytes& pin_vec,
    bool isBlueskyFile,
    const fs::path& encrypted_input_path,
    const fs::path& stream_output_path,
    bool is_data_compressed);
